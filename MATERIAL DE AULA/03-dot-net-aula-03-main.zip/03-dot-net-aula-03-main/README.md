### Tópicos Abordados

- Indices
- Paginação de Resultados
- Refactory 
	- Oraganização de Diretorios
	- Application
	- Domain
	- Infrastructure

### Indices

- Unico - Define indice em apenas um campo
- Composto - Define indice combinando um ou mais campos

```csharp
    [Table("tb_cliente")]
    [Index(nameof(Email), nameof(Nome))] // Indice Composto
    [Index(nameof(Email), IsUnique = true, Name = "IDX_cliente_email")]
    public class ClienteEntity
    {
		....
    }
```

### Paginação de Resultados

A **paginação de resultados em uma API ASP.NET (ou qualquer API)** é **fundamental** tanto para a performance do servidor quanto para a experiência do cliente que consome a API. Vou explicar os principais pontos:

#### Motivos para usar paginação em APIs

1. **Performance do servidor**    
    - Sem paginação, uma consulta que retorna milhares de registros vai consumir muita memória, CPU e tempo de processamento.
    - Isso pode sobrecarregar o **Entity Framework** e até travar a aplicação em cenários de alta concorrência.
2. **Tempo de resposta**
    - APIs que retornam dados massivos ficam lentas e podem até estourar o **timeout** do cliente.
    - Com paginação, você retorna apenas um subconjunto (ex.: 20 itens), garantindo respostas rápidas.
3. **Redução de tráfego de rede**
    - Se sua API mandar **10.000 registros em JSON**, o payload pode ter vários MB.
    - Isso prejudica dispositivos móveis e conexões lentas.
    - Paginar mantém o **payload leve e eficiente**.
4. **Melhor experiência para o cliente (frontend)**
    - Frontends (React, Angular, Vue, Mobile, etc.) conseguem carregar dados aos poucos (scroll infinito, botões "Próximo/Anterior").
    - Isso melhora a usabilidade e evita "travamentos" de UI.
5. **Escalabilidade**
    - Com paginação, sua API suporta mais usuários concorrentes.
    - Sem ela, alguns poucos requests pesados podem derrubar o sistema.
6. **Controle e ordenação**
    - Paginação geralmente vem junto com **ordenação e filtros**.
    - Isso permite ao cliente **navegar e consultar dados de forma organizada**.
7. **Compatibilidade com padrões de mercado**
    - Quase todas as APIs públicas (GitHub, Twitter, Google) usam paginação (`?page=1&limit=20`).
    - Isso se tornou um **padrão esperado** para desenvolvedores.

#### Tipos de paginação

- Offset-Based Pagination 
	Pula posições com skip (offset)
- Cursor-Based-Pagination
	É mais usando para paginações infinitas 


#### Offset Based Pagination

Criando modelo na pasta Models, que servirá para formatar a saída de dados do nosso modelo.
Ele esta usando generics `<T>`, para assumir o tipo do objeto que for passado

```csharp
public class PageResultModel<T>
{
	public required T Data { get; set; } 

	public int Deslocamento { get; set; }
	public int RegistroRetornado { get; set; }
	public int TotalRegistros { get; set; }
}
```

Modificando a interface 

```csharp
 Task<PageResultModel<IEnumerable<ClienteEntity>>> ObterTodosAsync(int Deslocamento = 0, int RegistroRetornado = 3);
```

Alterando o método do repositório para buscar as iformações

```csharp
public async Task<PageResultModel<IEnumerable<ClienteEntity>>> ObterTodosAsync(int Deslocamento = 0, int RegistroRetornado = 3)
{
	if (Deslocamento < 0) Deslocamento = 0;
	if (RegistroRetornado <= 0) RegistroRetornado = 3;

	var totalRegistros = await _context.Cliente.CountAsync();

	var result = await _context
		.Cliente
		.OrderBy(x => x.Id)
		.Skip(Deslocamento)
		.Take(RegistroRetornado)
		.ToListAsync();

	return new PageResultModel<IEnumerable<ClienteEntity>> { 
		Data = result,
		Deslocamento = Deslocamento,
		RegistroRetornado = RegistroRetornado,
		TotalRegistros = totalRegistros
	};
}
```

Ajustando a controller para receber os parmetros de Deslocamento e Registros Retornados

```csharp
public async Task<IActionResult> Get(int Deslocamento, int RegistroRetornado)
{
	var result = await _clienteRepository.ObterTodosAsync(Deslocamento, RegistroRetornado);

	if(!result.Data.Any())
		return NoContent();
		
	........    
}
```


### Refactory

#### Organização de Diretórios

A importância de organizando o projeto utilizando a arquitetura `Clean Architecture` são:

- Mantém o **domínio independente** de frameworks e banco de dados.
- Facilita **testes unitários**, pois regras de negócio ficam isoladas.
- Permite **trocar tecnologias** (ex.: EF → Dapper, API REST → gRPC) sem reescrever o core.
- Ajuda na **manutenção e evolução** do sistema, evitando acoplamento.
- Deixa claro **quem faz o quê**, aumentando organização e legibilidade.


```
|--Solution
	|--Project 
		|--Presentation
			|--API
		|--Application
			|--Dtos
			|--Interface
			|--Mappers
			|--UseCase
		|--Domain
			|--Entities
			|--Interfaces
		|--Infrastructure
			|--Data
				|--AppData
				|--Repositories
			|--Ioc
				Bootstrap.cs
```

- **Domain**: o coração do negócio (entidades, VOs, regras puras).
- **Application**: casos de uso/orquestração (Commands/Queries, portas/abstrações).
- **Infrastructure**: detalhes (EF Core, repositórios concretos, integrações, DI/IoC).
- **Presentation**: entrega/entrada (API Controllers, DTOs, validação de request, mapeamentos).

##### Entendendo as camadas
##### Presentation

- Camada de **entrada/saída** da aplicação.
- Onde ficam **Controllers, Endpoints, CLI, UI**.
- **Função:** receber requisição → validar → chamar `Application`.
- **Não contém regra de negócio**, só comunicação.
##### Application

- Camada de **orquestração de casos de uso**.
- Onde ficam **UseCases, DTOs, Mappers, Services de aplicação**.
- **Função:** coordenar entidades do domínio + repositórios (interfaces).
- Depende só de **Domain**, nunca de `Infrastructure`.

###### SOLID:
- S — Single Responsibility
	- **UseCase** só orquestra a regra + persistência (`ClienteUseCase`).
	- **Mapper/DTO** só transformação de dados e contratos de entrada/saída.
- D — Dependency Inversion
	- Depende somente das interfaces do Domain
	- Infrastructure fornece a implementações concretas
- O — Open/Closed
	- Mapper criando comportamentos para converter os dados de dtos para entidades
	
##### Domain

- **Coração do sistema**: regras de negócio puras.
- Onde ficam **Entities, ValueObjects, Eventos, Interfaces de repositório**.
- **Função:** modelar o negócio (ex.: Cliente, Produto, Estado).
- Não conhece banco de dados, API externa, nada de infra.

###### SOLID:
- S — Single Responsibility
	- **Entity** só regra/estado de domínio (`Cliente`, `Produto`, `Estado`).
- L — Liskov Substitution (Substituição de Liskov)
	- Sistema orientado a abstração (Interfaces) e não a classes concretas

##### Infrastructure

- Camada dos **detalhes técnicos**.
- Onde ficam **DbContext, EF Configurations, Repositórios concretos, Serviços externos, IoC**
- **Função:** implementar o que o `Domain` e `Application` precisam (repos, persistência, integrações).
- Pode mudar (ex.: EF → Dapper) sem quebrar o resto.

###### SOLID:
- S — Single Responsibility
	- **Repository** só persistência (`ClienteRepository`, etc.).
- I — Interface Segregation
	- Repositórios separados por entidade (`ClienteRepository`, `ProdutoRepository`)

##### Resumos das camas:

- **Presentation** → entra e sai dados.    
- **Application** → orquestra casos de uso.
- **Domain** → define regras do negócio.
- **Infrastructure** → executa detalhes técnicos.