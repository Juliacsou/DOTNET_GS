
**Tópicos Abordados**

- Testes 
	- Unidade
	- Funcionais


### Testes

**Testes de software** são procedimentos criados para **verificar se o sistema funciona conforme o esperado**.  
Eles garantem que cada parte do código (funções, classes, APIs) esteja fazendo o que deveria fazer **antes que o sistema vá para produção**.

*Em resumo:* testar é comparar o comportamento **esperado** com o comportamento **real** da aplicação.

#### Importância dos testes

1. **Evitar falhas em produção** — detecta erros antes que o usuário veja.
2. **Garantir qualidade e confiança** — você pode alterar o código sem medo de quebrar algo.
3. **Facilitar manutenção** — ao refatorar, os testes mostram se o sistema continua íntegro.
4. **Melhorar o design do código** — escrever testes força o desenvolvedor a criar código mais limpo e modular.
5. **Automatizar a validação** — economiza tempo e reduz erros manuais.


#### Configurando projeto de Testes

Para criar os projetos de testes, vamos utilizar o `xUnit`, adicione um novo projeto na solução com Tipo xUnit.

Adicione duas pastas `Introducao` e `APP`, que vamos utilizar para criar os nossos testes de exemplos e aplicação.

**Estrutura do diretório:**

```css
...

├─ 4 - Tests
│  └─ Revisao.Tests
│     ├─ Dependencies
│     ├─ APP
│     └─ Introducao
│        └─ Exemplos

...
```

No diretório `Exemplos`, vamos criar dois arquivos `Calculadora.cs` e `Textos.cs`. Estes arquivos vão ser utilizados para simular classes do nosso sistema e entender o conceito de testes. 

```css
├─ 4 - Tests
│  └─ Revisao.Tests
│     ├─ Dependencies
│     ├─ APP
│     ├─ Introducao
│     │  └─ Exemplos
│     │     ├─ Calculadora.cs
│     │     └─ Textos.cs

```

**Calculadora.cs**

```csharp
internal class Calculadora  
{  
    public double Somar(double valor1, double valor2)  
    {  
        var soma = valor1 + valor2;  
  
        if (soma == 80)  
            return 50;  
  
        return soma;  
    }  
  
    public decimal CalcularFrete(decimal peso)  
    {  
	    // Representa o custo mínimo de envio (ex.: taxa administrativa, combustível, manuseio, etc.).  
        decimal TaxaFixa = 10m; 
		// Cada quilograma(ou unidade de peso) custa R$ 2,50  
        decimal Valor = 2.5m; 
  
  
        return TaxaFixa + (peso * Valor);  
    }  
}
```

**Textos.cs**

```csharp
internal class Textos  
{  
    public string JuntarTexto(string texto1, string texto2)  
    {  
        return $"{texto1} {texto2}";  
    }  
}
```

> **Obs:** Para visualizar e rodar os testes de unidade deve habilitar no Visual Studio o `Test Explorer` que fica no menu `Views > Test Explorer`.  Com ele podemos rodar e visualizar os testes de forma clara, além de poder organizar (Agrupar) os testes usando anotações nos métodos. `(Trait)`. 

#### O que são os 3 A`s

Os **3 A’s (Arrange, Act, Assert)** são um **padrão de estruturação de testes automatizados** muito usado em testes de unidade no .NET (e em outras linguagens também).  
Ele ajuda a deixar o teste **organizado, legível e com responsabilidade clara em cada etapa**.

##### 1. Arrange (Preparar)

Nesta etapa você **configura o cenário do teste**.  
É onde você **cria os objetos**, **define valores de entrada**, **mocks** e **dependências necessárias**.  
Ou seja, prepara tudo para que o código a ser testado possa ser executado.


```csharp
// Arrange
var calculadora = new Calculadora();
int numero1 = 10;
int numero2 = 5;

```

##### 2. Act (Agir)

Aqui é onde você **executa a ação que está sendo testada**, geralmente chamando o método ou função alvo.  
É a parte central do teste — o "ato" que queremos verificar.

```csharp
// Act
int resultado = calculadora.Somar(numero1, numero2);

```

##### 3. Assert (Verificar)

Por fim, você **verifica se o resultado obtido está correto**, comparando com o valor esperado.  
Se o teste falhar aqui, é porque o comportamento do código não está conforme o esperado.

```csharp
// Assert
Assert.Equal(15, resultado);

```

*Exemplo Completo*

```csharp
public class CalculadoraTests
{
    [Fact]
    public void Somar_DeveRetornarSomaCorreta()
    {
        // Arrange - Preparar
        var calculadora = new Calculadora();
        int numero1 = 10;
        int numero2 = 5;

        // Act - Agir
        int resultado = calculadora.Somar(numero1, numero2);

        // Assert - Verificar
        Assert.Equal(15, resultado);
    }
}
```

#### Entendendo Fact e Theory

Vamos criar um arquivo `SomarTest.cs` na pasta `Introducao`, nele vamos criar os testes de unidade e enter o conceito de Fact e Theory.

**Projeto dever ficar assim:**

```css
├─ 4 - Tests
│  └─ Revisao.Tests
│     ├─ Dependencies
│     ├─ APP
│     ├─ Introducao
│     │  ├─ Exemplos
│     │  │  ├─ Calculadora.cs
│     │  │  └─ Textos.cs
│     │  └─ SomarTest.cs

```

##### Fact - Teste fixo (sem variação de dados)

O `[Fact]` é usado quando o **teste não depende de parâmetros** ou **dados variáveis**.  
Ou seja, o comportamento que você quer testar **é sempre o mesmo**.

Pense em “Fact” como um **fato** — algo que deve ser sempre verdade, sem variações.

```csharp
[Fact]  
[Trait("Simples", "Soma")] 
public void Somar_DeveRetornarSomaCorreta()  
{  
    // Arrange - Preparar  
    var calculadora = new Calculadora();  
  
    double numero1 = 10;  
    double numero2 = 5;  
  
    // Act - Agir  
    double resultado = calculadora.Somar(numero1, numero2);  
  
    // Assert - Verificar  
    Assert.Equal(15, resultado);  
}
```

No **`Assert`**, podemos validar **mais de uma condição** dentro do mesmo teste, verificando diferentes aspectos do comportamento esperado do código.  
Isso é especialmente útil quando queremos garantir que **várias propriedades** ou **resultados** estejam corretos ao mesmo tempo por exemplo, confirmar que o objeto não é nulo, que o valor retornado é o esperado e que uma determinada regra de negócio foi aplicada corretamente.

Para isso, podemos adicionar **múltiplas checagens** (ou **assertivas**) dentro do mesmo método de teste, cada uma validando uma “verdade” diferente sobre o resultado obtido.  

Exemplo a seguir demonstra essa prática:

```csharp
[Fact]  
[Trait("Simples", "Soma")]  
public void Somar_DeveRetornarSomaCorreta_40()  
{  
    // Arrange - Preparar  
    var calculadora = new Calculadora();  
  
    double numero1 = 20; 
    double numero2 = 20;  
  
    // Act - Agir    
    double resultado = calculadora.Somar(numero1, numero2);  
  
    // Assert - Verificar  
    Assert.True(resultado > 20, "Valoro deve ser maior que 20");  
  
    // Assert  
    Assert.NotNull(calculadora);  
  
    // Assert  
    Assert.Equal(40, resultado);  
}
```

###### Organizando os método com Trait

Nos exemplos acima, utilizando o `Fact`, estamos usando o `[Trait]` para organizar a visualização no `Test Explorer`.

O atributo `[Trait]` é usado para **organizar e categorizar testes automatizados** dentro do framework **xUnit**.  
Ele serve para **rotular** um teste com informações adicionais como o tipo de cenário, módulo, funcionalidade, ou o objetivo do teste.

Na prática, o `[Trait]` não muda a execução do teste em si, mas ajuda a **classificar**, **filtrar** e **entender melhor** o propósito daquele teste quando você o executa no Visual Studio, no terminal, ou em pipelines de CI/CD (como GitHub Actions, Azure DevOps ou GitLab CI).

```csharp
[Fact]  
[Trait("Simples", "Soma")] // Organizando o teste com anotação Trait  
public void Somar_DeveRetornarSomaCorreta_40() 
{
	...
} 
```

##### Theory - Teste com variação de dados (parametrizado)

O `[Theory]` é usado quando você quer **testar o mesmo método com vários conjuntos de dados**.  Ele trabalha junto com atributo `[InlineData]`.

Pense em “Theory” como uma **teoria que precisa ser provada com diferentes exemplos**.

```csharp
[Theory]  
[InlineData(1, 1, 2)]  
[InlineData(10, 10, 20)]  
[InlineData(40, 40, 50)]  
[Trait("Teoria", "Soma")]  
public void Calcular_Soma_RetornaValoresCorretos(int v1, double v2, double total)  
{  
    //Arrange - Preparar  
    var calcular = new Calculadora();  
  
    //Act - Agir  
    var resultado = calcular.Somar(v1, v2);  
  
    //Assert - Verificar  
    Assert.Equal(total, resultado);  
}
```



#### Testes de Unidade

O **teste de unidade** é um tipo de teste automatizado que **verifica o funcionamento isolado de uma parte específica do código**, como um **método** ou **função**.
Objetivo é garantir que cada unidade do sistema faça exatamente o que foi planejado, sem depender de outras partes do código. Para isto vamos testar cada método dos principais módulos da aplicação sendo eles `Repository`, `Application` e `Dominio`.

##### Testando Repository

No **Clean Architecture**, a camada **Infrastructure** é responsável por **persistir e recuperar os dados**, geralmente por meio de **repositórios** que acessam o banco via `DbContext`.

Essa camada é **crítica** porque é ela que traduz as operações de alto nível (como `AdicionarCliente`, `ObterTodosProdutos`) em comandos SQL reais no banco.

Portanto, **testar o repositório é garantir que:**

1. As consultas e filtros do Entity Framework estão corretos.
2. O mapeamento entre entidades e tabelas funciona (propriedades, chaves, relacionamentos etc).
3. As operações CRUD realmente se comportam como esperado sem depender do banco de produção.

###### Por que usar um banco em memória

Durante o desenvolvimento, **não queremos usar o banco de dados real** (PostgreSQL, SQL Server, MongoDB, etc.) em cada teste.

Por isso o **Entity Framework Core** oferece o **provedor InMemory**, que cria um banco **temporário na memória RAM**, ideal para testes unitários e de integração.

**Vantagens:**

1. **Rápido:** o banco é criado e destruído em memória, sem disco.
2. **Isolado:** cada teste começa com um banco limpo, sem interferência.
3. **Seguro:** não altera dados reais.
4. **Simples:** não precisa instalar servidor de banco.

Quando trabalhamos com o **Entity Framework**, um grande desafio é **testar a persistência** de dados **sem depender de um servidor real.

**Vantagens:**

1. O baco sobe localmente, em tempo de execução.
2. É totalmente isolado (cada teste tem seu próprio banco).
3. Roda em pipelines (CI/CD) sem dependências externas.
4. Permite testar o **Entity Framework**  de forma realista.

###### Instalando a Dependência:

Adicione a dependência `Microsoft.EntityFrameworkCore.InMemory` na aplicação de testes.

```bash
dotnet add package Microsoft.EntityFrameworkCore.InMemory
```

###### Preparando ambiente:

Vamos criar um novo arquivo chamado `ClienteRepositoryTest.cs`, para executar os testes de repositório. 

```css
├─ 4 - Tests
│  └─ Revisao.Tests
│     ├─ Dependencies
│     ├─ APP
│     │  ├─ ClienteRepositoryTest.cs
│     │  ├─ ClienteUseCaseTest.cs
│     │  └─ EntityTest.cs
│     └─ Introducao

```

###### Configurando Banco em Memória


O construtor do teste prepara todo o ambiente necessário para testar o `ClienteRepository` **sem utilizar um banco de dados real**, como PostgreSQL, SQL Server ou Oracle.

```csharp
private readonly DbContextOptions<ApplicationContext> _options;  
private readonly ApplicationContext _applicationContext;  
private readonly ClienteRepository _clienteRepository;
```

Esses atributos representam:

- **`_options`** → configurações que serão utilizadas pelo Entity Framework Core para criar o `ApplicationContext`.
- **`_applicationContext`** → instância do contexto do Entity Framework Core que será utilizada durante os testes.
- **`_clienteRepository`** → repositório que será testado.

---

### Configuração do banco em memória

```csharp
_options = new DbContextOptionsBuilder<ApplicationContext>()
    .UseInMemoryDatabase(databaseName: "TestDatabase")
    .Options;
```

Aqui está sendo configurado o **Entity Framework Core InMemory**.

O método:

```csharp
.UseInMemoryDatabase("TestDatabase")
```

informa ao Entity Framework que, em vez de utilizar um banco de dados externo, ele deve criar um **banco de dados em memória** chamado `TestDatabase`.

Isso é útil em testes porque:

- não precisa instalar ou acessar um banco de dados;
- os testes ficam mais rápidos;
- não é necessário configurar conexão;
- os testes podem ser executados em qualquer ambiente;
- permite testar o comportamento do repositório de forma isolada.

Dessa forma criamos uma baco isolado para executar os testes no repositório.

```csharp
private readonly DbContextOptions<ApplicationContext> _options;  
private readonly ApplicationContext _applicationContext;  
private readonly ClienteRepository _clienteRepository;  
  
public ClienteRepositoryTest()  
{  
    _options = new DbContextOptionsBuilder<ApplicationContext>()  
        .UseInMemoryDatabase(databaseName: "TestDatabase")  
        .Options;  
  
    _applicationContext = new ApplicationContext(_options);  
  
    _applicationContext.Database.EnsureDeleted();  
    _applicationContext.Database.EnsureCreated();  
  
    _clienteRepository = new ClienteRepository(_applicationContext);  
}
```

###### Criando os testes

**Validar o ObterTodosAsync**

```csharp
[Fact]  
[Trait("Repository", "Clientes")]  
public void ObterTodos_DeveRetornarClientes()  
{  
    // Arrange  
    var clientes = new List<ClienteEntity> {  
        new ClienteEntity { Nome = "João", Email = "joao.silva@example.com", Idade = 30 },  
        new ClienteEntity { Nome = "Maria", Email = "maria.silva@example.com", Idade = 25 },  
        new ClienteEntity { Nome = "Pedro", Email = "pedro.silva@example.com", Idade = 40 }  
    };  
  
    //Adicionando no banco em memoria  
    _applicationContext.Cliente.AddRange(clientes);  
    _applicationContext.SaveChanges();  
  
    // Act  
    var resultado = _clienteRepository.ObterTodos(0, 10);  
  
    // Assert  
    Assert.NotNull(resultado);  
    Assert.Equal(3, resultado.Count());  
  
    Assert.Collection(resultado,  
        cliente =>  
        {  
            Assert.Equal("João", cliente.Nome);  
            Assert.Equal("joao.silva@example.com", cliente.Email);  
            Assert.Equal(30, cliente.Idade);  
        },  
  
        cliente =>  
        {  
            Assert.Equal("Maria", cliente.Nome);  
            Assert.Equal("maria.silva@example.com", cliente.Email);  
            Assert.Equal(25, cliente.Idade);  
        },  
  
        cliente =>  
        {  
            Assert.Equal("Pedro", cliente.Nome);  
            Assert.Equal("pedro.silva@example.com", cliente.Email);  
            Assert.Equal(40, cliente.Idade);  
        });  
}
```

**Validar o ObterUmAsync**

```csharp
[Fact]  
[Trait("Repository", "Clientes")]  
public void ObterUm_DeveRetornarUmCliente()  
{  
    // Arrange  
    var cliente = new ClienteEntity  
    {  
        Id = 1,  
        Nome = "João",  
        Email = "joao.silva@example.com",  
        Idade = 30  
    };  
  
    _applicationContext.Cliente.Add(cliente);  
    _applicationContext.SaveChanges();  
  
    // Act  
    var resultado = _clienteRepository.ObterUm(1);  
  
    // Assert  
    Assert.NotNull(resultado);  
    Assert.Equal(cliente.Id, resultado.Id);  
    Assert.Equal(cliente.Nome, resultado.Nome);  
    Assert.Equal(cliente.Email, resultado.Email);  
    Assert.Equal(cliente.Idade, resultado.Idade);  
}
```

**Validar o AdicionarAsync**

```csharp
[Fact]  
[Trait("Repository", "Clientes")]  
public void Adicionar_DeveAdicionarCliente()  
{  
    // Arrange  
    var cliente = new ClienteEntity  
    {  
        Nome = "João",  
        Email = "joao.silva@example.com",  
        Idade = 30  
    };  
  
    // Act  
    var resultado = _clienteRepository.Adicionar(cliente);  
  
    // Assert  
    var idCliente = resultado?.Id ?? -1; //Buscar o ultimo ID Inserido  
  
    var clienteNoDb = _applicationContext.Cliente.FirstOrDefault(c => c.Id == idCliente);  
  
    Assert.NotNull(clienteNoDb);  
  
    Assert.Equal(cliente.Nome, clienteNoDb.Nome);  
    Assert.Equal(cliente.Email, clienteNoDb.Email);  
    Assert.Equal(cliente.Idade, clienteNoDb.Idade);  
}
```


##### Testando Application

Dentro da **Clean Architecture**, a camada **Application (ou UseCases)** é o **coração das regras de negócio** da aplicação.  
Ela é responsável por **coordenar o fluxo entre o domínio (entidades, regras puras)** e a **infraestrutura (banco de dados, serviços externos, APIs)**.

Por isso, **testar a camada Application é fundamental**, pois:

1. **Garante que a lógica de negócio funciona corretamente**, sem depender de banco de dados ou APIs externas.  
    → Exemplo: garantir que um cliente é criado apenas com dados válidos.
2. **Evita efeitos colaterais em testes** queremos testar o comportamento da regra, não da infraestrutura.
3. **Permite isolar e validar o comportamento da classe “UseCase”**, garantindo que ela chame o repositório corretamente e trate os resultados esperados.
4. **Aumenta a confiabilidade do sistema**, permitindo refatorações seguras (se o teste quebrar, sabemos exatamente o que mudou).

Antes de tudo devemos criar um novo arquivo `ClienteUseCaseTest.cs` para testar a application.

```css
├─ 4 - Tests
│  └─ Revisao.Tests
│     ├─ Dependencies
│     ├─ APP
│     │  ├─ ClienteRepositoryTest.cs
│     │  ├─ ClienteUseCaseTest.cs
│     └─ Introducao

```

Agora, vamos **definir algumas propriedades e um construtor** dentro da nossa classe de testes, para preparar o ambiente e execução dos cenários de teste.

Instale a dependência `Moq` na solução de teste.

```bash
dotnet add package Moq
```

Em seguida, vamos **entender o uso do `Mock`** um recurso fundamental nos testes de unidade.

**Configurando os atributos de teste**

```csharp
public class ClienteUseCaseTest  
{  
  
    private readonly Mock<IClienteRepository> _clienteRepository;  
    private readonly ClienteUseCase _clienteUseCase;  
  
    public ClienteUseCaseTest()  
    {  
        _clienteRepository = new Mock<IClienteRepository>();  
        _clienteUseCase = new ClienteUseCase(_clienteRepository.Object);  
    }
    
    ....
}
```

###### O que é o _Mock_?

O **Mock** permite **simular o comportamento de dependências externas**, como repositórios, serviços ou APIs, sem precisar acessar realmente o banco de dados ou outros sistemas.

Com isso, conseguimos testar apenas a **lógica interna da classe em análise**, garantindo que o foco do teste permaneça sobre o **comportamento do código**, e não sobre suas dependências.

Em outras palavras, o **mock substitui**:

- O acesso ao banco de dados (`IClienteRepository`),
- Qualquer outra dependência complexa.
    
Devemos criar os objetos utilizando o **framework Moq**, como mostrado no exemplo abaixo:

```csharp
_clienteRepository = new Mock<IClienteRepository>();

_clienteUseCase = new ClienteUseCase(_clienteRepository.Object);

```

**Entendendo funcionamento:**

> - Criar versões “falsas” das interfaces.
> - Quando chamados o `.Object`, ele retorna o **objeto simulado**, que é injetado no `ClienteUseCase`.  Com isso **nenhuma consulta real ao banco será feita**.


**Simulando comportamentos com `Setup`**

Sempre que utilizamos o **Moq**, precisamos **definir o comportamento esperado** do objeto simulado ou seja, **informar o que o mock deve retornar** quando um determinado método for chamado durante o teste.

Essa configuração é essencial, pois o **mock não contém lógica real**; ele apenas **imita o comportamento da dependência original**.  
Assim, conseguimos **controlar completamente o fluxo do teste**, garantindo que ele não dependa de banco de dados, APIs externas ou qualquer outro serviço real.

Para definir esse comportamento, utilizamos o método **`Setup`**.  
É por meio dele que indicamos qual método do mock será chamado e qual **valor simulado** deve ser retornado, permitindo que o teste continue como se estivesse lidando com uma implementação verdadeira.

**Exemplo:**

```csharp
//Arrange  
var listaClientes = new List<ClienteEntity>  
{  
    new ClienteEntity { Id = 1, Nome = "Carlos", Email = "cliente1@teste.com" },  
    new ClienteEntity { Id = 2, Nome = "Andre" , Email = "cliente2@teste.com" }  
};  
  
//Usando Com Async  
_clienteRepository.Setup(obj => obj.ObterTodosAsync(0, 3)).Returns(Task.FromResult(listaClientes));  

// Usando sem Async  
_clienteRepository.Setup(obj => obj.ObterTodos(0, 3)).Returns(listaClientes);
```

Nesse exemplo, estamos dizendo ao **mock**:

> “Quando o método `ObterTodosAsync(0, 3)` for chamado, retorne uma lista de  `ClienteEntity com as informações da paginação`.

Com isso, o teste pode prosseguir normalmente, como se estivesse acessando o repositório real mas, na verdade, estamos usando uma **simulação controlada**.

###### Criando os testes

**Validando ObterTodosAsync**

```csharp
[Fact]  
[Trait("UseCase", "Clientes")]  
public async Task ObterTodosClientes_DeveRetonarTodosOsClientes()  
{  
    //Arrange    
var listaClientes = new List<ClienteEntity>  
    {  
        new ClienteEntity { Id = 1, Nome = "Carlos", Email = "cliente1@teste.com" },  
        new ClienteEntity { Id = 2, Nome = "Andre" , Email = "cliente2@teste.com" }  
    };  
  
    _clienteRepository.Setup(obj => obj.ObterTodosAsync(0,3)).Returns(Task.FromResult(listaClientes));  
  
    //Act  
  
    // Usando Async    
    var resultado = await _clienteUseCase.ObterTodosClientesAsync();    
    var resultado = _clienteUseCase.ObterTodosClientes(0, 3);  
  
    //Assert    
	Assert.NotNull(resultado);  
  
    //Usando async  
    //Assert.Equal(2, resultado.Value.ToList().Count);  
    Assert.Equal(2, resultado.ToList().Count);  
  
    // Valida um registro específico  
    var cliente = resultado.SingleOrDefault(x => x.Id == 1);  
  
    Assert.NotNull(cliente);  
    Assert.Equal(1, cliente.Id);  
    Assert.Equal("Carlos", cliente.Nome);  
  
}
```

**Validando ObterUmClienteAsync**

```csharp
[Fact]  
[Trait("UseCase", "Clientes")]  
public void ObterUm_DeveRetonarUmClientes()  
{  
  
    //Arrange    
    int idCliente = 1;  
  
    var cliente = new ClienteEntity { Id = 1, Nome = "Carlos", Email = "cliente1@teste.com" };  
  
    //Prepara o repository  
    _clienteRepository.Setup(obj => obj.ObterUm(idCliente)).Returns(cliente);  
  
    //Act    
var resultado = _clienteUseCase.ObterUmCliente(1);  
  
    //Assert    
Assert.NotNull(resultado);  
    Assert.Equal(idCliente, resultado.Id);  
    Assert.Equal(cliente.Nome, resultado.Nome);  
}
```

**Validando AdicionarAsync**

```csharp
[Fact]  
[Trait("UseCase", "Clientes")]  
public void AdicionarAsync_DeveRetonarTodosOsClientes()  
{  
    //Arrange    
var clienteDto = new PostClienteDto { Nome = "Carlos", Email = "cliente1@teste.com", Idade = 10 };  
  
    var entity = clienteDto.ToClienteEntity();  
  
    _clienteRepository.Setup(obj => obj.Adicionar(It.IsAny<ClienteEntity>())).Returns(entity);  
  
    //Act    
var resultado = _clienteUseCase.AdicionarCliente(clienteDto);  
  
    //Assert    
Assert.NotNull(resultado);  
  
    Assert.Equal(clienteDto.Nome, resultado!.Nome);  
    Assert.Equal(clienteDto.Email, resultado!.Email);  
    Assert.Equal(clienteDto.Idade, resultado!.Idade);  
}
```


#### Teste Funcional (Integração)

Um **teste funcional** também chamado de **teste de integração** é aquele que **verifica o comportamento completo da aplicação**, testando várias camadas **trabalhando juntas**:

> 🔹 Controller → Application (UseCase) → Repository → Banco (ou simulado)

Ou seja, ele **não testa só uma função isolada**, mas **toda a integração entre os componentes reais** da API, sendo necessários a criação de testes nas outras camadas.

##### Testando Controller

###### Preparando ambiente:

Vamos criar um novo arquivo chamado `ClienteControllerTest.cs`, para executar os testes de integração. 

```css
├─ 4 - Tests
│  └─ Revisao.Tests
│     ├─ Dependencies
│     ├─ APP
│     │  ├─ ClienteControllerTest.cs
│     │  ├─ ClienteRepositoryTest.cs
│     │  ├─ ClienteUseCaseTest.cs
│     └─ Introducao
```

**Dependências:**

Instale as dependências para disponibilizar dependências como `WebApplicationFactory` para os testes funcionais (Integração). 

```bash
dotnet add package Microsoft.AspNetCore.Mvc.Testing
```

###### WebApplicationFactory

Em projetos ASP.NET, usamos a classe `WebApplicationFactory<TEntryPoint>` (do pacote `Microsoft.AspNetCore.Mvc.Testing`) para **subir a aplicação real em memória**, sem precisar de servidor.

```csharp
....

using Microsoft.AspNetCore.Mvc.Testing;  
using Microsoft.Extensions.DependencyInjection;  
using Microsoft.Extensions.DependencyInjection.Extensions;


public class CustomWebApplicationFactory : WebApplicationFactory<Program>  
{  
    public Mock<IClienteUseCase> ClienteUseCaseMock { get; } = new();  
  
    protected override void ConfigureWebHost(IWebHostBuilder builder)  
    {  
        builder.ConfigureServices(services =>  
        {  
            // Cria o Mock do IClienteUseCase    
services.RemoveAll(typeof(IClienteUseCase));  
            services.AddSingleton(ClienteUseCaseMock.Object);  
        });  
    }  
}

public class ClienteControllerTest
{
	...
}
```

###### Configurando DI e WebFactory

```csharp
public class ClienteControllerTest : IClassFixture<CustomWebApplicationFactory>  
{  
    private readonly CustomWebApplicationFactory _factory;  
  
    public ClienteControllerTest(CustomWebApplicationFactory factory)  
    {  
        _factory = factory;  
    }
}
```

**Tetando ObterTodosClientesAsync**

```csharp
[Fact(DisplayName = "GET /api/cliente retorna 200 OK")]  
[Trait("Controller", "Clientes")]  
public async Task Get_DeveRetornar204()  
{  
    // Arrange    
var clientes = new List<ClienteEntity> {  
        new ClienteEntity { Nome = "João", Email = "joao.silva@example.com", Idade = 30 },  
        new ClienteEntity { Nome = "Maria", Email = "maria.silva@example.com", Idade = 25 },  
        new ClienteEntity { Nome = "Pedro", Email = "pedro.silva@example.com", Idade = 40 }  
    };  
  
    _factory.ClienteUseCaseMock  
        .Setup(x => x.ObterTodosClientes(0, 3))  
        .Returns(clientes);  
  
    //Criando a controller  
    using var client = _factory.CreateClient();  
  
    // Act  
    var response = await client.GetAsync("/api/cliente");  
  
    // Assert    
Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);  
}
```