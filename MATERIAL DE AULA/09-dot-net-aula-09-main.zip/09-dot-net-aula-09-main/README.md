
**Tópicos Abordados**

- Aplicando Mongodb com EF


Nesta aula, expandimos a arquitetura da nossa API desenvolvida em **ASP.NET Core 8**, integrando o ecossistema NoSQL através do **MongoDB** utilizando o provedor oficial do **Entity Framework Core** (`MongoDB.EntityFrameworkCore`). Além disso, abordamos a convivência de múltiplos contextos de banco de dados (Relacional Oracle e NoSQL MongoDB), os cuidados na execução de comandos de migração com múltiplos contextos, o mapeamento de entidades com coleções de documentos embutidos (subdocumentos), e a aplicação prática de autorização baseada em papéis (**Roles**) em endpoints da aplicação.

## 1. Introdução ao MongoDB e Persistência Poliglota

No desenvolvimento de sistemas modernos corporativos, é comum nos depararmos com diferentes necessidades de armazenamento de dados:

- **Dados relacionais e transacionais (ACID estrito):** informações financeiras, usuários e cadastros centrais que demandam chaves primárias, chaves estrangeiras e integridade referencial rígida (ex.: Oracle, PostgreSQL, SQL Server).
- **Dados flexíveis, semiestruturados ou de alta volumetria:** catálogos de produtos, pedidos com histórico de itens embutidos, logs de auditoria e carrinhos de compras que se beneficiam do formato hierárquico e escalabilidade horizontal (ex.: MongoDB).

A estratégia de utilizar diferentes tecnologias de banco de dados na mesma solução de acordo com a natureza do dado é chamada de **Persistência Poliglota (Polyglot Persistence)**.

### Modelo Relacional vs. Modelo Baseado em Documentos

| Característica | Banco Relacional (ex.: Oracle) | Banco NoSQL de Documentos (ex.: MongoDB) |
| :--- | :--- | :--- |
| **Estrutura básica** | Tabelas, Linhas (Rows) e Colunas | Coleções (Collections) e Documentos (BSON/JSON) |
| **Esquema (Schema)** | Rígido (Definido por DDL e Migrations) | Flexível / Dinâmico |
| **Relacionamentos** | Chaves estrangeiras (Foreign Keys) e `JOIN` | Documentos Embutidos (Embedded) ou Referências |
| **Identificador Primário** | `NUMBER`, `INT`, `IDENTITY`, `SEQUENCE` | `ObjectId` (12-byte BSON Unique Identifier) |
| **Consultas** | SQL (Structured Query Language) | BSON / MQL ou LINQ via Provedor |

No MongoDB, os dados são armazenados no formato **BSON** (*Binary JSON*), permitindo tipos de dados avançados (como datas binárias, inteiros de 64 bits e `ObjectId`), suportando aninhamento de listas e subobjetos dentro de um único registro.

---

## 2. Aplicando MongoDB com Entity Framework Core

Historicamente, o acesso ao MongoDB em aplicações .NET era realizado utilizando exclusivamente o driver nativo (`MongoDB.Driver`), que exigia sintaxes de filtro como `Builders<T>.Filter` e métodos manuais como `ReplaceOneAsync` ou `InsertOneAsync`.

A partir das versões recentes, a própria equipe oficial do MongoDB lançou o **MongoDB Entity Framework Core Provider** (`MongoDB.EntityFrameworkCore`). Esse pacote traz os seguintes benefícios:

- **Unificação de Padrões:** permite aos desenvolvedores C# utilizar a mesma abstração consagrada do `DbContext`, `DbSet<T>`, Change Tracker e consultas LINQ (`.Where()`, `.FirstOrDefault()`, `.Skip()`, `.Take()`).
- **Curva de Aprendizado Reduzida:** quem já sabe trabalhar com Entity Framework Core para Oracle, SQL Server ou SQLite utiliza exatamente as mesmas interfaces e ciclo de vida de contexto.
- **Interoperabilidade na Arquitetura:** podemos injetar contextos relacionais e NoSQL seguindo as mesmas convenções de Clean Architecture e Injeção de Dependências.

---

## 3. Bibliotecas e Dependências Necessárias

Para habilitar o suporte ao MongoDB e à manipulação de tipos BSON no projeto ASP.NET Core, foram instalados dois pacotes NuGet essenciais:

```bash
dotnet add package MongoDB.EntityFrameworkCore --version 8.3.3
dotnet add package MongoDB.Bson
```

### O que cada biblioteca faz:

1. **`MongoDB.EntityFrameworkCore`**: provedor oficial do Entity Framework Core mantido pela MongoDB Inc., que traduz comandos LINQ e operações de persistência em chamadas nativas do MongoDB.
2. **`MongoDB.Bson`**: biblioteca fundamental que define os tipos nativos do ecossistema Mongo, como a struct `ObjectId`, além dos atributos de serialização (`[BsonId]`, `[BsonRepresentation]`).

Visualização no arquivo de projeto (`AspNet.API.csproj`):

```xml
<ItemGroup>
    <PackageReference Include="MongoDB.Bson" Version="3.12.0" />
    <PackageReference Include="MongoDB.EntityFrameworkCore" Version="8.3.3" />
    <PackageReference Include="Oracle.EntityFrameworkCore" Version="8.23.26200" />
    <PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.8" />
    <PackageReference Include="Swashbuckle.AspNetCore" Version="6.6.2" />
</ItemGroup>
```

---

## 4. Configuração da Conexão (`appsettings.Development.json`)

No arquivo de configuração da aplicação, declaramos as variáveis de conexão com o banco de dados e as chaves de segurança. Para evitar a exposição de credenciais e dados sensíveis, utilize variáveis de ambiente ou placeholders conforme abaixo:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "ConnectionStrings": {
    "Oracle": "<SUA_CONNECTION_STRING_ORACLE>",
    "Mongodb": "<SUA_CONNECTION_STRING_MONGODB>"
  },
  "Secretkey": "<SUA_CHAVE_SECRETA_JWT>"
}
```

### Detalhamento das Configurações:

- **`ConnectionStrings:Oracle`**: string de conexão com a base de dados relacional Oracle (contendo host, porta, serviço e credenciais de acesso).
- **`ConnectionStrings:Mongodb`**: string de conexão com o servidor ou cluster MongoDB (ex.: `mongodb://localhost:27017` em ambiente local ou URI de conexão do MongoDB Atlas).
- **`Secretkey`**: chave secreta simétrica utilizada pela aplicação para assinar e validar os tokens JWT gerados no processo de autenticação.

---

## 5. Multi-Contextos no Entity Framework Core: O Cuidado com Migrations

Com a inclusão do `MongoApplicationContext`, a nossa aplicação passa a conter **dois contextos de banco de dados distintos**:

1. `ApplicationContext` → Conectado ao banco relacional **Oracle** (gerenciado por Migrations do EF Core).
2. `MongoApplicationContext` → Conectado ao banco NoSQL **MongoDB** (onde coleções e documentos não exigem DDL relacional rígido).

### O Problema do Comando Genérico de Migration

Quando executamos ferramentas de linha de comando do Entity Framework Core como `dotnet ef database update` ou o comando do Package Manager Console no Visual Studio:

```powershell
Update-Database
```

O Entity Framework Core emitirá um erro de ambiguidade informando que **existem múltiplos DbContexts registrados no projeto**, não sabendo qual deles deve ser considerado para gerar ou aplicar migrações:

> *"More than one DbContext was found. Specify which one to use by the --context parameter for the .NET Core CLI tools, or the -Context parameter for the Package Manager Console tools."*

### A Solução: Especificar o Contexto Explicitamente

Sempre que a aplicação possui mais de um `DbContext`, é obrigatório informar o parâmetro indicando o contexto relacional desejado.

#### No Package Manager Console (Visual Studio):

```powershell
# Passar o -Context quando tem dois contexts na aplicação
Update-Database -Context ApplicationContext
```

Para adicionar novas migrações:

```powershell
Add-Migration NomeDaNovaMigration -Context ApplicationContext
```

#### No Terminal (.NET CLI):

```bash
# Aplicando migrações informando o contexto
dotnet ef database update --context ApplicationContext

# Criando migrações informando o contexto
dotnet ef migrations add NomeDaNovaMigration --context ApplicationContext
```

> [!IMPORTANT]
> O **MongoDB** não necessita de migrações relacionais para criação de tabelas (`CREATE TABLE`), pois cria dinamicamente o banco de dados e as coleções assim que o primeiro documento for gravado. Portanto, as migrações continuam restritas ao contexto relacional (`ApplicationContext`).

---

## 6. Modelagem de Entidades para MongoDB

No modelo NoSQL de documentos, é comum modelar uma entidade principal (como um **Pedido**) contendo seus detalhes associados (como os **Itens do Pedido**) embutidos diretamente no próprio documento, em vez de criar uma tabela separada com chave estrangeira.

### 6.1. Subdocumento: `PedidoItemEntity`

Criamos a classe `PedidoItemEntity` em `Domain/Entities/PedidoItemEntity.cs`:

```csharp
namespace AspNet.API.Domain.Entities
{
    public class PedidoItemEntity
    {
        public int ProdutoId { get; set; }
        public double Valor { get; set; }
    }
}
```

- Esta classe representa um **objeto embutido (subdocumento)**.
- Não possui chave primária própria (`Id`), pois seus dados residem internamente na lista do documento pai (`PedidoEntity`).

### 6.2. Documento Principal: `PedidoEntity`

Criamos a classe `PedidoEntity` em `Domain/Entities/PedidoEntity.cs`:

```csharp
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel.DataAnnotations.Schema;

namespace AspNet.API.Domain.Entities
{
    [Table("tb_pedido")]
    public class PedidoEntity
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public ObjectId Id { get; set; }
        public int ClienteId { get; set; }
        public string NumeroPedido { get; set; } = string.Empty;

        public ICollection<PedidoItemEntity> Itens { get; set; } = [];
    }
}
```

#### Entendendo as Anotações e Tipos:

1. **`[Table("tb_pedido")]`**:
   - Informa ao provedor do Entity Framework qual será o nome da coleção no MongoDB (neste caso, a coleção será nomeada como `tb_pedido`).
2. **`ObjectId`**:
   - Tipo de dados nativo do MongoDB (12 bytes) composto por: timestamp de 4 bytes, identificador aleatório da máquina/processo de 5 bytes e contador incremental de 3 bytes.
3. **`[BsonId]`**:
   - Mapeia a propriedade C# `Id` para o campo canônico `_id` do documento MongoDB.
4. **`[BsonRepresentation(BsonType.ObjectId)]`**:
   - Garante que a propriedade será serializada e manipulada como um `ObjectId` binário no BSON, mas passível de conversão amigável para string em consultas e APIs.
5. **`public ICollection<PedidoItemEntity> Itens { get; set; } = [];`**:
   - Representa a lista embutida de subdocumentos de itens dentro do próprio documento do pedido.

---

## 7. Contexto NoSQL: `MongoApplicationContext`

Para gerenciar o ciclo de vida e a persistência dos documentos via EF Core, criamos a classe `MongoApplicationContext` em `Infrastructure/Data/MongoApplicationContext.cs`:

```csharp
using AspNet.API.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace AspNet.API.Infrastructure.Data
{
    public class MongoApplicationContext : DbContext
    {
        public MongoApplicationContext(DbContextOptions<MongoApplicationContext> options) : base(options)
        {
            
        }

        public DbSet<PedidoEntity> Pedido { get; set; }
    }
}
```

- Herda de `Microsoft.EntityFrameworkCore.DbContext`.
- Recebe `DbContextOptions<MongoApplicationContext>` via injeção de dependência.
- Expõe a coleção de pedidos através da propriedade `DbSet<PedidoEntity> Pedido`.

---

## 8. Camada de Infraestrutura: Contratos e Repositório

### 8.1. Interface `IPedidoRepository`

Localizada em `Domain/Interfaces/IPedidoRepository.cs`, estabelece o contrato para as operações de persistência do pedido:

```csharp
using AspNet.API.Domain.Entities;

namespace AspNet.API.Domain.Interfaces
{
    public interface IPedidoRepository
    {
        (IEnumerable<PedidoEntity> data, int rowsCount) ObterTodos(int Deslocamento, int RegistroRetornado);
        PedidoEntity? Adicionar(PedidoEntity entity);
        PedidoEntity? ObterUm(string Id);

        PedidoEntity? AdicionarItem(string PedidoId, PedidoItemEntity entity);
    }
}
```

- **`ObterTodos`**: retorna uma tupla C# contendo a coleção paginada de pedidos e a quantidade total de registros.
- **`Adicionar`**: persiste um novo pedido com seus dados básicos.
- **`ObterUm`**: busca um documento a partir do identificador em formato string.
- **`AdicionarItem`**: localiza o pedido existente e inclui um novo item na sua lista de subdocumentos.

### 8.2. Implementação de `PedidoRepository`

Localizada em `Infrastructure/Data/Repositories/PedidoRepository.cs`:

```csharp
using AspNet.API.Domain.Entities;
using AspNet.API.Domain.Errors;
using AspNet.API.Domain.Interfaces;
using MongoDB.Bson;

namespace AspNet.API.Infrastructure.Data.Repositories
{
    public class PedidoRepository : IPedidoRepository
    {
        private readonly MongoApplicationContext _context;

        public PedidoRepository(MongoApplicationContext context)
        {
            _context = context;
        }

        public PedidoEntity? Adicionar(PedidoEntity entity)
        {
            try
            {
                _context.Pedido.Add(entity);
                _context.SaveChanges();

                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public PedidoEntity? AdicionarItem(string PedidoId, PedidoItemEntity entity)
        {
            try
            {
                var pedido = _context
                    .Pedido
                    .FirstOrDefault(x => x.Id == ObjectId.Parse(PedidoId));

                if (pedido is null) throw new NoContentException("Não foi encontrado o Pedido");

                pedido.Itens ??= [];

                //if (pedido.Itens is null)
                //    pedido.Itens = new List<PedidoItemEntity>();

                pedido.Itens.Add(entity);

                _context.SaveChanges();

                return pedido;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public (IEnumerable<PedidoEntity> data, int rowsCount) ObterTodos(int Deslocamento, int RegistroRetornado)
        {
            try
            {
                if (Deslocamento < 0) Deslocamento = 0;

                if (RegistroRetornado <= 0) RegistroRetornado = 30;

                var totalRegistros = _context.Pedido.Count();

                var resultado = _context
                    .Pedido
                    .OrderBy(x => x.Id)
                    .Skip(Deslocamento)
                    .Take(RegistroRetornado)
                    .ToList();

                if (!resultado.Any()) throw new NoContentException("Não foi encontrado Pedidos");

                return (resultado, totalRegistros);
            }
            catch(NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public PedidoEntity? ObterUm(string Id)
        {
            try
            {
                var pedido = _context
                    .Pedido
                    .FirstOrDefault(x => x.Id == ObjectId.Parse(Id));

                if (pedido is null) throw new NoContentException("Não foi encontrado o Pedido");

                return pedido;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
    }
}
```

#### Destaques da Implementação:

1. **Conversão de Identificador com `ObjectId.Parse(Id)`**:
   - Como o Mongo utiliza o tipo `ObjectId`, convertemos a string recebida pela rota da API para o tipo BSON equivalente para a comparação no LINQ (`x.Id == ObjectId.Parse(Id)`).
2. **Atualização de Documento Embutido (`AdicionarItem`)**:
   - O EF Core rastreia a entidade `pedido`. Ao adicionar um item à coleção `pedido.Itens.Add(entity)` e invocar `_context.SaveChanges()`, o provedor atualiza o documento correspondente na coleção do MongoDB.
3. **Tratamento Específico com `NoContentException`**:
   - Lança exceção de domínio personalizada quando o registro não é encontrado, permitindo que a camada de aplicação converta o erro no status HTTP adequado.

---

## 9. Camada de Aplicação: DTOs e Mappers

Para desacoplar a camada de apresentação das entidades de domínio e tratar a serialização do `ObjectId` como texto simples (`string`), criamos DTOs dedicados.

### 9.1. DTO de Criação: `PostPedidoDto`

Localizado em `Application/Dtos/PostPedidoDto.cs`:

```csharp
namespace AspNet.API.Application.Dtos
{
    public class PostPedidoDto
    {
        public int ClienteId { get; set; }
        public string NumeroPedido { get; set; } = string.Empty;
    }
}
```

### 9.2. DTO de Consulta: `GetPedidoDto`

Localizado em `Application/Dtos/GetPedidoDto.cs`:

```csharp
using AspNet.API.Domain.Entities;

namespace AspNet.API.Application.Dtos
{
    public class GetPedidoDto
    {
        public string Id { get; set; }
        public int ClienteId { get; set; }
        public string NumeroPedido { get; set; } = string.Empty;

        public IEnumerable<PedidoItemEntity> Itens { get; set; } = [];
    }
}
```

- Repare que a propriedade `Id` é declarada como `string` para facilitar o consumo por clientes HTTP/JSON (como React, Angular, Postman e mobile).

### 9.3. Métodos de Extensão: `PedidoMapper`

Localizado em `Application/Mappers/PedidoMapper.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Domain.Entities;

namespace AspNet.API.Application.Mappers
{
    public static class PedidoMapper
    {
        public static PedidoEntity ToPedidoEntity(this PostPedidoDto obj)
        {
            return new PedidoEntity
            {
                ClienteId = obj.ClienteId,
                NumeroPedido = obj.NumeroPedido,
            };
        }

        public static GetPedidoDto ToPedidoDto(this PedidoEntity obj)
        {
            return new GetPedidoDto
            {
                Id = obj.Id.ToString(),
                ClienteId = obj.ClienteId,
                NumeroPedido = obj.NumeroPedido,
                Itens = obj.Itens,
            };
        }
    }
}
```

- `obj.Id.ToString()` converte o `ObjectId` do MongoDB de forma segura para string hexadecimal.

---

## 10. Camada de Aplicação: Casos de Uso com `OperationResult` e HATEOAS

### 10.1. Interface `IPedidoUseCase`

Localizada em `Application/Interfaces/IPedidoUseCase.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Domain.Entities;

namespace AspNet.API.Application.Interfaces
{
    public interface IPedidoUseCase
    {
        OperationResult<PageResponseDto<GetPedidoDto>> ObterTodosPedidos(int Deslocamento, int RegistroRetornado);
        OperationResult<GetPedidoDto?> ObterUmPedido(string Id);
        OperationResult<GetPedidoDto?> AdicionarPedido(PostPedidoDto entity);

        OperationResult<GetPedidoDto?> AdicionarItemNoPedido(string PedidoId, PedidoItemEntity entity);
    }
}
```

### 10.2. Implementação de `PedidoUseCase`

Localizada em `Application/UseCases/PedidoUseCase.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Application.Interfaces;
using AspNet.API.Application.Mappers;
using AspNet.API.Domain.Entities;
using AspNet.API.Domain.Errors;
using AspNet.API.Domain.Interfaces;
using System.Net;

namespace AspNet.API.Application.UseCases
{
    public class PedidoUseCase : IPedidoUseCase
    {
        private readonly IPedidoRepository _pedidoRepository;

        public PedidoUseCase(IPedidoRepository pedidoRepository)
        {
            _pedidoRepository = pedidoRepository;
        }

        public OperationResult<GetPedidoDto?> AdicionarItemNoPedido(string PedidoId, PedidoItemEntity entity)
        {
            try
            {
                var result = _pedidoRepository.AdicionarItem(PedidoId, entity);

                return OperationResult<GetPedidoDto?>.Success(result?.ToPedidoDto(), (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<GetPedidoDto?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                return OperationResult<GetPedidoDto?>.Failure("Ocorreu um erro ao obter um pedido", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<GetPedidoDto?> AdicionarPedido(PostPedidoDto entity)
        {
            try
            {
                var result = _pedidoRepository.Adicionar(entity.ToPedidoEntity());

                return OperationResult<GetPedidoDto?>.Success(result?.ToPedidoDto(), (int)HttpStatusCode.OK);
            }
            catch (Exception)
            {
                return OperationResult<GetPedidoDto?>.Failure("Ocorreu um erro ao salvar o cliente", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<PageResponseDto<GetPedidoDto>> ObterTodosPedidos(int Deslocamento, int RegistroRetornado)
        {
            try
            {
                var result = _pedidoRepository.ObterTodos(Deslocamento, RegistroRetornado);

                var pageResponse = new PageResponseDto<GetPedidoDto>
                {
                    Items = result.data.Select(item => item.ToPedidoDto()),
                    Deslocamento = Deslocamento,
                    RegistroRetornado = RegistroRetornado,
                    TotalRegistros = result.rowsCount,
                    Links = new List<LinkDto>
                    {
                        new LinkDto($"/api/pedido?Deslocamento={Deslocamento}&RegistroRetornado={RegistroRetornado}", "self", "GET"),
                        new LinkDto("/api/pedido", "create_cliente", "POST")
                    }
                };

                return OperationResult<PageResponseDto<GetPedidoDto>>.Success(pageResponse, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            { 
                return OperationResult<PageResponseDto<GetPedidoDto>>.Failure(ex.Message, (int)HttpStatusCode.NoContent);
            }
            catch (Exception ex)
            {
                return OperationResult<PageResponseDto<GetPedidoDto>>.Failure("Ocorreu um erro ao buscar todos os pedidos", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<GetPedidoDto?> ObterUmPedido(string Id)
        {
            try
            {
                var result = _pedidoRepository.ObterUm(Id);

                return OperationResult<GetPedidoDto?>.Success(result?.ToPedidoDto(), (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<GetPedidoDto?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                return OperationResult<GetPedidoDto?>.Failure("Ocorreu um erro ao obter um pedido", (int)HttpStatusCode.BadRequest);
            }
        }
    }
}
```

#### Responsabilidades do `PedidoUseCase`:

- Centraliza a orquestração da regra de negócio.
- Encapsula as respostas com `OperationResult<T>`, padronizando o status code HTTP retornado.
- Monta o envelope paginado `PageResponseDto<GetPedidoDto>` enriquecido com links de hipermídia (HATEOAS).
- Converte exceções de ausência de conteúdo (`NoContentException`) em códigos adequados (`404 Not Found` para buscas pontuais e `204 NoContent` para listagens vazias).

---

## 11. Camada de Apresentação: `PedidoController`

Localizada em `Presentation/Controllers/PedidoController.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Application.Interfaces;
using AspNet.API.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AspNet.API.Presentation.Controllers
{
    [Authorize]
    [Route("api/pedido")]
    [ApiController]
    public class PedidoController : ControllerBase
    {
        private readonly IPedidoUseCase _pedidoUseCase;

        public PedidoController(IPedidoUseCase pedidoUseCase)
        {
            _pedidoUseCase = pedidoUseCase;
        }

        [HttpGet]
        public IActionResult Get(int Deslocamento, int RegistroRetornado)
        {
            var resultado = _pedidoUseCase.ObterTodosPedidos(Deslocamento, RegistroRetornado);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            var resultado = _pedidoUseCase.ObterUmPedido(id);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPost]
        public IActionResult Post(PostPedidoDto model)
        {
            var resultado = _pedidoUseCase.AdicionarPedido(model);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPost("{pedidoId}/item")]
        public IActionResult PostItem(string pedidoId, PedidoItemEntity model)
        {
            var resultado = _pedidoUseCase.AdicionarItemNoPedido(pedidoId, model);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }
    }
}
```

### Explicação dos Endpoints da Controller:

1. **`[Authorize]` em nível de Controller:**
   - Exige que qualquer requisição aos endpoints de pedidos envie um JWT Bearer Token válido no header `Authorization`.
2. **`GET /api/pedido?Deslocamento=0&RegistroRetornado=10`**:
   - Retorna a lista paginada de pedidos armazenados no MongoDB.
3. **`GET /api/pedido/{id}`**:
   - Retorna um pedido específico e seus respectivos itens pelo identificador do MongoDB.
4. **`POST /api/pedido`**:
   - Cria o pedido básico contendo o identificador do cliente e número do pedido.
5. **`POST /api/pedido/{pedidoId}/item`**:
   - Adiciona um subdocumento de item diretamente no array de itens do pedido identificado por `pedidoId`.

---

## 12. Injeção de Dependência no `Bootstrap.cs`

Para que o ASP.NET Core consiga resolver o `MongoApplicationContext`, o repositório e o caso de uso, configuramos o contêiner de Inversão de Controle no arquivo `Infrastructure/IoC/Bootstrap.cs`:

```csharp
public static void AddIoC(IServiceCollection services, IConfiguration configuration)
{
    // Contexto Relacional Oracle
    services.AddDbContext<ApplicationContext>(options => {
        options.UseOracle(configuration.GetConnectionString("Oracle"));
    });

    // Contexto NoSQL MongoDB (Configurando a conexão e o nome do database "Aula01")
    services.AddDbContext<MongoApplicationContext>(options => {
        options.UseMongoDB(configuration?.GetConnectionString("Mongodb") ?? "", "Aula01");
    });

    // Registro das dependências do Módulo de Pedidos (MongoDB)
    services.AddTransient<IPedidoRepository, PedidoRepository>();
    services.AddTransient<IPedidoUseCase, PedidoUseCase>();

    // Registro dos demais módulos (Usuário, Cliente, etc.)
    services.AddTransient<IUserRepository, UserRepository>();
    services.AddTransient<IUserUseCase, UserUseCase>();

    services.AddTransient<IClienteRepository, ClienteRepository>();
    services.AddTransient<IClienteUseCase, ClienteUseCase>();

    services.AddTransient<IClienteService, ClienteService>();
}
```

### Detalhes do Método `options.UseMongoDB(...)`:

```csharp
options.UseMongoDB(connectionString, databaseName);
```

- **`connectionString`**: a URL ou string de conexão do cluster/servidor Mongo configurada no `appsettings.json` (chave `ConnectionStrings:Mongodb`).
- **`databaseName`**: o nome do banco de dados a ser utilizado dentro do MongoDB (no exemplo da aula, foi utilizado `"Aula01"`).

---

## 13. Autorização Baseada em Papéis (Roles) na Prática

Na Aula 08 aprendemos como gerar o token JWT embutindo papéis de usuário através de claims:

```csharp
new Claim(ClaimTypes.Role, result.Value!.Role.ToString())
```

Na **Aula 09**, aplicamos a autorização baseada em papéis em endpoints reais da aplicação (`ClienteController`), demonstrando a granularidade do controle de acesso:

```csharp
namespace AspNet.API.Presentation.Controllers
{
    [Route("api/cliente")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly IClienteUseCase _clienteUseCase;

        public ClienteController(IClienteUseCase clienteUseCase)
        {
            _clienteUseCase = clienteUseCase;
        }

        // Apenas usuários com a Role "admin" OU "gerente" podem listar clientes
        [HttpGet]
        [Authorize(Roles = "admin,gerente")]
        [SwaggerOperation(Summary = "Lista todos os clientes")]
        public IActionResult Get(int Deslocamento, int RegistroRetornado)
        {
            var resultado = _clienteUseCase.ObterTodosClientes(Deslocamento, RegistroRetornado);
            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);
            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        // Apenas usuários com a Role "admin" podem cadastrar novos clientes
        [HttpPost]
        [Authorize(Roles = "admin")]
        [SwaggerOperation(Summary = "Adicionar cliente")]
        public IActionResult Post(ClienteDto model)
        {
            var resultado = _clienteUseCase.AdicionarCliente(model);
            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);
            return StatusCode(resultado.StatusCode, resultado.Value);
        }
    }
}
```

### Comportamento dos Status Codes:

- **Usuário Anônimo (sem token):** recebe status `401 Unauthorized`.
- **Usuário Autenticado como `user` (não possui as roles `admin` ou `gerente`):** recebe status `403 Forbidden`.
- **Usuário Autenticado como `gerente`:** acessa o `GET /api/cliente`, mas recebe `403 Forbidden` ao tentar `POST /api/cliente`.
- **Usuário Autenticado como `admin`:** tem acesso completo a ambos os métodos.

---

## 14. Exemplos Práticos de Requisição e Resposta

### 14.1. Criando um Novo Pedido

**Requisição:**
`POST /api/pedido`  
**Header:** `Authorization: Bearer <seu_token_jwt>`  
**Body:**
```json
{
  "clienteId": 10,
  "numeroPedido": "PED-2026-001"
}
```

**Resposta (`200 OK`):**
```json
{
  "id": "671fb2c58e72c845b91b9a21",
  "clienteId": 10,
  "numeroPedido": "PED-2026-001",
  "itens": []
}
```

---

### 14.2. Adicionando um Item ao Pedido

**Requisição:**
`POST /api/pedido/671fb2c58e72c845b91b9a21/item`  
**Header:** `Authorization: Bearer <seu_token_jwt>`  
**Body:**
```json
{
  "produtoId": 102,
  "valor": 89.90
}
```

**Resposta (`200 OK`):**
```json
{
  "id": "671fb2c58e72c845b91b9a21",
  "clienteId": 10,
  "numeroPedido": "PED-2026-001",
  "itens": [
    {
      "produtoId": 102,
      "valor": 89.9
    }
  ]
}
```

---

### 14.3. Listando Pedidos com Paginação e Hipermídia (HATEOAS)

**Requisição:**
`GET /api/pedido?Deslocamento=0&RegistroRetornado=10`  
**Header:** `Authorization: Bearer <seu_token_jwt>`  

**Resposta (`200 OK`):**
```json
{
  "items": [
    {
      "id": "671fb2c58e72c845b91b9a21",
      "clienteId": 10,
      "numeroPedido": "PED-2026-001",
      "itens": [
        {
          "produtoId": 102,
          "valor": 89.9
        }
      ]
    }
  ],
  "deslocamento": 0,
  "registroRetornado": 10,
  "totalRegistros": 1,
  "links": [
    {
      "href": "/api/pedido?Deslocamento=0&RegistroRetornado=10",
      "rel": "self",
      "method": "GET"
    },
    {
      "href": "/api/pedido",
      "rel": "create_cliente",
      "method": "POST"
    }
  ]
}
```

---

## 15. Resumo das Práticas e Arquitetura da Aula 09

| Componente | Camada | Tecnologia / Padrão | Finalidade |
| :--- | :--- | :--- | :--- |
| `MongoDB.EntityFrameworkCore` | Infrastructure | EF Core NoSQL Provider | Permite consultar e persistir documentos MongoDB usando `DbContext` e LINQ |
| `MongoApplicationContext` | Infrastructure | `DbContext` | Contexto dedicado para as coleções NoSQL do MongoDB |
| `Update-Database -Context ApplicationContext` | Tooling CLI | EF Core Migrations | Evita ambiguidade ao rodar comandos de migração em projetos multi-contexto |
| `PedidoEntity` e `PedidoItemEntity` | Domain | BSON / NoSQL Entities | Modela o agregado de pedidos com documentos embutidos (subdocumentos) |
| `IPedidoRepository` / `PedidoRepository` | Domain / Infrastructure | Repository Pattern | Encapsula o acesso a dados e consultas ao MongoDB |
| `IPedidoUseCase` / `PedidoUseCase` | Application | Use Case Pattern | Aplica regras de negócio, padroniza retornos com `OperationResult` e HATEOAS |
| `PedidoController` | Presentation | ASP.NET Core API Controller | Expõe os endpoints RESTful para manipulação de pedidos |
| `[Authorize(Roles = "...")]` | Presentation | Role-Based Authorization | Protege endpoints restringindo acesso a papéis específicos (`admin`, `gerente`) |

