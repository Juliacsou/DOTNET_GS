
**Tópicos Abordados**

- Adicioar no Repository o lancamento do erro
- Refatorar controller (Remover application context)
- Chamada de serviços externos
- Aplicar a PageResult
- Hateaos


## 1. Tratamento de Exceções no Repository com `NoContentException`

Ao trabalhar com **Clean Architecture**, as exceções lançadas pelas camadas inferiores (como a camada de Infraestrutura e Repositório) devem ser semânticas e previsíveis para que as camadas superiores (Casos de Uso) possam capturá-las e traduzi-las no código de status HTTP correto.

### O Problema do `catch (Exception ex)` Genérico

Quando lançamos uma exceção de domínio como `NoContentException` dentro de um bloco `try`, mas possuímos apenas um bloco genérico `catch (Exception ex)`, a exceção customizada é capturada por ele e reempacotada como uma `System.Exception` genérica:

```csharp
// PROBLEMA: A exceção NoContentException é mascarada como Exception genérica
try
{
    var cliente = _context.Cliente.FirstOrDefault(x => x.Id == Id);
    if (cliente is null) 
        throw new NoContentException("Não foi encontrado o cliente");
    
    return cliente;
}
catch (Exception ex)
{
    // NoContentException cai aqui e é reempacotada!
    throw new Exception(ex.Message, ex);
}
```

Ao fazer isso, a camada de aplicação (`ClienteUseCase`) nunca conseguirá capturar `catch (NoContentException ex)`. Como consequência, o erro será tratado como uma falha genérica de sistema (resultando em HTTP 400 Bad Request ou 500 Internal Server Error), em vez de um HTTP 404 (Not Found) ou HTTP 204 (No Content).

### A Solução: Captura Específica de `NoContentException`

Para preservar o tipo da exceção e permitir que ela chegue intacta aos casos de uso, adicionamos um bloco `catch (NoContentException ex)` antes do `catch (Exception ex)` genérico, relançando a exceção sem convertê-la.

#### Estrutura de Diretórios:

```css
AspNet.API
├── Domain
│   └── Errors
│       └── NoContentException.cs
└── Infrastructure
    └── Data
        └── Repositories
            └── ClienteRepository.cs
```

#### Classe `NoContentException`:

Localizada em `Domain/Errors/NoContentException.cs`:

```csharp
namespace AspNet.API.Domain.Errors
{
    public class NoContentException : Exception
    {
        public NoContentException()
        {
        }

        public NoContentException(string? message) : base(message)
        {
        }
    }
}
```

#### Ajustando o `ClienteRepository`:

Em `Infrastructure/Data/Repositories/ClienteRepository.cs`, todos os métodos que validam existência de registros agora capturam e relançam a `NoContentException` especificamente:

```csharp
public ClienteEntity? ObterUm(int Id)
{
    try
    {
        var cliente = _context
            .Cliente
            .Include(x => x.Estado)
            .Include(x => x.Produtos)
            .Include(x => x.Cursos)
            .FirstOrDefault(x => x.Id == Id);

        if (cliente is null) 
            throw new NoContentException("Não foi encontrado o cliente");

        return cliente;
    }
    catch (NoContentException ex)
    {
        throw new NoContentException(ex.Message);
    }
    catch (Exception ex)
    {
        throw new Exception(ex.Message, ex);
    }
}

public ClienteEntity? Deletar(int Id)
{
    try
    {
        var cliente = _context.Cliente.FirstOrDefault(x => x.Id == Id);

        if (cliente is null) 
            throw new NoContentException("Não foi encontrado o cliente");

        _context.Cliente.Remove(cliente);
        _context.SaveChanges();

        return cliente;
    }
    catch (NoContentException ex)
    {
        throw new NoContentException(ex.Message);
    }
    catch (Exception ex)
    {
        throw new Exception(ex.Message, ex);
    }
}

public ClienteEntity? Editar(int Id, ClienteEntity entity)
{
    try
    {
        var cliente = _context
            .Cliente
            .Include(x => x.Estado)
            .FirstOrDefault(x => x.Id == Id);

        if (cliente is null) 
            throw new NoContentException("Não foi encontrado o cliente");

        cliente.Nome = entity.Nome;
        cliente.Email = entity.Email;
        cliente.Idade = entity.Idade;

        if (cliente.Estado is null)
        {
            cliente.Estado = new EstadoEntity
            {
                Nome = entity.Estado.Nome
            };
        }
        else
            cliente.Estado.Nome = entity.Estado.Nome;

        _context.Cliente.Update(cliente);
        _context.SaveChanges();

        return cliente;
    }
    catch (NoContentException ex)
    {
        throw new NoContentException(ex.Message);
    }
    catch (Exception ex)
    {
        throw new Exception(ex.Message, ex);
    }
}
```

#### Tratamento na Camada de Aplicação (`ClienteUseCase`):

Com a exceção preservada, o caso de uso consegue diferenciar o erro de negócio da falha de infraestrutura:

```csharp
public OperationResult<ClienteEntity?> ObterUmCliente(int Id)
{
    try
    {
        _logger.LogInformation("ObterUmCliente iniciado na application");
        var result = _clienteRepository.ObterUm(Id);

        return OperationResult<ClienteEntity?>.Success(result, (int)HttpStatusCode.OK);
    }
    catch (NoContentException ex)
    {
        _logger.LogWarning("Nao retornou nenhuma informação do ObterUmCliente - Parametros: ID: {0}", Id);
        return OperationResult<ClienteEntity?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
    }
    catch (Exception ex)
    {
        _logger.LogError("[ERROR] - {0}", ex.Message);
        return OperationResult<ClienteEntity?>.Failure("Ocorreu um erro ao obter um cliente", (int)HttpStatusCode.BadRequest);
    }
}
```

---

## 2. Refatorando a Controller de Cliente

Um dos pilares do Clean Architecture é a **separação estrita de responsabilidades**. A camada de apresentação (Controllers) deve ser o mais enxuta possível (*thin controller*), agindo apenas como orquestradora HTTP: recebe parâmetros, chama o caso de uso e retorna o código HTTP apropriado.

### O Problema Anterior

Nas versões anteriores da controller:
- Ela injetava diretamente o `ApplicationContext` (DbContext).
- Executava consultas de banco diretamente nos métodos da Controller (como `GetListaMaiorDeIdade()`), violando o encapsulamento do domínio e da infraestrutura.
- Injetava `ILogger<ClienteController>` com código repetitivo de log e blocos `try/catch` redundantes.

### A Solução Aplicada

1. **Remoção do `ApplicationContext` e `ILogger`**: A controller passa a injetar exclusivamente a abstração `IClienteUseCase`.
2. **Transferência de Lógica de Consulta**: A busca de clientes maiores de idade foi movida para o repositório (`ObterTodosMaioresDeIdade`) e caso de uso (`ObterTodosClientesMaioresDeIdadeClientes`).
3. **Padronização das Respostas com `OperationResult`**: A controller apenas lê o `OperationResult` e devolve a resposta HTTP baseando-se em `resultado.StatusCode`.

#### Atualizando o `IClienteRepository` e `ClienteRepository`:

Em `Domain/Interfaces/IClienteRepository.cs`:

```csharp
IEnumerable<ClienteEntity> ObterTodosMaioresDeIdade(int idade);
```

Em `Infrastructure/Data/Repositories/ClienteRepository.cs`:

```csharp
public IEnumerable<ClienteEntity> ObterTodosMaioresDeIdade(int idade)
{
    try
    {
        var resultado = _context
            .Cliente
            .Where(x => x.Idade >= idade)
            .ToList();

        if (!resultado.Any()) 
            throw new NoContentException("Não foi encontrado clientes");

        return resultado;
    }
    catch (NoContentException ex)
    {
        throw new NoContentException(ex.Message);
    }
    catch (Exception ex)
    {
        throw new Exception(ex.Message, ex);
    }
}
```

#### Atualizando o `IClienteUseCase` e `ClienteUseCase`:

Em `Application/Interfaces/IClienteUseCase.cs`:

```csharp
OperationResult<IEnumerable<ClienteEntity>> ObterTodosClientesMaioresDeIdadeClientes(int idade);
```

Em `Application/UseCases/ClienteUseCase.cs`:

```csharp
public OperationResult<IEnumerable<ClienteEntity>> ObterTodosClientesMaioresDeIdadeClientes(int idade)
{
    try
    {
        _logger.LogInformation("ObterTodosClientesMaioresDeIdadeClientes iniciado na application");

        var result = _clienteRepository.ObterTodosMaioresDeIdade(idade);

        return OperationResult<IEnumerable<ClienteEntity>>.Success(result, (int)HttpStatusCode.OK);
    }
    catch (NoContentException ex)
    {
        return OperationResult<IEnumerable<ClienteEntity>>.Failure(ex.Message, (int)HttpStatusCode.NoContent);
    }
    catch (Exception ex)
    {
        _logger.LogError(ex.Message);
        return OperationResult<IEnumerable<ClienteEntity>>.Failure("Ocorreu um erro ao buscar clientes maior de idade", (int)HttpStatusCode.BadRequest);
    }
}
```

#### Controller Refatorada (`ClienteController.cs`):

Localizada em `Presentation/Controllers/ClienteController.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Application.Interfaces;
using AspNet.API.Doc.Samples;
using AspNet.API.Domain.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Swashbuckle.AspNetCore.Annotations;
using Swashbuckle.AspNetCore.Filters;

namespace AspNet.API.Presentation.Controllers
{
    [Route("api/cliente")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly IClienteUseCase _clienteUseCase;

        public ClienteController(IClienteUseCase clienteUseCase)
        {
            _clienteUseCase = clienteUseCase;
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Lista todos os clientes")]
        [SwaggerResponse(statusCode: 200, description: "Dados do cliente listado com sucesso", type: typeof(IEnumerable<ClienteEntity>))]
        [SwaggerResponse(statusCode: 204, description: "Nao possui dados do cliente")]
        [SwaggerResponse(statusCode: 400, description: "Ocorreu um erro ao listar os clientes", type: typeof(string))]
        [SwaggerResponseExample(statusCode: 200, typeof(ClienteResponseListSample))]
        [EnableRateLimiting("politica_5_tentativas")]
        public IActionResult Get(int Deslocamento, int RegistroRetornado)
        {
            var resultado = _clienteUseCase.ObterTodosClientes(Deslocamento, RegistroRetornado);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpGet("{id}")]
        [SwaggerOperation(Summary = "Obter um cliente")]
        [SwaggerResponse(statusCode: 200, description: "Dados do cliente retornado com sucesso", type: typeof(ClienteEntity))]
        [SwaggerResponse(statusCode: 404, description: "Nao encontrado dados para o cliente")]
        [SwaggerResponseExample(statusCode: 200, typeof(ClienteResponseSample))]
        public IActionResult Get(int id)
        {
            var resultado = _clienteUseCase.ObterUmCliente(id);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpGet("maior/idade")]
        [SwaggerOperation(Summary = "Lista todos os clientes maiores de idade")]
        public IActionResult GetListaMaiorDeIdade()
        {
            var resultado = _clienteUseCase.ObterTodosClientesMaioresDeIdadeClientes(18);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Adicionar cliente")]
        [SwaggerRequestExample(typeof(ClienteEntity), typeof(ClienteRequestSample))]
        [SwaggerResponse(statusCode: 200, description: "Dados do cliente cadastrado com sucesso", type: typeof(ClienteEntity))]
        [SwaggerResponseExample(statusCode: 200, typeof(ClienteResponseSample))]
        public IActionResult Post(PostClienteDto model)
        {
            var resultado = _clienteUseCase.AdicionarCliente(model);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPut("{id}")]
        [SwaggerOperation(Summary = "Editar cliente")]
        public IActionResult Put([FromRoute, SwaggerParameter("Id do cliente!")] int id, PostClienteDto model)
        {
            var resultado = _clienteUseCase.EditarCliente(id, model);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpDelete("{id}")]
        [SwaggerOperation(Summary = "Deletar cliente")]
        public IActionResult Delete(int id)
        {
            var resultado = _clienteUseCase.DeletarCliente(id);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPost("produto/cliente/{clienteId}")]
        [SwaggerOperation(Summary = "Adicionar produto")]
        public IActionResult PostProduto(int clienteId, PostProdutoDto model)
        {
            var resultado = _clienteUseCase.AdicionarProdutoNoCliente(model, clienteId);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPut("produto/{id}/cliente/{clienteId}")]
        [SwaggerOperation(Summary = "Editar produto")]
        public IActionResult PutProduto(int id, int clienteId, PostProdutoDto model)
        {
            var resultado = _clienteUseCase.EditarProdutoNoCliente(model, id, clienteId);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPost("curso/cliente/{clienteId}")]
        [SwaggerOperation(Summary = "Adicionar curso")]
        public IActionResult PostCurso(int clienteId, PostCursoDto model)
        {
            var resultado = _clienteUseCase.AdicionarCursoNoCliente(model, clienteId);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPut("curso/{cursoId}/cliente")]
        [SwaggerOperation(Summary = "Editar curso")]
        public IActionResult PutCurso(int cursoId, PostCursoDto model)
        {
            var resultado = _clienteUseCase.EditarCursoNoCliente(model, cursoId);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }
    }
}
```

---

## 3. Chamada de Serviços Externos (`IClienteService`)

Aplicações corporativas necessitam frequentemente se comunicar com serviços web externos (APIs REST terceiras ou de outros domínios). Para manter o desacoplamento, a interface da comunicação pertence ao **Domain**, enquanto a implementação concreta com o cliente HTTP pertence à **Infrastructure**.

Nesta aula, realizamos a integração com a API pública do **ViaCEP** (`https://viacep.com.br/ws/`) para busca assíncrona de endereços a partir de um CEP.

### Instalação do Pacote `RestSharp`

Utilizamos o pacote `RestSharp` para simplificar requisições HTTP RESTful. No arquivo de projeto `AspNet.API.csproj`:

```xml
<PackageReference Include="RestSharp" Version="114.0.0" />
```

### Estrutura de Diretórios:

```css
AspNet.API
├── Domain
│   ├── Entities
│   │   └── EnderecoModel.cs
│   └── Interfaces
│       └── IClienteService.cs
└── Infrastructure
    ├── Service
    │   └── ClienteService.cs
    └── IoC
        └── Bootstrap.cs
```

### 1. Criando a Entidade `EnderecoModel`

Localizada em `Domain/Entities/EnderecoModel.cs`:

```csharp
namespace AspNet.API.Domain.Entities
{
    public class EnderecoModel
    {
        public string Cep { get; set; }
        public string Logradouro { get; set; }
        public string Bairro { get; set; }
        public string Uf { get; set; }
    }
}
```

### 2. Criando a Interface `IClienteService`

Localizada em `Domain/Interfaces/IClienteService.cs`:

```csharp
using AspNet.API.Domain.Entities;

namespace AspNet.API.Domain.Interfaces
{
    public interface IClienteService
    {
        Task<EnderecoModel?> ObterEnderecoPorCepAsync(string cep);
    }
}
```

### 3. Implementando o `ClienteService` com `RestSharp`

Localizada em `Infrastructure/Service/ClienteService.cs`:

```csharp
using AspNet.API.Domain.Entities;
using AspNet.API.Domain.Errors;
using AspNet.API.Domain.Interfaces;
using RestSharp;

namespace AspNet.API.Infrastructure.Service
{
    public class ClienteService : IClienteService
    {
        private readonly ILogger<ClienteService> _logger;
        private readonly RestClient _restClient;

        public ClienteService(ILogger<ClienteService> logger)
        {
            _logger = logger;
            _restClient = new RestClient("https://viacep.com.br/ws/");
        }

        public async Task<EnderecoModel?> ObterEnderecoPorCepAsync(string cep)
        {
            var request = new RestRequest($"{cep}/json/", Method.Get);
            var response = await _restClient.ExecuteAsync<EnderecoModel>(request);

            if (!response.IsSuccessful || response.Data == null)
                throw new NoContentException($"Não foi localizado o endereco para esta cep: {cep}");

            return response.Data;
        }
    }
}
```

### 4. Registrando a Injeção de Dependência no `Bootstrap.cs`

Em `Infrastructure/IoC/Bootstrap.cs`, registramos a interface e a implementação:

```csharp
public static void AddIoC(IServiceCollection services, IConfiguration configuration)
{
    services.AddDbContext<ApplicationContext>(options => {
        options.UseOracle(configuration.GetConnectionString("Oracle"));
    });

    services.AddTransient<IClienteRepository, ClienteRepository>();
    services.AddTransient<IClienteUseCase, ClienteUseCase>();
    services.AddTransient<IClienteService, ClienteService>();
}
```

### 5. Integrando no `ClienteUseCase`

Injetamos o `IClienteService` no construtor do `ClienteUseCase` e implementamos o método `ObterEnderecoPorCepAsync`:

```csharp
public class ClienteUseCase : IClienteUseCase
{
    private readonly ILogger<ClienteUseCase> _logger;
    private readonly IClienteRepository _clienteRepository;
    private readonly IClienteService _clienteService;

    public ClienteUseCase(
        IClienteRepository clienteRepository, 
        ILogger<ClienteUseCase> logger, 
        IClienteService clienteService)
    {
        _clienteService = clienteService;
        _clienteRepository = clienteRepository;
        _logger = logger;
    }

    // ... outros métodos ...

    public async Task<OperationResult<EnderecoModel?>> ObterEnderecoPorCepAsync(string cep)
    {
        try
        {
            var result = await _clienteService.ObterEnderecoPorCepAsync(cep);

            return OperationResult<EnderecoModel?>.Success(result, (int)HttpStatusCode.OK);
        }
        catch (NoContentException ex)
        {
            return OperationResult<EnderecoModel?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
        }
        catch (Exception)
        {
            return OperationResult<EnderecoModel?>.Failure("Ocorreu um erro ao buscar o cep", (int)HttpStatusCode.BadRequest);
        }
    }
}
```

### 6. Endpoint na `ClienteController`

Adicionamos a rota `GET api/cliente/endereco/{cep}` na controller:

```csharp
[HttpGet("endereco/{cep}")]
[SwaggerOperation(Summary = "Obter um endereco por cep")]
[SwaggerResponse(statusCode: 200, description: "Dados do endeco retornado com sucesso", type: typeof(EnderecoModel))]
[SwaggerResponse(statusCode: 404, description: "Nao encontrado dados para o cep informado")]
public async Task<IActionResult> GetEnderecoPorCep(string cep)
{
    var resultado = await _clienteUseCase.ObterEnderecoPorCepAsync(cep);

    if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

    return StatusCode(resultado.StatusCode, resultado.Value);
}
```

#### Exemplo de Resposta JSON da API:

```json
{
  "cep": "01001-000",
  "logradouro": "Praça da Sé",
  "bairro": "Sé",
  "uf": "SP"
}
```

---

## 4. Paginação com `PageResponseDto<T>`

Ao listar dados em aplicações reais, nunca devemos trazer todos os registros de uma só vez, pois isso gera degradação de performance no banco de dados e sobrecarga na rede.

A paginação é composta por:
- **Deslocamento (Offset / Skip)**: Quantidade de registros a serem ignorados no início da consulta.
- **RegistroRetornado (Limit / Take)**: Quantidade máxima de registros a serem trazidos na página.
- **TotalRegistros (TotalCount)**: Quantidade total de registros existentes na tabela.

### 1. Criando o `PageResponseDto<T>`

Localizado em `Application/Dtos/PageResponseDto.cs`:

```csharp
namespace AspNet.API.Application.Dtos
{
    public class PageResponseDto<T>
    {
        public IEnumerable<T> Items { get; set; } = new List<T>();
        public int Deslocamento { get; set; }
        public int RegistroRetornado { get; set; }
        public int TotalRegistros { get; set; }

        public List<LinkDto> Links { get; set; } = new();
    }
}
```

### 2. Ajustando o Repositório com Retorno de Tupla C#

Para retornar tanto a lista paginada quanto a quantidade total de registros da tabela sem criar uma classe extra apenas para essa consulta interna, utilizamos o recurso de **Tuplas Nomeadas do C#** `(IEnumerable<ClienteEntity> data, int rowsCount)`.

#### Em `Domain/Interfaces/IClienteRepository.cs`:

```csharp
(IEnumerable<ClienteEntity> data, int rowsCount) ObterTodos(int Deslocamento, int RegistroRetornado);
```

#### Em `Infrastructure/Data/Repositories/ClienteRepository.cs`:

```csharp
public (IEnumerable<ClienteEntity> data, int rowsCount) ObterTodos(int Deslocamento = 0, int RegistroRetornado = 30)
{
    try
    {
        if (Deslocamento < 0) Deslocamento = 0;
        if (RegistroRetornado <= 0) RegistroRetornado = 30;

        // Conta a quantidade total de registros na base
        var totalRegistros = _context.Cliente.Count();

        // Aplica ordenação e paginação com Skip e Take
        var resultado = _context
            .Cliente
            .Include(x => x.Estado)
            .Include(x => x.Produtos)
            .Include(x => x.Cursos)
            .OrderBy(x => x.Id)
            .Skip(Deslocamento)
            .Take(RegistroRetornado)
            .ToList();

        if (!resultado.Any()) 
            throw new NoContentException("Não foi encontrado clientes");

        return (resultado, totalRegistros);
    }
    catch (NoContentException ex)
    {
        throw new NoContentException(ex.Message);
    }
    catch (Exception ex)
    {
        throw new Exception(ex.Message, ex);
    }
}
```

---

## 5. HATEOAS com `PageResponseDto`

**HATEOAS (Hypermedia as the Engine of Application State)** é o princípio REST onde a API fornece, junto aos dados solicitados, links de hipermídia descrevendo as ações e navegações disponíveis para o recurso.

No contexto de endpoints paginados, o HATEOAS orienta o cliente sobre como acessar a própria consulta atual (`self`), bem como recursos relacionados (por exemplo, cadastrar um novo cliente via `POST`).

### 1. Criando o `LinkDto`

Localizado em `Application/Dtos/LinkDto.cs`:

```csharp
namespace AspNet.API.Application.Dtos
{
    public class LinkDto
    {
        public string Href { get; set; } = string.Empty;
        public string Rel { get; set; } = string.Empty;
        public string Method { get; set; } = "GET";

        public LinkDto(string href, string rel, string method = "GET")
        {
            Href = href;
            Rel = rel;
            Method = method;
        }
    }
}
```

- **`Href`**: URL ou caminho do endpoint.
- **`Rel`**: Relação do link com o recurso atual (ex: `"self"`, `"create_cliente"`).
- **`Method`**: Verbo HTTP a ser utilizado pelo cliente (`GET`, `POST`, `PUT`, `DELETE`).

### 2. Construindo a Resposta Paginada com HATEOAS no `ClienteUseCase`

No método `ObterTodosClientes` da classe `ClienteUseCase`:

```csharp
public OperationResult<PageResponseDto<ClienteEntity>> ObterTodosClientes(int Deslocamento, int RegistroRetornado)
{
    try
    {
        _logger.LogInformation("ObterTodos iniciado na application");
        var result = _clienteRepository.ObterTodos(Deslocamento, RegistroRetornado);

        var pageResponse = new PageResponseDto<ClienteEntity> 
        {
            Items = result.data,
            Deslocamento = Deslocamento,
            RegistroRetornado = RegistroRetornado,
            TotalRegistros = result.rowsCount,
            Links = new List<LinkDto> 
            {
                new LinkDto($"/api/cliente?Deslocamento={Deslocamento}&RegistroRetornado={RegistroRetornado}", "self", "GET"),
                new LinkDto("/api/cliente", "create_cliente", "POST")
            }
        };

        return OperationResult<PageResponseDto<ClienteEntity>>.Success(pageResponse, (int)HttpStatusCode.OK);
    }
    catch (NoContentException ex)
    {
        _logger.LogWarning("Nao retornou nenhuma informação do ObterTodos - Parametros: D: {0} - R: {1}", Deslocamento, RegistroRetornado);
        return OperationResult<PageResponseDto<ClienteEntity>>.Failure(ex.Message, (int)HttpStatusCode.NoContent);
    }
    catch (Exception ex)
    {
        _logger.LogError("[ERROR] - {0}", ex.Message);
        return OperationResult<PageResponseDto<ClienteEntity>>.Failure("Ocorreu um erro ao buscar todos os clientes", (int)HttpStatusCode.BadRequest);
    }
}
```

### 3. Exemplo do Retorno JSON Formatado com Paginação e HATEOAS

Ao fazer uma requisição para `GET /api/cliente?Deslocamento=0&RegistroRetornado=2`:

```json
{
  "items": [
    {
      "id": 1,
      "nome": "João da Silva",
      "email": "joao@email.com",
      "idade": 25,
      "estado": {
        "id": 1,
        "nome": "SP"
      },
      "produtos": [],
      "cursos": []
    },
    {
      "id": 2,
      "nome": "Maria Santos",
      "email": "maria@email.com",
      "idade": 30,
      "estado": {
        "id": 2,
        "nome": "RJ"
      },
      "produtos": [],
      "cursos": []
    }
  ],
  "deslocamento": 0,
  "registroRetornado": 2,
  "totalRegistros": 15,
  "links": [
    {
      "href": "/api/cliente?Deslocamento=0&RegistroRetornado=2",
      "rel": "self",
      "method": "GET"
    },
    {
      "href": "/api/cliente",
      "rel": "create_cliente",
      "method": "POST"
    }
  ]
}
```