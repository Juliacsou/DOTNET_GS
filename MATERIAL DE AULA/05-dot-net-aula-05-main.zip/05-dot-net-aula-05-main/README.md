**Tópicos Abordados**

- Logging
- Health Check
- Trancing/Metricas - Aplication Insigths

### Logging

 _Logging_ em APIs ASP.NET é um dos pilares fundamentais para construir aplicações profissionais, observáveis e de fácil manutenção. O log funciona como um **sistema de registro contínuo dos eventos significativos** que ocorrem dentro da aplicação sejam eles erros, requisições, warnings ou informações de diagnóstico.

Alguns motivos por que logging é importante:

- Diagnosticar problemas em produção: quando um erro ocorre, sem logs muitas vezes ficamos “às cegas”.
- Entender o comportamento e fluxo da aplicação: ler os logs nos ajuda a saber o que está acontecendo (requests, respostas, tempo, falhas).
- Auditoria, rastreamento e conformidade: em ambientes críticos precisamos ter trilha de quem fez o que, quando e como.
- Observabilidade (além de métricas/traces): logs complementam métricas e traces para formar visão completa.

No ASP.NET, o logging é suportado nativamente via o namespace `Microsoft.Extensions.Logging`. 

Mas também há práticas recomendadas, bibliotecas externas (como Serilog) que enriquecem os logs com formatação, destinos (sinks) e estrutura (“structured logging”).   

#### Níveis de Logs

O _logging_ é um subsistema integrado ao framework que permite registrar eventos através de um pipeline padronizado, desacoplado e extensível.

O conceito central desse sistema é a interface **`ILogger<T>`**, injetada por _Dependency Injection_, permitindo registrar informações dentro dos controllers, services, repositories ou qualquer outra camada.

O objetivo principal é permitir ao programador capturar e registrar acontecimentos importantes usando níveis de severidade, tais como:

- **Trace** – extremamente detalhado; útil apenas para depuração profunda    
- **Debug** – informações de desenvolvimento
- **Information** – eventos comuns do sistema
- **Warning** – algo inesperado, mas que não quebra a aplicação
- **Error** – erros que não impedem o sistema de continuar
- **Critical** – falhas graves que podem derrubar a aplicação

#### Configurando os Logs

No arquivo `appsettings.json` temos as configurações e níveis dos logs gerados.

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

Isso significa que, por padrão, registramos logs de nível “Information” ou superior, e para categorias sob “Microsoft.AspNetCore” apenas “Warning” ou superior.

#### Usando ILogger em um Controller

Para adicionar o `ILogger` no projeto, basta adicionar a interface no construtor da controller ou qualquer classe que queria registrar logs.

```csharp
[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
	// Interface ILogger
    private readonly ILogger<ProductsController> _logger;

    public ProductsController(ILogger<ProductsController> logger)
	
	....    
}
```

Observe que a interface `ILogger` está sendo inicializada com o tipo `ProductsController` como parâmetro. Isso indica ao mecanismo de logging qual classe está associada aos registros gerados. Dessa forma, cada entrada de log é automaticamente categorizada com o nome da controller, facilitando a identificação da origem das mensagens durante depurações, auditorias ou análises de comportamento da aplicação.

##### Definindo os logs no método `GetById`:

Veja que, para cada tipo de informação registrada, utilizamos um método específico da classe `Logger`. Cada um deles representa um nível de severidade distinto:

- **LogInformation**: utilizado para registrar informações gerais sobre o funcionamento da aplicação, como etapas de processamento ou confirmações de execução.
- **LogWarning**: destinado a avisos importantes que não interrompem a aplicação, mas indicam situações potencialmente problemáticas.
- **LogError**: empregado para registrar erros que ocorreram durante a execução, facilitando a identificação e correção de falhas.

Essa categorização permite uma análise mais precisa dos eventos registrados e contribui para um monitoramento mais eficiente do sistema.

```csharp
[HttpGet("{id}")]
public async Task<IActionResult> GetById(int id)
{
	_logger.LogInformation("Getting product with id {ProductId}", id);

	try
	{
		var product = await _service.GetByIdAsync(id);
		if (product == null)
		{
			_logger.LogWarning("Product with id {ProductId} not found", id);
			return NotFound();
		}

		_logger.LogInformation("Product retrieved successfully: {ProductId}", id);
		return Ok(product);
	}
	catch (Exception ex)
	{
		_logger.LogError(ex, "Error retrieving product with id {ProductId}", id);
		throw; // ou return algum erro estruturado
	}
}
```

##### Exemplo completo:

```csharp
[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private readonly ILogger<ProductsController> _logger;
    private readonly IProductService _service;

    public ProductsController(ILogger<ProductsController> logger, IProductService service)
    {
        _logger = logger;
        _service = service;
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        _logger.LogInformation("Getting product with id {ProductId}", id);

        try
        {
            var product = await _service.GetByIdAsync(id);
            if (product == null)
            {
                _logger.LogWarning("Product with id {ProductId} not found", id);
                return NotFound();
            }

            _logger.LogInformation("Product retrieved successfully: {ProductId}", id);
            return Ok(product);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving product with id {ProductId}", id);
            throw; // ou return algum erro estruturado
        }
    }
}
```

#### Usando ILogger na camada de Aplicação (Application)

Da mesma forma que utilizamos logs nas controllers, também podemos aplicá-los em qualquer ponto da arquitetura. Isso inclui a camada de aplicação, onde o uso de logging é essencial para acompanhar regras de negócio, fluxos internos e comportamento dos casos de uso.

A seguir, apresentamos uma forma recomendada de implementar o mecanismo de logging dentro da camada de aplicação, garantindo rastreabilidade, padronização das mensagens e melhor capacidade de diagnóstico durante a execução da aplicação.

```csharp
public class ProductUseCase : IProductUseCase  
{  
    ILogger<ProductUseCase> _logger;  
  
    public ProductUseCase(ILogger<ProductUseCase> logger)  
    {  
        _logger = logger;  
    }  
  
    public Task<ProductDto> ObterPorIdAsync(int Id)  
    {  
        try  
        {  
            _logger.LogInformation("Obtendo o produto {ProductId} do repository", Id);  
  
            return Task.FromResult(new ProductDto(Id, "Nome do Produto"));  
        }  
        catch (Exception ex)  
        {  
            _logger.LogError(ex, "Ocorreu um erro para obter o produto {ProductId}", Id);  
            throw;  
        }  
    }  
}
```

#### Habilitando o Serilog

Instando a dependencia para salvar os logs no disco.

```bash
dotnet add package Serilog.AspNetCore
```

Configurando e habilitando o Serilog

```csharp
var builder = WebApplication.CreateBuilder(args);

Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .WriteTo.File(
        path: Path.Combine(AppContext.BaseDirectory, "logs", "api-.log"),
        rollingInterval: RollingInterval.Day,
        retainedFileCountLimit: 7,
        outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {SourceContext}{NewLine}    {Message:lj}{NewLine}{Exception}")
    .CreateLogger();

builder.Services.AddSerilog();
```

| Configuração                                                            | O que faz                                                                                    | Exemplo / Resultado                                                                                 |
| ----------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| `Log.Logger`                                                            | Define o logger global do Serilog que será utilizado pela aplicação.                         | `Log.Logger = new LoggerConfiguration()`                                                            |
| `new LoggerConfiguration()`                                             | Inicia a construção da configuração do Serilog.                                              | Permite configurar níveis, destinos, formato etc.                                                   |
| `.MinimumLevel.Information()`                                           | Define o nível mínimo global dos logs. Registra `Information`, `Warning`, `Error` e `Fatal`. | `Log.Information(...)` será registrado; `Log.Debug(...)` não.                                       |
| `.MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)` | Define um nível mínimo específico para logs gerados pelo ASP.NET Core.                       | Logs `Information` do `Microsoft.AspNetCore` são ignorados; `Warning` e superiores são registrados. |
| `.Enrich.FromLogContext()`                                              | Permite adicionar informações extras ao contexto dos logs.                                   | Pode adicionar `CorrelationId`, `UserId`, `RequestId` etc.                                          |
| `.WriteTo.Console()`                                                    | Define o console como destino dos logs.                                                      | Logs aparecem no terminal da aplicação.                                                             |
| `.WriteTo.File(...)`                                                    | Define um arquivo como destino dos logs.                                                     | `logs/api-2026...log`                                                                               |
| `Path.Combine(...)`                                                     | Monta o caminho do arquivo de forma compatível com o sistema operacional.                    | Funciona adequadamente em Windows, Linux e Docker.                                                  |
| `AppContext.BaseDirectory`                                              | Obtém o diretório base onde a aplicação está sendo executada.                                | `/app/` ou `C:\MinhaApi\`                                                                           |
| `"logs"`                                                                | Define o diretório onde os arquivos de log serão armazenados.                                | `/app/logs/`                                                                                        |
| `"api-.log"`                                                            | Define o padrão do nome do arquivo. O Serilog adicionará a data.                             | `api-20260903.log`                                                                                  |
| `rollingInterval: RollingInterval.Day`                                  | Faz a rotação dos arquivos diariamente.                                                      | Um arquivo novo por dia.                                                                            |
| `retainedFileCountLimit: 7`                                             | Define a quantidade de arquivos antigos que serão mantidos.                                  | Mantém aproximadamente 7 dias quando há um arquivo diário.                                          |
| `outputTemplate`                                                        | Define o formato do conteúdo gravado no arquivo.                                             | Data + nível + origem + mensagem + exceção.                                                         |
| `{Timestamp:yyyy-MM-dd HH:mm:ss.fff}`                                   | Mostra data e hora do evento, incluindo milissegundos.                                       | `2026-09-03 17:30:25.123`                                                                           |
| `[{Level:u3}]`                                                          | Mostra o nível do log usando três caracteres.                                                | `[INF]`, `[WRN]`, `[ERR]`, `[FTL]`                                                                  |
| `{SourceContext}`                                                       | Mostra a origem/categoria que gerou o log.                                                   | `MinhaApi.Controllers.ClientesController`                                                           |
| `{NewLine}`                                                             | Adiciona uma quebra de linha.                                                                | Separa as informações visualmente.                                                                  |
| `{Message:lj}`                                                          | Exibe a mensagem do log.                                                                     | `Cliente 123 encontrado`                                                                            |
| `{Exception}`                                                           | Exibe a exceção e o stack trace, quando existir.                                             | `System.Exception...`                                                                               |
| `.CreateLogger()`                                                       | Finaliza a configuração e cria a instância do logger.                                        | Produz o `ILogger` do Serilog.                                                                      |

### Health Check

Implementar **health checks** em APIs ASP.NET é essencial para confiabilidade e operação contínua. Eles:

- Fornecem **visibilidade em tempo real** do estado da aplicação e de suas dependências (BD, cache, filas).    
- **Padronizam a sinalização de falhas** via HTTP (ex.: 200/503), simplificando automações e alertas.
- Permitem **orquestração inteligente**: **Kubernetes**, **Docker Swarm**, **NGINX/Traefik/HAProxy**, **Consul** e **Prometheus** usam esses sinais para reiniciar, escalar e retirar instâncias do tráfego.
- **Reduzem downtime** ao isolar nós problemáticos e evitar enviar requisições para instâncias não prontas.
- Melhoram a **observabilidade** com respostas consistentes (JSON) e métricas integráveis.
    
##### Liveness (o processo está vivo?)

- **Objetivo:** detectar travamentos/loops ou deadlocks no processo da API.
- **Escopo:** auto-contido (não deve chamar dependências externas).
- **Ação típica do orquestrador:** reiniciar o container quando unhealthy.
- **Exemplos:** responder “OK”/200, verificar thread pool/heap básico, “self check”.
- **Boas práticas:** rápido (<100ms), sem I/O externo, estável.

##### Readiness (a instância está pronta para tráfego?)

- **Objetivo:** garantir que a instância pode atender requisições de negócio.
- **Escopo:** pode validar **dependências críticas** (ex.: EntityFramework `AnyAsync()` leve), configuração e migrações concluídas.
- **Ação típica do orquestrador/Load Balancer:** anexar/desanexar do pool de tráfego conforme Healthy/Unhealthy.
- **Exemplos:** ping leve ao banco, teste de cache, verificação de filas/credenciais.
- **Boas práticas:** operação **barata** e com **timeout curto** (2–5s), sem mutações (apenas leitura).

#### Implementação
##### Dependencias 

Instalar dependencia para executar o ping no Oracle usando `HealthChecks.Oracle` e uma dependencias dedicada para verificar se o banco de dados esta funcionando.

```bash
dotnet add package AspNetCore.HealthChecks.Oracle
```

##### *Program.cs*

Configurar o Health Check para monitorar a aplicação e Banco de dados.

```csharp
builder.Services.AddHealthChecks()
    // Liveness
    .AddCheck(
        "self",
        () => HealthCheckResult.Healthy(),
        tags: ["live"])
    // Readness
    .AddOracle(
        connectionString: builder.Configuration.GetConnectionString("Oracle") ?? "",
        name: "oracle",
        failureStatus: HealthStatus.Unhealthy,
        tags: ["db"]);
```

Configurando as Urls de mapeamento

```csharp
app.MapHealthChecks("/health/live", new HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("live")
});

app.MapHealthChecks("/health/db", new HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("db")
});
```

##### *API* 
Utilizando a controller `HealthController` para exibir as informações de Health Check

```csharp
[Route("api/health2")]
[ApiController]
[AllowAnonymous]
public class HealthController : ControllerBase
{
	private readonly HealthCheckService _healthService;

	public HealthController(HealthCheckService healthService)
	{
		_healthService = healthService;
	}
	
	...
}
```


###### Metodo Liveness (Validar se API esta no ar)

```csharp
[HttpGet("live")]
public async Task<IActionResult> Live(CancellationToken ct)
{
	var report = await _healthService.CheckHealthAsync(
		r => r.Tags.Contains("live"), ct);
		
	var result = new
	{
		status = report.Status.ToString(),
		checks = report.Entries.Select(e => new
		{
			name = e.Key,
			status = e.Value.Status.ToString(),
			description = e.Value.Description,
			error = e.Value.Exception?.Message
		})
	};

	return report.Status == HealthStatus.Healthy
		? Ok(result)
		: StatusCode(StatusCodes.Status503ServiceUnavailable, result);
}
```

###### Metodo Readiness (Valida de o banco esta on-line)

```csharp
[HttpGet("db")]
public async Task<IActionResult> Ready(CancellationToken ct)
{
	var report = await _healthService.CheckHealthAsync(
		r => r.Tags.Contains("db"), ct);

	var result = new
	{
		status = report.Status.ToString(),
		checks = report.Entries.Select(e => new
		{
			name = e.Key,
			status = e.Value.Status.ToString(),
			description = e.Value.Description,
			error = e.Value.Exception?.Message
		})
	};

	return report.Status == HealthStatus.Healthy
		? Ok(result)
		: StatusCode(StatusCodes.Status503ServiceUnavailable, result);
}
```


### Application Insights

O **Application Insights** é uma ferramenta de monitoramento e observabilidade da Microsoft para aplicações.  
Ele permite acompanhar **requisições, erros, exceções, métricas, desempenho e dependências** em tempo real.  
É útil para identificar rapidamente **falhas, gargalos de performance e problemas de integração**.
Além disso, facilita a análise do comportamento da aplicação e o diagnóstico de problemas em **produção**.

Adicionando pacotes

```bash
dotnet add package Microsoft.ApplicationInsights.AspNetCore

dotnet add package Azure.Monitor.OpenTelemetry.AspNetCore
```

Configurando String de conexão 

```json
  "ApplicationInsights": {
    "ConnectionString": "STRING DE CONEXAO"
  }
```

Adicionando as configurações na `program.cs`

```csharp
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddOpenTelemetry()
    .UseAzureMonitor(options =>
    {
        options.ConnectionString =
            builder.Configuration["ApplicationInsights:ConnectionString"];
    });
```