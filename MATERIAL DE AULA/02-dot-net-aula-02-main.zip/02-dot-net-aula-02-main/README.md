### Tópicos Abordados

- Revisão
	- Repository Pattern
	- Utilizando Dtos
- Criando Mapeamentos
- Compressão de Dados 
- Hate Limit
- Swagger Annontation

### Repository Pattern

É um padrão de projeto que **isola a lógica de acesso a dados** (queries SQL, Entity Framework, Dapper, MongoDB etc.) da lógica de negócios da aplicação.  
Ele atua como um **intermediário** entre o **Domain/Application** e a **fonte de dados**.
#### Benefícios de Usar Repository Pattern

1. **Separação de responsabilidades (SRP - Single Responsibility Principle)**  
    - A camada de aplicação/serviço não precisa conhecer como os dados são persistidos.
    - O repositório concentra tudo relacionado a persistência.
2. **Facilidade de manutenção**
    - Se amanhã você trocar o banco de dados (ex.: de SQL Server para MongoDB), você só altera a camada de repositórios, sem mudar a lógica de negócio.
3. **Testabilidade**
    - Você pode **mockar** os repositórios em testes unitários sem precisar de banco real.
    - Isso facilita TDD.
4. **Reutilização de código**
    - Centraliza operações comuns como `Add`, `Update`, `GetById`, `Remove`, evitando duplicação.
5. **Camada de abstração**
    - Evita que o Entity Framework (ou outro ORM) fique espalhado pelo código da aplicação.
    - Se amanhã você quiser trocar EF por Dapper, o impacto será mínimo.
6. **Organização e clareza**
    - Deixa claro quais operações estão disponíveis sobre uma entidade.
    - Facilita a leitura e a manutenção por equipes grandes.

#### Organizando o Diretório

Adicionando novo diretório dentro da pasta Data, para armazenar os arquivos do repositório. 

![image.png](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOMAAACFCAIAAAAmQdhcAAAMuklEQVR4nO2dT4jbVh7Hf93ZpkxyCDmkmbJDvS4IGoRoAnsJDKnXOD4E5hCnYi9DUm9rzF5CZw+BfdCCE6r00h0zhy6DKd7AHHZr8LCZQ1uPO6uCIXtMMEsDInHUDrtkc0iykG2njTN7kOTRP2skS4reU36fk0fWk57JN3r68z76vZDJZABBqOfnsW79+l9/98rL0+Yl//v+yW//sPaPm9/Ful8kfcSb1Fdenq7/+bp5ya+EX/ylLtpW+/d/vj/xmz85WosNRcoZf6jNUkHqx9JLhAUCJHV2dnZrayvoDt57+4T5z+1t+Ozzf/7r3n891jExyqfYUNpKlnCVlttqYkOpDjDJqcZvUnmev3Tp0tmzZ4PuwHZMnZRWpcR120URWq5RRVLPz/ysxPO8JEn79++Puzde9Nc31VxRBAAQG4pOQzROEjLltvan7VskJex9TOV5/sqVKy+++OIz6I1PWhWuBaAN+kQoVDgwj/7Wb1t4SpAO9kgqZTFVB7cAwHytpQ6ca3l/i7CJ1+hPV0yF+XxmoPQBBNKVgHAcx5WaqnM1z28RZhmb1NnZ2UuXLtESUxAb7fKAVFoA8Ho2ox1bhfm886mF97cIs4wd/be2tia40o+aTLmtlAEA1GaJ0884W8vNarutlEGVZf2o2erIktRWyjLhKs5vkTTwQqxPU53PqFwZc+cfQXaJN6kIEhW+7qciSOJgUhE2wKQibIBJRdgAk4qwASYVYQNMKsIG8c75nwx0WhAnNCY1nNOiIzYUCcY5At6gFUMjsSc1CacFQCDVrCzDxPNT0YqhjniTmpTTIsznYXNxGZaW5gWpHyZHaMXQQoxXVMk5LcJ8HjbX+/31TcjPC/pCsaF0iUi6iqIoSpcI4xdaQSuGDuJKqjYLe9++fTFt3ws9qADWqAJkylVY5Diu1ITykhFL14XutCocx3EcR+RclQitCkdkUJslTjs3sH4b5w98LoklqcnKAqOgalEtXxgd4dTmotQHgL60Imeyr3sstGGyYhRFMV1vWfD+FglH9ElN2mkRL5QzmXJbG4fb5QzoQ7cZgcs6G7ouRCuGFiJOavJOi1jMqc0SN6LUVEdRzeinAsJ8PiN3Wh4LdzeHVgwlRHztn7jTIhZz6uay6Wq/v76ptositABAHWSXFCUDADLhjEy6LkQrhjponPMfj9Pieu8Tb4gyA43PqNCpQpzgDBWEDWgc/RHECR5TETbApCJsgElF2ACTirABJhVhA1qSyvN80l1AqIaWpF6+fJmGsIqNiWeXig1tgqtAumNmuu7BxA1B0CfYjp1jmwZoSer09HStVgsZ1kOvHcp/lF/4cuHcV+dOfXxKWzj10tTCxoL5w1g0pyUbbnZpXypw/h/PGvkO3NBAIF2lnV0xJuQswnyw/2imDsSyfmTQklQAqNfrYcJ68NWDpz85vTPc2bi4ce2da7e/uA1aOjsLU/umzn99XvvgEVZhPg+by8vW2dd0I5Cl8sBsefUlKaUaDUVJ7fV6YcJ67N1jj759JL8v37t57+Hdh3c27gDAcHu4Wlwd/ji8+uZV7cPqqdUxG4jKaTEfdXbH5cbefoupoWk8N05GxIbSJaRhGeTdZyr634JdsLH213Q6onfNsb7b/hqiyw8PD0VJBYBer7e2tlar1Q4cOBC07cyxGVVWd57uTLjv6J0WgXTb+U19rqx22PP2Wwy0SbH69Nqs1N3dabajtc6MTAZDR7Dicwu2DoiNUX8JVAlIBTIoXxBBbEhAClLfvv74XypeMHY/kcfuBl1J5Xn+zJkz9Xr98ePHQdvuDHee/vTUttD/6B+90yLM5zPyiu3E04/BInBZMI6Utp0ua3nvyJDltPC57jzQFiytDFtCymWyrwO0KgQkRQLimTfnL701UHNStOezFCWV5/larVav13u93gTNH9x+MDs3a1voe/SP2mlxJXKDxeTNRoRMRrZEmINhXypw3CIspXP0DxNTALjx6Y0ZYebkByePvHHkMH/46FtHteXDbT2dow8uROy0AIAeI8t9BJ8GS18ZjP6jCKSaG7N9AO2AmZNMaRAIEQNtwb5f640PsSEB4QhIrnkzTqydv1TvXKHUVB2H7gmhZSb1cDgME1MAuP/N/c7FzvHy8fyH+Sc/PNm6HuDFLRE5LTb6UoFkFV1zkQlX2cNvGTXUXoehKBJob3Pxilmrwt0ixsra6oG2YO6A1krvMMjNZracbZZa0L/VrLa75FZB6rt32PFLYfTCJJlw0QgVtMxPnZubCxPT2ECnhRZoGf2pjClCEbQkFUG8oWX0RxBv8JiKsAEmFWEDTCrCBphUhA0wqQgb0PKMygzWTkGc0JjUcLVTLJVP5Mmqp3igT3AL+IBqslaIidjvp05QO+Xu339vW7K9DX/bdKmd8stf/9HR2vSoM0SlHx/gM9VnSjprp+i0OrJU5QQADBP7pLJ2ioFYzKn67Gg3T8TNMHGROmwttaluHl6HxQZpNLqK0hDdzRMXIwQZRxprp4wmrhc7huxp8y706fIOw8RN6nAXLZxeh7sNkh0sWuckO3oSg8iRSlJYO0V75bllMrSLdwEuhomr1OFHtBhvgxiHdPOa1p7EIHKkkvTVTjHoS4tNs7rv4V14GibRixbWnsQgcqSS1NVOMdGXVgbasO7iXYCLYTJe6thDtPBvg7j3JGKRI5WkrXaKldZys9peIusFyepdaGaF0zBxkzpEm2gxUkGdXocvG8Tek04xcpEjldA4PzWe2ik28G4oY9D4jAprpyBOcIYKwgY0jv4I4gSPqQgbYFIRNsCkImyASUXYAJOKsAGN91MnA52WdJOepIZ2WoqdSKbdaU9f1SY+/4oWSpM6gdMCAO+9fcL85/Y2fPa5i9MSvDv+H72KDSkXvbyF0JnUhJ2WsLi/eR8JCXVXVEk7LUELjIDJQtFe4J8pt3UTxVopRcPhoqCs4g+6kpqo0zIiUIERoy7EYFEvigJqs6RLMdZKKeBWTQVlFb9QNPrTIguYC4w41VaBy0ImZ8wvBbmjNbFbKBq7c1vVAbjVGHFubX2gSpL+pnLEBC1JpSamfrBdMo0ZpI1KKS0QSHfJ99agwEkC6SpKBq/MzFAx+lPltOzBGL3EBWelFGeNEZRVfEPFMZUyp8WJR4ERcwkRWyNnpRRnNRWUVfySnvmpz8RpQRIjPUlF0g0V56kIsieYVIQNMKkIG2BSETbApCJsgElF2ACTirAB20nleT7pLiDPCLaTevny5UTDKjYsk0hNb1DXX91rvDRdIF0lwrf57k58jWUaa8S9jQa2kzo9PV2r1UKG9dBrh/If5Re+XDj31blTH5/SFk69NLWwsWD+sAcC6Srt7IrxCt9FmDcHqC8VuEDz+Ex1AdxRmyVj7qsUdVZ3e7tnN54dbCcVAOr1epiwHnz14OlPTu8MdzYublx759rtL26Dls7OwtS+qfNfn9c+7BVWgSyVB+ZJen1JejYT9lodGZ6LSVfMJ7XX64UJ67F3jz369pH8vnzv5r2Hdx/e2bgDAMPt4Wpxdfjj8OqbV7UPq6dWvbYyeqv1WDxqp0zgw5g3TEl9mG63a+qcy7HYtovAEg7zSQWAXq+3trZWq9UOHDgQtO3MsRlVVnee7oTthF/Pb0wVl+A+DGX1YQqFFXlUAUQs5mxug13LCS7hpCGpPM+fOXOmXq8/fvw4aNud4c7Tn57aFgYf/QFG5VK8GVfFZeTDOIfycU1oqw/T6hhRFYtZ/QcZbR1aTvCKMcwnlef5Wq1Wr9d7vd4EzR/cfjA7N2tbGHj0769v7kZmTzyquARsQld9mNZyM1slgkCqWXetLNQemU9qmJgCwI1Pb8wIMyc/OHnkjSOH+cNH3zqqLR9u6+kcffCkL63IOckiSxPXfwD/cou/JlTVh+mvb0L+woU8GEE1TledWo6fPVqhwk6ZmOFwGCamAHD/m/udi53j5eP5D/NPfniydT3wi1t0WhXuFjHKp2gFVMas50tu8e/D0FQfpi+tDBQJSMV+RHVoOdAIKuGwPed/bm4uTEzTTgL1YaJ7v5cdtkd/jCldCKRqu5aKDrZHf4QaBNJtlzNqs1SI6QjO9uiPPD+wPfojzw+YVIQNMKkIG2BSETbApCJsQEtS0TNBvKElqUl7Jhqol9ALLUlN3jNBvYRuaEkqJOyZoF5COxQlNUnPBPWS+PWSkFCUVEjWM0G9JGa9JCR0JTVJzwT1kpj1kpBQlNQkPRPUSwDi1ktCQlFSE/VMUC8BiFkvCQkt81OT90xQL4F49ZKQ0DI/FT0TN1Kll4SEltEfY0oFceolIaFl9EeSJna9JCS0jP4I4g0toz+CeINJRdgAk4qwASYVYYP/A8GpTXZoeFbpAAAAAElFTkSuQmCC)

#### Criando a Interface

```csharp
public interface IClienteRepository
{
	Task<IEnumerable<ClienteEntity>> ObterTodosAsync();
	Task<ClienteEntity?> ObterUmAsync(int Id);
	Task<ClienteEntity?> AdicionarAsync(ClienteEntity entity);
	Task<ClienteEntity?> EditarAsync(int Id, ClienteEntity entity);
	Task<ClienteEntity?> DeletarAsync(int Id);
}
```

#### Criando arquivo concreto do Repositorio 

```csharp
public class ClienteRepository : IClienteRepository
{
	public Task<ClienteEntity?> AdicionarAsync(ClienteEntity entity)
	{
		throw new NotImplementedException();
	}
	
	public Task<ClienteEntity?> DeletarAsync(int Id)
	{
		throw new NotImplementedException();
	}
	
	public Task<ClienteEntity?> EditarAsync(int Id, ClienteEntity entity)
	{
		throw new NotImplementedException();
	}
	
	public Task<IEnumerable<ClienteEntity>> ObterTodosAsync()
	{
		throw new NotImplementedException();
	}
	
	public Task<ClienteEntity?> ObterUmAsync(int Id)
	{
		throw new NotImplementedException();
	}
}
```

#### Configurando Context

```csharp
public class ClienteRepository : IClienteRepository
{
	private readonly ApplicationContext _context;

	public ClienteRepository(ApplicationContext context)
	{
		_context = context;
	}
}
```

#### Refatorando os métodos

Vamos trazer a lógica de banco de dados que esta no controller para o nosso arquivo ==ClienteRepository.cs==

```csharp
public async Task<ClienteEntity?> AdicionarAsync(ClienteEntity entity)
{
	_context.Cliente.Add(entity);
	_context.SaveChanges();
	
	return entity;
}

public async Task<ClienteEntity?> DeletarAsync(int Id)
{
	var result = await _context.Cliente.FindAsync(Id);
	
	if (result is not null)
	{
		_context.Remove(result);
		_context.SaveChanges();
		
		return result;
	}
	return null;
}



public async Task<ClienteEntity?> EditarAsync(int Id, ClienteEntity entity)
{
	var result = await _context.Cliente.FindAsync(Id);
	
	if (result is not null)
	{
		result.Nome = entity.Nome;
		result.Email = entity.Email;
		result.EstadoId = entity.EstadoId;

		_context.Update(result);
		_context.SaveChanges();
		
		return result;
	}
	return null;
}



public async Task<IEnumerable<ClienteEntity>> ObterTodosAsync()
{
	var result = await _context.Cliente.ToListAsync();	
	return result;
}

public async Task<ClienteEntity?> ObterUmAsync(int Id)
{
	var result = await _context.Cliente.FindAsync(Id);
	return result;
}
```

#### Refatorando a controller

##### Configurando o Repository

```csharp
public class ClienteController : ControllerBase
{
	private readonly IClienteRepository _clienteRepository;

	public ClienteController(IClienteRepository clienteRepository)
	{
		_clienteRepository = clienteRepository;
	}
}
```

##### Usando Repository nos métodos

- Buscar todos os clientes

```csharp
[HttpGet]

[SwaggerOperation(
   Summary = "Lista clientes",
   Description = "Retorna a lista completa de clientes cadastrados."
)]

[SwaggerResponse(statusCode: 200, description: "Lista retornada com sucesso", type: typeof(IEnumerable<ClienteEntity>))]
[SwaggerResponse(statusCode: 201, description: "Não possui dados para o cliente")]
[EnableRateLimiting("rateLimitePolicy")]
public async Task<IActionResult> Get()
{
	var result = await _clienteRepository.ObterTodosAsync();
	
	if(!result.Any())
		return NoContent();
		
	var Id = result.FirstOrDefault()?.Id ?? 0;

	var hateos = new
	{
	    data = result,
	    links = new { 
		    self = Url.Action(nameof(Get), "Cliente", null),
		    getById = Url.Action(nameof(Get), "Cliente", new { id = Id}),
		    put = Url.Action(nameof(Put), "Cliente", new { id = Id }),
		    delete = Url.Action(nameof(Delete), "Cliente", new { id = Id }),
	    }
	};
	
	return Ok(hateoas);
}
```

- Obter um cliente 

```csharp
[HttpGet("{id}")]
[SwaggerOperation(
	Summary = "Obtém cliente por ID",
	Description = "Retorna o cliente correspondente ao ID informado."
)]
[SwaggerResponse(statusCode: 200, description: "Cliente encontrado", type: typeof(ClienteEntity))]
[SwaggerResponse(statusCode: 404, description: "Cliente não encontrado")]
public async Task<IActionResult> Get(int id)
{
	var result = await _clienteRepository.ObterUmAsync(id);
	
	if (result is null)
		return NotFound();
		
	var hateaos = new
	{
		data = result,
		links = new
		{
			self = Url.Action(nameof(Get), "Cliente", new { id }),
			get = Url.Action(nameof(Get), "Cliente", null),
			put = Url.Action(nameof(Put), "Cliente", new { id }),
			delete = Url.Action(nameof(Delete), "Cliente", new { id }),
		}
	};
	
	return Ok(hateos);
}
```
#### Configurando a DI (Injeção de Dependência)

```csharp
builder.Services.AddTransient<IClienteRepository, ClienteRepository>();
```

### Dtos

DTOs (**Data Transfer Objects**) são usados em aplicações, especialmente em **APIs ASP.NET** com boas práticas de arquitetura (ex: **Clean Architecture**, **DDD**, etc.), para **transportar dados entre camadas** de forma organizada, segura e desacoplada.
#### Quais as vantagens

##### 1. **Separação de Camadas**
- As entidades de domínio (ex: `ClienteEntity`) representam **a regra de negócio**.
- As DTOs representam **os dados que viajam pela API**.  
    Isso evita expor diretamente suas entidades internas, protegendo o domínio.
##### 2. **Segurança**
- Sem DTOs, a API poderia expor campos sensíveis (ex: `SenhaHash`, `TokenInterno`) ao serializar uma entidade.
- Com DTOs, você controla **exatamente o que vai para o cliente**.
##### 3. **Controle de Entrada e Validação**
- DTOs servem para definir **o que a API espera receber**.
- Exemplo: no `ClienteCreateDto`, você pode pedir só `Nome` e `Email`, sem permitir que o usuário mande `Id` ou `DataCriacao`.
##### 4. **Facilidade de Evolução**
- DTOs permitem **versões diferentes** da API sem alterar o domínio.  
    Exemplo: `ClienteDtoV1` e `ClienteDtoV2`.
##### 5. **Performance**
- DTOs podem reduzir payloads, transmitindo **apenas os dados necessários**.
- Isso evita trafegar objetos grandes com dados inúteis.
##### 6. **Padronização e Clareza**
- Quando outra equipe consome sua API, a documentação fica clara:  
    “Esse é o contrato, esses são os dados de entrada e saída.”

#### Organizando Diretório

Crie uma nova pasta no projeto com nome Dtos para armazenar os arquivos de Dtos

![image.png](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKsAAAAsCAIAAACVP98uAAAE6UlEQVR4nO2cQWjbVhjHvy7LRpJD6aFtysyEBw9SHmIt7FIInTFODoUc4kzsEtppmwm7hPRS2IMN7DBll1Gxw0YQwyvksE2gQHvY5nhBA0N2bBFhgUfqaTMbaQ9tB1mXLY53kJUospxZdiS76P1O8sv73nv4/fW9J72/c2Jubg4YEeYEx3HdHgOjmzzX7QEwugxTQNRhCog6z4fZ2drX7507M+As+evp7tvvL/9077cwh8FwEqoCzp0ZkL9cc5a8xr/0lSy4qv3x4OmlNz9viBYUKiXsD2Y+nZKMQEYZMdpXQCwWq1QqfqPm3rrk/LizA998u/771p9H1HGwP++CQjUaJyijAggKnSkzPbRLmwrAGOdyuampKb+BrhzQLmomjYrauACqehzNRZl2doIYY0mSBgcHj300PjDurJqJccFaGjhRo1QRAAB4UqR1lPryclCkuBcchv8cgDFeWFjo7+8PYjT+UTMIHKuAoGhimaCUCsCTolYkGylpZNYuYnjgLwf02PSb5Y3DBTyKg16w5tqQFnUuPgKwUTYTUpHwXRjgs4APBfTW9PMTSa5MW9n9GVIKoetwk60CnrSqgFgslsvlemX669k+487sBi1DYtyaZp7MJOx8AGBIqXTejCOWCdy0ug+oVCpt7PyPG07UqAgAYObTyH78Uwu6JGlU1AnKWM8IlEpWnZQKzvcIOkHskdFNqGeDje8EPWnyRogRCOx0OOqwk6GowxQQdZgCog5TQNRhCog6TAFRhykg6gSuAIxx0F0wOiFwBczPz/eACByugfopoaBYVzwp0mM8OBQUesAzcSAZuAIGBgay2WyHIjj1yqnkx8np76ev/nB17JMxq7Dvxb7plWnnhTc8KVItvojqXIcJ5wmhIaWQL4eZLZ2mmPm01RMpi5p9HPm/UV0jjH2ALMudiODkyyevfHalVq2t3Fi5/c7tze82wZr1wnTfC33XfrxmXTQRAU9uimXLUGhhSFJIZhE1k86b9lFlzxKGAkqlUiciuPDuhSe/PtE/0LfubT3+5fH9lfsAUN2pLo0vVf+p3nr9lnWxNLbkEcxPJLmDM2IvHHen204mKLRIiOJI6UeY0ry8Bz6sbIcGfbjRYF1uIT0LlEql5eXlbDY7NDTkN3b4wrCpm7W9Wpt9NziJmiAoWnLVSuAEZuqi4MR4ASGEiM6JswKoGUR0K89bNmWPkEYao8QyQQghlM7H3fYlnhT3G7Wqz9q1UYMh4hgISQEY48nJSVmWt7e3/cbWqrW9f/dchS2vAgBcfKSVbngUt25TSqmUsIPM/KcqAIBa0KHBX+Id4qI1K9vBXyeSnL7o3JgE7HILQwEY42w2K8tyqVRqI/zR5qPYaMxV2OoqUM/DLXalE3u/2PLtdmRI61a2IwjY5RaGAjqZfgC4+8XdYX748oeXz7569jQ+ff6N81Z5dac+6/sXXhjSop6QHN8dT4jn92jQMiSaZ/I2QnxZ2eztiHFn1fRoMziXW+C/GqtWq51MPwA8/Plh4Ubhongx+VFy9+/dyprPHyqpGbRBbOuYZR5rUi+NilrdhgY6QRnvag2mNFdIW1a2AwwpReK03oROUAaCdbkF7hEaHR3tZPoZQcNcYlGHnQxFHaaAqMMUEHWYAqIOU0DUYQqIOkwBUcfHO0GM8fr6eiedsf8l1oP8B4DmwDRteyAsAAAAAElFTkSuQmCC)

#### Criando a DTO
Crie o arquivo `ClienteDto.cs` para ser utilizado nos metodos Post e Put da Controller `ClienteController.cs`.

Vamos utilizar o `Record`, que é uma forma de declarar classes imutáveis e com **igualdade por valor** (value-based equality). Ele foi pensado para facilitar a criação de **objetos de domínio**, **DTOs** e estruturas de dados onde a comparação deve ser feita pelo **conteúdo** e não pela referência.

```csharp
 public record ClienteDto(string Nome, string Email, int EstadoId);
```

#### Utilizando nos metodos de entrada

Altere o parametro de entrada para utilizar a `ClienteDto.cs`.

De: 
```csharp
[HttpPost]
public IActionResult Post(ClienteEntity entity)
{
	....
}
```

Para: 
```csharp
[HttpPost]
public IActionResult Post(ClienteDto entity)
{
	....
}
```

### Mappers

Criar uma **classe Mapper** para converter de **DTO → Entidade** (e vice-versa) é uma **boa prática de arquitetura**.
#### Por que usar Mapper?

1. **Separação de responsabilidades (SRP - SOLID)**    
    - O DTO (Data Transfer Object) existe para transportar dados entre a API e o cliente.
    - A Entidade representa a regra de negócio no domínio.
    - Se misturarmos os dois, a camada de domínio pode acabar dependendo de detalhes da API.
    - O Mapper centraliza a conversão e mantém cada camada focada na sua responsabilidade.
2. **Evita código duplicado**
    - Sem mapper, cada controller ou service teria que repetir código para converter DTO em entidade.
    - Com mapper, centralizamos a lógica de transformação em um só lugar.
3. **Maior manutenibilidade**
    - Se mudar o DTO ou a Entidade, você ajusta apenas no Mapper.
    - Sem isso, teria que procurar e alterar em todos os pontos do sistema onde há conversão.  
4. **Facilita testes**
    - Você consegue testar a lógica de mapeamento separadamente.
    - Garante que sempre haverá consistência ao transformar dados.
5. **Clareza no fluxo de dados**
    - Fica explícito quando você está lidando com dados de entrada/saída (DTO) e quando está lidando com objetos do domínio (Entidade).

Usando **extension methods como mapper**, utilizamos dois princípios do SOLID:

1. **SRP** (Single Responsibility Principle) → separa responsabilidades.    
2. **OCP** (Open/Closed Principle) → estende classes sem modificá-las.
#### Configurando o Diretório

Cria um novo diretório para armazenar os arquivos de mapper do projeto.

![image.png](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKwAAAApCAIAAAAnLlXkAAAFXklEQVR4nO2bQWjbVhjHvy5LRpJD6aFtysyEBg9ahFgKuxRCZ4yTQ8GHOBO7hHbaZswuYbkU9mADO0zZZcT4sGHE8Ao5bBM40By2OVrQwJAdW8RY4JFq2sxG2kPbQdZli+MdZMWyIzmxLdvJ/H4n+fP73nuO/nrv6b1/zjAMA5T+5rled4DSe6gIKPB8h+rd+OrdSxeGnZG/nu299f7Kj/d/61CLlJbplAguXRhOfbHhjLzKv/hlSqgr9sfDZ9fe+OxQtiATKahhFFOcUR6rORGy0bCk+9/hfuZYIggEAsVisdmq33vzmvPj7i58/c1Pv2//2aCMA9Nk45hXHPdbmBMZALPZblCO5GgRcByXTCZnZmaarbpuJGgWw4BQhJd0WwXCVFDTtCDbTp0UV45YGHIcJ0nSyMhId3rjxEhnDHHOnj94HGez6fzBt4JMKsiCHVCxgFVCCCEq5r2DAHwlYicLMlFlWSVEFg591w80EgHHcYuLi0NDQ13rTS1KXgtOWXeCj4RgfdWxFFBiCCGEENaCcfvmMmIc5hFC0SyIS95BQc6F1qNWNtjJDGvMIxRThDnRwFbVtQuS/zOeIrAUMDg42M3e1KGks2wc8wDCnGhkapeDlaFAClZDZnZe0gFAlzIaw172CPKIBUbMVbLtcmZFYpuGGZSqY0Z/4C6Ck6AAAAB9dR1CEQHH2Wza+VzyWJUAI4RQNOuyUuSRy8rBGdQqD/vh512XwgjNw1K/TweBQCCZTPZeAQAAupQxREmsnQoALrOMaWwCAB8JVXe9mVCEh0pQyyseQZ0YUJ1CPFoNR7Mmi/plPHB5OygWiy28C3QKJZ2NA6nbGVDS2XguR0QwNa06EpgGu0QIAwAaRopnUIlFkZrLERHAisYcNQuyPcNoGPXLdsSZDh0gHd4xdMVjs6gFBJnEjfp9JNcgpZ5O7Rj6dGsp3YAeIFE6Nh1QThF0JKBQEVCoCChARUABKgIK+CsCjuN8rI3SNfwUwcLCwgnQQdUQYDsIBNm64rFKfDwgFGS3UyYeq8TPVrqBnyIYHh5OJBJt6uDcy+dCH4dmv5u9+f3NyU8mreDACwOza7POC3d4rJIcm7FPCOch4rxHuhRGTW0h2+rxxPLA1aTMiadv38XnNUEqlWpHB2dfOnvj0xvlUnnt9trdt+9ufbsF1o3Pzw4MDdz64ZZ14aEDHi+JhtOdqktSh40hlgeu+tnywHW2Tf/xWQSFQqEdHYy/M/7016faB9r2/e0nvzx5sPYAAEq7peWp5dI/pTuv3bEulieXXZJrTpBdcTzZbg4zjGXHNGKdJzJizi7iZjzrkQeu5mfXlmvFHuf/20GhUFhZWUkkEqOjo83mjo2PmZpZ3i+32LZlMjgad4eZyOYtxxojzgmgxBDWwMxGLeOJawr0xgNXbYHH6kE5q5ut2OP8FwHHcdPT06lUamdnp9nccqm8/+9+XfDY0wHAgamsMR4Os4p7SclrcMhQ4p4C0BMPXLVXkRCj1bTZkj3OZxFwHJdIJFKpVKFQaCH98dbjwESgLnjc6UBfXTfth/JovB1mzaZ03wPXgJbscT6LoB0FAMC9z++N8WPXP7x+8ZWL57nzV16/YsVLu5Ubf3Dhhi5ltKDk+PE8xq5/iGM4zJpJ6b4Hzl7c6KvrpkuxZu1xfppKSqVSOwoAgEc/P8rfzl8Vr4Y+Cu39vVfcaPLfnpQY2sRqjhAJAADMbDTsUa6Bw8xRLK9JUo6IGkaxhild9sBV0aUwZkmlmIZRDFqxx/npJ5iYmGhHAX3ACfXA+TkdUAWcUugBEoXayyh0JKAAFQEFqAgoQEVAASoCCgD8B3BnmwXvmj+pAAAAAElFTkSuQmCC)

Criando o arquivo `ClienteMapper.cs` e vamos utilizar o conceito de `Extension Methods` para extender o comportamento da classe `ClienteDto`

```csharp
public static class ClienteMapper
{
	public static ClienteEntity ToClienteEntity(this ClienteDto obj)
	{
		return new ClienteEntity { 
			Nome = obj.Nome,
			Email = obj.Email,
			EstadoId = obj.EstadoId,
		};
	}
}
```

#### Aplicando na controller POST e PUT

O repositório espera uma classe `ClienteEntity` no parâmetro de entrada, utilizando a método de extensão, vamos converter o tipo de `ClienteEntity` para `ClienteDto`.

- Método Post
```csharp
[HttpPost]
public IActionResult Post(ClienteDto entity)
{
	try
	{
		var result =_clienteRepository.AdicionarAsync(entity.ToClienteEntity());
		
		return Ok(result);
	}
	catch (Exception)
	{
		return BadRequest();
	}
}
```

- Método Put

```csharp
[HttpPut("{id}")]
public async Task<IActionResult> Put(int id, ClienteDto entity)
{
	var result = await _clienteRepository.EditarAsync(id, entity.ToClienteEntity());

	if (result is null)
		return NotFound();
		
	return Ok(entity);
}
```


### Compressão de Dados

A compressão de respostas em uma API tem como objetivo reduzir o tamanho dos dados enviados do servidor para o cliente. Isso traz diversos benefícios:

1. **Redução de tráfego na rede**: respostas menores significam menos consumo de banda.
2. **Melhoria no tempo de resposta percebido**: clientes recebem os dados mais rapidamente.
3. **Escalabilidade**: menos dados trafegando permite que mais requisições sejam atendidas sem aumentar significativamente o uso de recursos.
4. **Compatibilidade com navegadores e clientes modernos**: Gzip e Brotli são amplamente suportados.
5. **Custo-benefício**: troca-se processamento do servidor (para comprimir) por economia de largura de banda e melhor experiência do usuário.

##### Configurando Compressão

Adicione a namespace `Microsoft.AspNetCore.ResponseCompression` no arquivo ==Program.cs==, para adicionar os pacotes de compressão de resposta.

```csharp
using Microsoft.AspNetCore.ResponseCompression;
```

##### Adicionando configuração 

Ainda no arquivo ==Program.cs== adicione as seguinte configurações:

```csharp
builder.Services.AddResponseCompression(options => {
    //options.EnableForHttps = true;
    options.Providers.Add<BrotliCompressionProvider>();
    options.Providers.Add<GzipCompressionProvider>();
});
```

##### Configurando tipo de compressão

Cada algoritmo de compressão (Brotli e Gzip) pode operar em diferentes **níveis de intensidade**, que impactam em duas dimensões:

- **Tamanho final da resposta** (quanto menor, melhor para o cliente).
- **Uso de CPU do servidor** (quanto maior a compressão, mais processamento é necessário).

```csharp
builder.Services.Configure<BrotliCompressionProviderOptions>(options =>
{
    options.Level = System.IO.Compression.CompressionLevel.Fastest;
});

builder.Services.Configure<GzipCompressionProviderOptions>(options => {
    options.Level = System.IO.Compression.CompressionLevel.Fastest;
});
```

No caso acima, foi configurado o nível **`Fastest`**, que prioriza **velocidade de resposta** em vez de máxima compactação. Isso é importante em cenários de API porque:

1. **APIs respondem muitas vezes com payloads pequenos/medianos**, onde a diferença entre máxima e rápida compressão é mínima em bytes, mas o custo em CPU pode ser significativo.
2. **Escalabilidade**: reduzir o uso de CPU permite que o servidor atenda muito mais requisições simultâneas.    
3. **Equilíbrio ideal**: em geral, `Fastest` gera economia de rede suficiente sem comprometer o desempenho do servidor.

##### Habilitando a compressão

Adicione na ==Program.cs== as seguinte propriedade `app.UseResponseCompression()`

```csharp
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.UseResponseCompression();

app.MapControllers();

app.Run();
```


### Hate Limit

Usar **Rate Limit em uma API ASP.NET** é essencial para **segurança, estabilidade e controle de uso**, evitando abusos, protegendo o servidor e garantindo que todos os usuários tenham acesso justo aos recursos.
#### Criando as policies 

Vamos adicionar a namespace `System.Threading.RateLimiting` no arquivo de configuração ==Program.cs== para ciar as policies e limitar a quantidade de acessos na api. 

Adicione as configurações do RateLimiter: 

```csharp
using System.Threading.RateLimiting;

builder.Services.AddRateLimiter(options => {
    options.AddFixedWindowLimiter(policyName: "rateLimitePolicy", opt => {
        opt.PermitLimit = 5;
        opt.Window = TimeSpan.FromSeconds(10);
        opt.QueueProcessingOrder = QueueProcessingOrder.OldestFirst;
        opt.QueueLimit = 2;
    });

    options.AddFixedWindowLimiter(policyName: "rateLimitePolicy2", opt => {
        opt.PermitLimit = 3;
        opt.Window = TimeSpan.FromSeconds(5);
        opt.QueueProcessingOrder = QueueProcessingOrder.OldestFirst;
        opt.QueueLimit = 2;
    });
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
});
```

> **Obs:** É possível criar mais de uma politica de Rate Limiter
##### O que ele esta fazendo

- O cliente só pode fazer **5 requisições a cada 10 segundos**.
- Tipo de processamento da fila FIFO (First in First Out)
- Define a fila de processamento com limite de 2 itens, as requisições que excederem retorna 429.
- Se ultrapassar, recebe **429 Too Many Requests**.
#### Habilitando na aplicação

Adicione na ==Program.cs== a seguinte linha para habilitar o Rate Limmiter

```csharp
app.UseRateLimiter();
```

**Exemplo:**

```csharp
var app = builder.Build();


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.UseRateLimiter(); //Habilitando Rate Limiter

app.MapControllers();

app.Run();
```

#### Configurando controller 

Vamos adicionar a ==annotation== para habilitar o Rate Limiter no metodo Get da API

```csharp
using Microsoft.AspNetCore.RateLimiting;

[HttpGet]
[EnableRateLimiting("rateLimitePolicy")] // Incluindo a Plolicy de Rate Limit
public async Task<IActionResult> Get()
{

}
```

### Swagger Annontation

Melhorando as descrições dos métodos usando markdown com **Raw String Literals** `"""` (Strings Brutas)

```csharp
[HttpGet]
[SwaggerOperation(
	Summary = "Listar todos os clientes",
	Description = """
	Retorna a lista completa de clientes cadastrados na base de dados Oracle.

	### 📋 Informações do Retorno:
	* **Status 200 (OK):** Retorna uma lista contendo todos os clientes localizados.
	* **Status 204 (No Content):** Executado com sucesso, porém a base não possui registros cadastrados.
	* **Status 400 (Bad Request):** Ocorreu uma falha durante a consulta (ex: erro de conexão com o banco).

	### 💡 Observações:
	* Os dados incluem as entidades relacionadas (como **Estado**).
	"""
)]
public IActionResult Get()
{
	.....
}
```

```csharp
[HttpPut("{id}")]
[SwaggerOperation(
	Summary = "Editar cliente",
	Description = """
	Atualiza os dados cadastrais completos de um cliente existente.

	### ⚠️ Observações Importantes

	* **Email:** Deve ser único no sistema.
	* **Estado:** Informe apenas a sigla (ex: `SP`, `RJ`).

	### 🔄 Fluxo de Processamento

	1. Valida se o `ID` existe na base.
	2. Atualiza os dados cadastrais.
	3. Retorna o objeto atualizado.
	"""
)]
public IActionResult Put(int id, PostClienteDto model)
{
	....
}
```
#### Adicionando Pacote de Exemplos

```bash
dotnet add package Swashbuckle.AspNetCore.Filters
```

#### Configurando a `Program.cs`

```csharp
using Swashbuckle.AspNetCore.Filters;

builder.Services.AddSwaggerGen(c =>
{
    c.EnableAnnotations();
    c.ExampleFilters();    // habilita os exemplos do pacote
});

// registra as classes de exemplo
builder.Services.AddSwaggerExamplesFromAssemblyOf<Program>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
```

##### Criando Diretório

```markdown
Doc/
└── Samples/
    ├── ClienteRequestSample.cs
    ├── ClienteResponseListSample.cs
    └── ClienteResponseSample.cs
```

## Criando as classes com exemplos

```csharp
public class ClienteRequestSample : IExamplesProvider<ClienteEntity>
{
	public ClienteEntity GetExamples()
	{
		return new ClienteEntity
		{
			Id = 6,
			Nome = "Joao Silta",
			Email = "joao.silva@outlook.com",
			EstadoId = 5,
		};
	}
}
```


```csharp
public class ClienteResponseSample : IExamplesProvider<ClienteEntity>

{
	public ClienteEntity GetExamples()
	{
		return new ClienteEntity
		{
			Id = 1,
			Nome = "Marcos Oliveira",
			Email = "marcos.oliveira@outlook.com",
			EstadoId = 5,
		};
	}
}
```


```csharp
public class ClienteResponseListSample : IExamplesProvider<IEnumerable<ClienteEntity>>
{
	public IEnumerable<ClienteEntity> GetExamples()
	{
		return new List<ClienteEntity>
		{
			new ClienteEntity {
				Id = 1,
				Nome = "Marcos Oliveira",
				Email = "marcos.oliveira@outlook.com",
				EstadoId = 5,
			},
			new ClienteEntity {
				Id = 2,
				Nome = "Alex Ferreira",
				Email = "alex.ferreira@outlook.com",
				EstadoId = 5,
			}
		};
	}
}
```

#### Implementando nos métodos da controller

```csharp
[HttpGet]
[SwaggerOperation(
   Summary = "Lista clientes",
   Description = "Retorna a lista completa de clientes cadastrados."
)]

[SwaggerResponse(statusCode: 200, description: "Lista retornada com sucesso", type: typeof(IEnumerable<ClienteEntity>))]
[SwaggerResponse(statusCode: 201, description: "Não possui dados para o cliente")]

[SwaggerResponseExample(statusCode: 200, typeof(ClienteResponseListSample))]
public async Task<IActionResult> Get()

{
	...
}
```

```csharp
[HttpPost]
[SwaggerRequestExample(typeof(ClienteEntity), typeof(ClienteRequestSample))]

[SwaggerResponse(statusCode: 200, description: "Cliente salvo como sucesso", typeof(ClienteEntity))]

[SwaggerResponseExample(statusCode: 200, typeof(ClienteResponseSample))]
public IActionResult Post(ClienteDto entity)

{
	....
}
```


```csharp
[HttpPut("{id}")]
[SwaggerOperation(
	Summary = "Editar cliente"
)]
[SwaggerRequestExample(typeof(ClienteEntity), typeof(ClienteRequestSample))]

[SwaggerResponse(statusCode: 200, description: "Dados do cliente alterados com sucesso", type: typeof(ClienteEntity))]
[SwaggerResponseExample(statusCode: 200, typeof(ClienteResponseSample))]
public IActionResult Put(
[FromRoute, SwaggerParameter("Identificador único do cliente no sistema")] int id, 
PostClienteDto model)
{
	....
}
```

##### Utilizado `SwaggerParameter`

Para adicionar descrição nos parametros dos metodos

```csharp
public IActionResult Put(

[FromRoute, SwaggerParameter("Identificador único")] int id, 
PostClienteDto model

)
{
	....
}
```