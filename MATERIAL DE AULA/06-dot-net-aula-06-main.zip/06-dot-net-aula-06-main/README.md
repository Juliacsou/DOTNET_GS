**Tópicos Abordados**

- Operation Result 
	- Adicionando na Application
	- Organizando Logs
	- Retornando as informações na Controller
- Erros Customizados
	- Retornando erros no Repository


#### Operation Result

O padrão `OperationResult<T>` é muito útil quando você aplica **Clean Architecture** porque ele centraliza a forma como **sucessos e erros são retornados** da **camada Application** para a **camada Presentation (Controllers)**.

##### Problema sem `OperationResult`

Se você não usa esse padrão, cada **caso de uso (Application)** precisaria:

- Retornar o objeto (`Cliente`, `Produto`, etc.);
- Lidar com erros lançando exceções;
- A Controller ficaria responsável por transformar exceções em `BadRequest`, `NotFound`, etc.
    
Isso gera muito **código repetido** dentro das controllers, e a **Application** fica inconsistente (algumas retornam exceções, outras `null`, outras objetos).

##### Solução com `OperationResult`

Ao usar `OperationResult<T>`:

- A **Application** sempre retorna um contrato único (`Success` ou `Failure`);
- O **status code** já é definido dentro da Application (ex.: `404` quando não encontra, `400` para erro de validação, etc.);
- A Controller só precisa **ler o resultado** e repassar para o ASP.NET.

Criando a classe `OperationResult` nas entidades na camada de domínio.

```csharp
public class OperationResult<T>  
{  
    public bool IsSuccess { get; private set; }  
    public string? Error { get; private set; }  
    public int StatusCode { get; private set; } = 200;  
    public T? Value { get; private set; }  
  
    private OperationResult() { }  
  
    public static OperationResult<T> Success(T value, int statusCode = 200)  
        => new OperationResult<T> { IsSuccess = true, Value = value, StatusCode = statusCode };  
  
    public static OperationResult<T> Failure(string error, int statusCode = 400)  
        => new OperationResult<T> { IsSuccess = false, Error = error, StatusCode = statusCode };  
}
```


#### Criando Interface de IClienteUseCase

```csharp
public interface IClienteUseCase  
{  
    Task<OperationResult<PageResultModel<IEnumerable<ClienteEntity>>>> ObterTodosClientesAsync(int Deslocamento = 0, int ResgistrosRetornado = 3);  
    Task<OperationResult<ClienteEntity?>> ObterUmClienteAsync(int Id);  
    Task<OperationResult<ClienteEntity?>> AdicionarClienteAsync(ClienteDto entity);  
    Task<OperationResult<ClienteEntity?>> EditarClienteAsync(int Id, ClienteDto entity);  
    Task<OperationResult<ClienteEntity?>> DeletarClienteAsync(int Id);  
    Task<OperationResult<ProdutoEntity?>> EditarProdutoClienteAsync(int Id, int ClienteId, ProdutoDto entity);  
    Task<OperationResult<ProdutoEntity?>> AdicionarProdutoClienteAsync(int ClienteId, ProdutoDto entity);  
}
```

#### Criando classes de ClienteUseCase

```csharp
public class ClienteUseCase : IClienteUseCase  
{  
    private readonly IClienteRepository _clienteRepository;  
  
    public ClienteUseCase(IClienteRepository clienteRepository)  
    {  
        _clienteRepository = clienteRepository;  
    }
    
    ....
}
```

##### Criando os métodos AdicionarClienteAsync

```c#
public async Task<OperationResult<ClienteEntity?>> AdicionarClienteAsync(ClienteDto entity)  
{  
    try  
    {  
        var result = await _clienteRepository.AdicionarAsync(entity.ToClienteEntity());  
  
        return OperationResult<ClienteEntity?>.Success(result, (int)HttpStatusCode.OK);  
    }  
    catch (Exception)  
    {  
        return OperationResult<ClienteEntity?>.Failure("Ocorreu um erro ao salvar o cliente", (int)HttpStatusCode.BadRequest);  
    }  
}
```

##### Criando os métodos DeletarClienteAsync

```c#
public async Task<OperationResult<ClienteEntity?>> DeletarClienteAsync(int Id)  
{  
    try  
    {  
        var result = await _clienteRepository.DeletarAsync(Id);  
  
        return OperationResult<ClienteEntity?>.Success(result, (int)HttpStatusCode.OK);  
    }  
    catch (Exception)  
    {  
        return OperationResult<ClienteEntity?>.Failure("Ocorreu um erro ao deletar o cliente", (int)HttpStatusCode.BadRequest);  
    }  
}
```

##### Criando os métodos EditarClienteAsync

```c#
public async Task<OperationResult<ClienteEntity?>> EditarClienteAsync(int Id, ClienteDto entity)  
{  
    try  
    {  
        var result = await _clienteRepository.EditarAsync(Id, entity.ToClienteEntity());  
  
        return OperationResult<ClienteEntity?>.Success(result, (int)HttpStatusCode.OK);  
    }  
    catch (Exception)  
    {  
        return OperationResult<ClienteEntity?>.Failure("Ocorreu um erro ao editar o cliente", (int)HttpStatusCode.BadRequest);  
    }  
}
```

##### Criando os métodos EditarProdutoClienteAsync

```c#
public async Task<OperationResult<ProdutoEntity?>> EditarProdutoClienteAsync(int Id, int ClienteId, ProdutoDto entity)  
{  
    try  
    {  
        var result = await _clienteRepository.EditarProdutoAsync(Id, ClienteId, entity.ToProdutoEntity());  
  
        return OperationResult<ProdutoEntity?>.Success(result, (int)HttpStatusCode.OK);  
    }  
    catch (Exception)  
    {  
        return OperationResult<ProdutoEntity?>.Failure("Ocorreu um erro ao editar o produto", (int)HttpStatusCode.BadRequest);  
    }  
}
```

##### Criando os métodos ObterTodosClientesAsync

```c#
public async Task<OperationResult<PageResultModel<IEnumerable<ClienteEntity>>>> ObterTodosClientesAsync(int Deslocamento = 0, int ResgistrosRetornado = 3)  
{  
    var result = await _clienteRepository.ObterTodosAsync(Deslocamento, ResgistrosRetornado);  
  
    if (!result.Data.Any())  
        return OperationResult<PageResultModel<IEnumerable<ClienteEntity>>>.Failure("", (int)HttpStatusCode.NoContent);  
  
  
    return OperationResult<PageResultModel<IEnumerable<ClienteEntity>>>.Success(result, (int)HttpStatusCode.OK);  
}
```

##### Criando os métodos ObterUmClienteAsync

```c#
public async Task<OperationResult<ClienteEntity?>> ObterUmClienteAsync(int Id)  
{  
    var result = await _clienteRepository.ObterUmAsync(Id);  
  
    if (result is null)  
        return OperationResult<ClienteEntity?>.Failure("", (int)HttpStatusCode.NotFound);  
  
    return OperationResult<ClienteEntity?>.Success(result, (int)HttpStatusCode.OK);  
  
  
}
```

#### Erros Customizados

Usar **exceções customizadas** serve para representar **erros específicos do domínio ou da lógica de negócio** da aplicação, de forma mais clara e controlada.  
Em vez de lançar uma exceção genérica (`Exception`), criamos uma classe que comunica exatamente **o que deu errado**.

###### Principais motivos:

1. **Clareza semântica**
    - Facilita entender o que aconteceu apenas pelo tipo da exceção.
    - Exemplo: `NoContentException` é muito mais claro que um simples `Exception`.
        
2. **Tratamento específico de erros**
    - Permite capturar apenas o erro desejado no `catch`.
    
```c# 
try
{
    BuscarCliente("123");
}
catch (NoContentException ex)
{
    // Tratar o erro quando não retorna dados
}
catch (Exception ex)
{
    // Tratar outros erros genéricos
}

```
    
3. **Melhor manutenção e depuração**
    - O tipo da exceção revela o contexto do erro, ajudando no debug e nos logs.
        
4. **Separação de camadas**
    - Camadas como _Domain_, _Application_ e _Infrastructure_ podem ter exceções próprias, tornando os erros **mais expressivos** e desacoplados.

##### Criando arquivo `NoContentException`

**Diretório deve ficar assim:**

```css
...

├─ 2 - Domain
│  └─ Revisao.Domain
│     ├─ Dependencies
│     ├─ Entities
│     ├─ Errors
│     │  └─ NoContentException.cs
│     └─ Interfaces

...
```

A nova classe deve herdar de `Exception` em C# é a base de **todas as exceções** no .NET.
Ela representa erros que ocorrem durante a execução do programa e fornece propriedades úteis como:

- `Message`: descrição do erro;
- `StackTrace`: o caminho da pilha onde ocorreu o erro;
- `InnerException`: exceção interna que causou o erro atual.

**A nova classe de excessão deve ficar assim:**

```c#
public class NoContentException : Exception  
{  
    public NoContentException()  
    {  
    }  
  
    public NoContentException(string? message) : base(message)  
    {  
        //Log  
        Console.WriteLine($"Erro - {message} - {DateTime.UtcNow.ToString()}");  
    }  
}
```

##### Ajustando o Repository

Lance uma excessão utilizando o `throw` com a nova classe, que representa a falta de conteúdo.

**Excluindo um cliente:**

```c#
public async Task<ClienteEntity?> DeletarAsync(string Id)  
{  
    var result = await _context.Cliente.FindAsync(ObjectId.Parse(Id));  
  
    if (result is null) throw new NoContentException("Não existe conteudo para cliente");  
  
    if (result is not null)  
    {  
        _context.Remove(result);  
        _context.SaveChanges();  
  
        return result;  
    }  
  
    return null;  
}
```

**Buscando um cliente:**

```c#
public async Task<ClienteEntity?> ObterUmAsync(string Id)  
{  
    var result = await _context  
        .Cliente  
        .FirstOrDefaultAsync(x => x.Id == ObjectId.Parse(Id));  
  
    if (result is null) throw new NoContentException("Não existe conteudo para cliente");  
  
    return result;  
}
```

**Buscando todos os clientes:**

```c#
public async Task<PageResultModel<IEnumerable<ClienteEntity>>> ObterTodosAsync(int Deslocamento = 0, int ResgistrosRetornado = 3)  
{  
  
    var totalRegistros = await _context.Cliente.CountAsync();  
  
    var result = await _context  
        .Cliente   
        .Skip(Deslocamento)  
        .Take(ResgistrosRetornado)  
        .ToListAsync();  
  
    if (!result.Any()) throw new NoContentException("Não existe conteudo para cliente");  
  
    return new PageResultModel<IEnumerable<ClienteEntity>>  
    {  
        Data = result,  
        Deslocamento = Deslocamento,  
        RegistroRetornados = ResgistrosRetornado,  
        TotalRegistros = totalRegistros  
    };  
}
```


##### Ajustando Application

**Excluindo um cliente:**

```c#
public async Task<OperationResult<ClienteResponseDto?>> DeletarClienteAsync(string Id)  
{  
    try  
    {  
        var result = await _clienteRepository.DeletarAsync(Id);  
  
        return OperationResult<ClienteResponseDto?>.Success(result?.ToClienteDto());  
    }  
    catch (NoContentException ex)  
    {  
        return OperationResult<ClienteResponseDto?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);  
    }  
    catch (Exception)  
    {  
        return OperationResult<ClienteResponseDto?>.Failure("Ocorreu um erro ao salvar o cliente");  
    }  
}
```

**Buscando um cliente:**

```c#
public async Task<OperationResult<ClienteResponseDto?>> ObterUmClienteAsync(string Id)  
{  
    try  
    {  
        var result = await _clienteRepository.ObterUmAsync(Id);  
  
        return OperationResult<ClienteResponseDto?>.Success(result?.ToClienteDto());  
    }  
    catch (NoContentException ex)  
    {  
        return OperationResult<ClienteResponseDto?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);  
    }  
    catch (Exception)  
    {  
        return OperationResult<ClienteResponseDto?>.Failure("Ocorreu um erro ao buscar o cliente");  
    }  
}
```

**Buscando todos os clientes:**

```c#
public async Task<OperationResult<PageResultModel<IEnumerable<ClienteResponseDto>>>> ObterTodosClientesAsync(int Deslocamento = 0, int ResgistrosRetornado = 3)  
{  
    try  
    {  
        var result = await _clienteRepository.ObterTodosAsync(Deslocamento, ResgistrosRetornado);  
  
        return OperationResult<PageResultModel<IEnumerable<ClienteResponseDto>>>.Success(result.ToClienteDto());  
    }  
    catch (NoContentException ex)  
    {  
        return OperationResult<PageResultModel<IEnumerable<ClienteResponseDto>>>.Failure(ex.Message, (int)HttpStatusCode.NoContent);  
    }  
    catch (Exception)  
    {  
        //Log ILogger  
        return OperationResult<PageResultModel<IEnumerable<ClienteResponseDto>>>.Failure("Ocorreu um erro ao buscar os clientes");  
    }  
}
```