﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace AspNET.API.Domain.Entities
{
    [Table("tb_curso")]
    public class CursoEntity
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Nome { get; set; } = string.Empty;

        [JsonIgnore]
        public ICollection<ClienteEntity>? Clientes { get; set; } = [];
    }
}
