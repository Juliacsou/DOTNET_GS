﻿namespace AspNET.API.Domain.Entities
{
    public class PedidoItensEntity
    {
        public int ProdutoId { get; set; }
        public double Valor { get; set; }
    }
}
