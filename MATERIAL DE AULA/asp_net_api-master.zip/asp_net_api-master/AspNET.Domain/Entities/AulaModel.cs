﻿using System.ComponentModel.DataAnnotations;

namespace AspNET.API.Domain.Entities
{
    public class AulaModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "O campo nome nao pode ser vazio")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "O campo nao pode ter menos que 3 caracteres")]
        public string Nome { get; set; }
        [EmailAddress(ErrorMessage = "O email esta invalido")]
        public string Email { get; set; }
    }
}
