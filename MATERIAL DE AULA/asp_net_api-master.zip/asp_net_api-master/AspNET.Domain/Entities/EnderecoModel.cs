﻿namespace AspNET.API.Domain.Entities
{
    public class EnderecoModel
    {
        public string Cep { get; set; }
        public string Logradouro { get; set; }
        public string Bairro { get; set; }
        public string Uf { get; set; }
    }
}
