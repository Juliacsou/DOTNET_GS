﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AspNET.API.Domain.Entities
{
    [Table("tb_cliente")]
    [Index(nameof(Email), nameof(Idade))] // Indice Composto
    //[Index(nameof(Email), IsUnique = true, Name = "IDX_EMAIL")]
    public class ClienteEntity
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(100, MinimumLength = 3)]
        [Column("c_nome")]
        public string Nome { get; set; }
        [Required]
        [Column("c_email")]
        public string Email { get; set; }
        [Column("c_idade")]
        public int Idade { get; set; }

        //1:1
        public EstadoEntity? Estado { get; set; }

        //1:N
        public ICollection<ProdutoEntity>? Produtos { get; set; }

        //N:N
        public ICollection<CursoEntity>? Cursos { get; set; } = [];
    }
}
