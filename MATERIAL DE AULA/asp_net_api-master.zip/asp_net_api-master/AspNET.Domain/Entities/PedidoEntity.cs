﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel.DataAnnotations.Schema;

namespace AspNET.API.Domain.Entities
{
    [Table("tb_pedido")]
    public class PedidoEntity
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public ObjectId Id { get; set; }
        public int ClienteId { get; set; }
        public string NumeroPedido { get; set; } = string.Empty;

        public ICollection<PedidoItensEntity> Itens { get; set; } = [];
    }
}
