﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace AspNET.API.Domain.Entities
{
    [Table("tb_estado")]
    public class EstadoEntity
    {
        [Key]
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;

        [ForeignKey(nameof(ClienteEntity))]
        public int ClienteId { get; set; }

        [JsonIgnore]
        public ClienteEntity? Cliente { get; set; }
    }
}
