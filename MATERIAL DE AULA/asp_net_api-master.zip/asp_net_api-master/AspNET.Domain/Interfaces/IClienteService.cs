﻿using AspNET.API.Domain.Entities;

namespace AspNET.API.Domain.Interfaces
{
    public interface IClienteService
    {
        Task<EnderecoModel?> ObterEnderecoPorCepAsync(string cep);
    }
}
