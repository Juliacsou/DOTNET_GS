﻿using AspNET.API.Domain.Entities;

namespace AspNET.API.Domain.Interfaces
{
    public interface IClienteRepository
    {
        Task<(IEnumerable<ClienteEntity> data, int rowsCount)> ObterTodosAsync(int Deslocamento, int RegistroRetornado);
        Task<IEnumerable<ClienteEntity>> ObterTodosMaiorDeIdadeAsync(int idade);
        ClienteEntity? ObterUm(int Id);
        ClienteEntity? Adicionar(ClienteEntity entity);
        ClienteEntity? Editar(int Id, ClienteEntity entity);
        ClienteEntity? Deletar(int Id);


        ProdutoEntity? AdicionarProduto(ProdutoEntity entity, int clienteId);
        ProdutoEntity? EditarProduto(ProdutoEntity entity, int produtoId, int clienteId);

        CursoEntity? AdicionarCurso(CursoEntity entity, int clienteId);
        CursoEntity? EditarCurso(CursoEntity entity, int cursoId);
    }
}
