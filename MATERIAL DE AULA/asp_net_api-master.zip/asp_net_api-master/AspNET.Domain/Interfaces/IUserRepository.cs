﻿using AspNET.API.Domain.Entities;

namespace AspNET.API.Domain.Interfaces
{
    public interface IUserRepository
    {
        Task<UserEntity?> AdicionarAsync(UserEntity entity);
        Task<UserEntity?> AutenticaAsync(string email, string password);
    }
}
