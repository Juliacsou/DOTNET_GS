﻿using AspNET.API.Domain.Entities;

namespace AspNET.API.Domain.Interfaces
{
    public interface IPedidoRepository
    {
        (IEnumerable<PedidoEntity> data, int rowsCount) ObterTodos(int Deslocamento, int RegistroRetornado);
        PedidoEntity? ObterUm(string Id);
        PedidoEntity? Adicionar(PedidoEntity entity);

        PedidoEntity? AdicionarItem(string PedidoId, PedidoItensEntity entity);
    }
}
