﻿using AspNET.API.Application.Dtos;
using AspNET.API.Application.Interfaces;
using AspNET.API.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Pedido.API.Controllers
{
    [Route("api/pedido")]
    [ApiController]
    public class PedidoController : ControllerBase
    {
        private readonly IPedidoUseCase _pedidoUseCase;

        public PedidoController(IPedidoUseCase pedidoUseCase)
        {
            _pedidoUseCase = pedidoUseCase;
        }

        [HttpGet]
        public IActionResult Get(int Deslocamento, int RegistroRetornado)
        {
            var resultado = _pedidoUseCase.ObterTodosPedidos(Deslocamento, RegistroRetornado);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            var resultado = _pedidoUseCase.ObterUmPedido(id);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPost]
        public IActionResult Post(PostPedidoDto model)
        {
            var resultado = _pedidoUseCase.AdicionarPedido(model);
            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPost("{pedidoId}/item")]
        public IActionResult PostItem(string pedidoId, PedidoItensEntity model)
        {
            var resultado = _pedidoUseCase.AdicionarItemPedido(pedidoId, model);
            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }
    }
}
