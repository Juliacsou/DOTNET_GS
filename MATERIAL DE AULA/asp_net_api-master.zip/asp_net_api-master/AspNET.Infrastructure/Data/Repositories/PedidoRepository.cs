﻿using AspNET.API.Domain.Entities;
using AspNET.API.Domain.Errors;
using AspNET.API.Domain.Interfaces;
using MongoDB.Bson;

namespace AspNET.API.Infrastructure.Data.Repositories
{
    public class PedidoRepository : IPedidoRepository
    {
        private readonly MongoApplicationContext _context;

        public PedidoRepository(MongoApplicationContext context)
        {
            _context = context;
        }

        public PedidoEntity? Adicionar(PedidoEntity entity)
        {
            try
            {
                _context.Pedido.Add(entity);
                _context.SaveChanges();

                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public PedidoEntity? AdicionarItem(string PedidoId, PedidoItensEntity entity)
        {
            try
            {
                var pedido = _context
                    .Pedido
                    .FirstOrDefault(x => x.Id == ObjectId.Parse(PedidoId));

                if (pedido is null) throw new NoContentException("Não foi encotrado o pedido");

                pedido.Itens ??= [];

                //if (pedido.Itens is null)
                //    pedido.Itens = new List<PedidoItensEntity>();

                pedido.Itens.Add(entity);

                _context.SaveChanges();

                return pedido;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public (IEnumerable<PedidoEntity> data, int rowsCount) ObterTodos(int Deslocamento, int RegistroRetornado)
        {
            try
            {
                if (Deslocamento < 0) Deslocamento = 0;
                if (RegistroRetornado <= 0) RegistroRetornado = 30;

                var todosRegistros = _context.Pedido.Count();

                var resultado = _context
                    .Pedido
                    .OrderBy(x => x.Id)
                    .Skip(Deslocamento)
                    .Take(RegistroRetornado)
                    .ToList();

                if (!resultado.Any()) throw new NoContentException("Não foi encotrado o Pedido");

                return (resultado, todosRegistros);
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public PedidoEntity? ObterUm(string Id)
        {
            try
            {
                var pedido = _context
                    .Pedido
                    .FirstOrDefault(x => x.Id == ObjectId.Parse(Id));

                if (pedido is null) throw new NoContentException("Não foi encotrado o pedido");

                return pedido;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
    }
}
