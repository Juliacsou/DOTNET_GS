﻿using AspNET.API.Domain.Entities;
using AspNET.API.Domain.Errors;
using AspNET.API.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace AspNET.API.Infrastructure.Data.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationContext _context;

        public UserRepository(ApplicationContext context)
        {
            _context = context;
        }

        public async Task<UserEntity?> AdicionarAsync(UserEntity entity)
        {
            try
            {
                await _context.Usuario.AddAsync(entity);
                await _context.SaveChangesAsync();

                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<UserEntity?> AutenticaAsync(string email, string password)
        {
            try
            {
                // var hashPassword = GeraHash(password)

                var usuario = await _context
                    .Usuario
                    .FirstOrDefaultAsync(x => x.Email == email && x.Password == password);

                if (usuario is null) throw new NoContentException("Não foi encotrado o usuario para esta credecial");

                return usuario;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
    }
}
