﻿using AspNET.API.Domain.Entities;
using AspNET.API.Domain.Errors;
using AspNET.API.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace AspNET.API.Infrastructure.Data.Repositories
{
    public class ClienteRepository : IClienteRepository
    {
        private readonly ApplicationContext _context;

        public ClienteRepository(ApplicationContext context)
        {
            _context = context;
        }

        public ClienteEntity? Adicionar(ClienteEntity entity)
        {
            try
            {
                //Insert into tb_cliente (coluna) values (campos, campos, ....)
                _context.Cliente.Add(entity);
                _context.SaveChanges();

                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }



        public ClienteEntity? Deletar(int Id)
        {
            try
            {
                //var cliente = _context.Cliente.Find(id); //Sempre utiliza a coluna do anotacao Key (PrimaryKey)
                var cliente = _context.Cliente.FirstOrDefault(x => x.Id == Id);

                if (cliente is null) throw new NoContentException("Não foi encotrado o cliente");

                _context.Cliente.Remove(cliente);
                _context.SaveChanges();

                return cliente;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public ClienteEntity? Editar(int Id, ClienteEntity entity)
        {
            try
            {
                //var cliente = _context.Cliente.Find(id); //Sempre utiliza a coluna do anotacao Key (PrimaryKey)
                var cliente = _context
                    .Cliente
                    .Include(x => x.Estado)
                    .FirstOrDefault(x => x.Id == Id);

                if (cliente is null) throw new NoContentException("Não foi encotrado o cliente");

                cliente.Nome = entity.Nome;
                cliente.Email = entity.Email;
                cliente.Idade = entity.Idade;

                if (cliente.Estado is null)
                {
                    cliente.Estado = new EstadoEntity
                    {
                        Nome = entity.Estado?.Nome ?? "SP"
                    };
                }
                else
                    cliente.Estado.Nome = entity.Estado?.Nome ?? "SP";

                _context.Cliente.Update(cliente);
                _context.SaveChanges();

                return cliente;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<(IEnumerable<ClienteEntity> data, int rowsCount)> ObterTodosAsync(int Deslocamento = 0, int RegistroRetornado = 30)
        {
            try
            {
                if (Deslocamento < 0) Deslocamento = 0;
                if (RegistroRetornado <= 0) RegistroRetornado = 30;

                var todosRegistros = await _context.Cliente.CountAsync();

                // Select * From tb_cliente
                var resultado = await _context
                    .Cliente
                    .Include(x => x.Estado) //inner join 
                    .Include(x => x.Produtos)
                    .Include(x => x.Cursos)
                    .OrderBy(x => x.Id)
                    .Skip(Deslocamento)
                    .Take(RegistroRetornado)
                    .ToListAsync();

                if (!resultado.Any()) throw new NoContentException("Não foi encotrado o clientes");

                return (resultado, todosRegistros);
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public ClienteEntity? ObterUm(int Id)
        {
            try
            {
                var cliente = _context
                    .Cliente
                    .Include(x => x.Estado) //inner join 
                    .Include(x => x.Produtos)
                    .Include(x => x.Cursos)
                    .FirstOrDefault(x => x.Id == Id);

                if (cliente is null) throw new NoContentException("Não foi encotrado o cliente");

                return cliente;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public CursoEntity? AdicionarCurso(CursoEntity entity, int clienteId)
        {
            try
            {
                var cliente = _context.Cliente.FirstOrDefault(x => x.Id == clienteId);

                if (cliente is null) throw new NoContentException("Não foi encotrado o curso");

                var curso = new CursoEntity
                {
                    Nome = entity.Nome,
                    Clientes = [cliente]
                };

                _context.Curso.Add(curso);
                _context.SaveChanges();

                return curso;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public CursoEntity? EditarCurso(CursoEntity entity, int cursoId)
        {
            try
            {
                var curso = _context
                    .Curso
                    .FirstOrDefault(x => x.Id == cursoId);

                if (curso is null) throw new NoContentException("Não foi encotrado o curso");

                curso.Nome = entity.Nome;

                _context.Curso.Update(curso);
                _context.SaveChanges();

                return curso;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
        public ProdutoEntity? AdicionarProduto(ProdutoEntity entity, int clienteId)
        {
            try
            {
                entity.ClienteId = clienteId;

                _context.Produto.Add(entity);
                _context.SaveChanges();

                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public ProdutoEntity? EditarProduto(ProdutoEntity entity, int produtoId, int clienteId)
        {
            try
            {
                var produto = _context
                    .Produto
                    .Include(x => x.Cliente)
                    .FirstOrDefault(x => x.Id == produtoId && x.ClienteId == clienteId);

                if (produto is null) throw new NoContentException("Não foi encotrado o produto");

                produto.Nome = entity.Nome;
                produto.Preco = entity.Preco;

                _context.Produto.Update(produto);
                _context.SaveChanges();

                return produto;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<IEnumerable<ClienteEntity>> ObterTodosMaiorDeIdadeAsync(int idade)
        {
            try
            {
                var resultado = await _context
                    .Cliente
                    .Where(x => x.Idade >= idade)
                    .ToListAsync();

                if (!resultado.Any()) throw new NoContentException("Não foi encotrado o clientes");

                return resultado;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
    }
}
