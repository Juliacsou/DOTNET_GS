﻿using AspNET.API.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace AspNET.API.Infrastructure.Data
{
    public class MongoApplicationContext : DbContext
    {
        public MongoApplicationContext(DbContextOptions<MongoApplicationContext> options) : base(options)
        {
            
        }

        public DbSet<PedidoEntity> Pedido { get; set; }
    }
}
