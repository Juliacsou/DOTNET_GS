﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AspNET.API.Migrations
{
    /// <inheritdoc />
    public partial class addindexcliente : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "c_email",
                table: "tb_cliente",
                type: "NVARCHAR2(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "NVARCHAR2(2000)");

            migrationBuilder.CreateIndex(
                name: "IX_tb_cliente_c_email_c_idade",
                table: "tb_cliente",
                columns: new[] { "c_email", "c_idade" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_tb_cliente_c_email_c_idade",
                table: "tb_cliente");

            migrationBuilder.AlterColumn<string>(
                name: "c_email",
                table: "tb_cliente",
                type: "NVARCHAR2(2000)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "NVARCHAR2(450)");
        }
    }
}
