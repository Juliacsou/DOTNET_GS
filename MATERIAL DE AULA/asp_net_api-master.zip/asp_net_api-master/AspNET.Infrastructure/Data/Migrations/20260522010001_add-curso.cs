﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AspNET.API.Migrations
{
    /// <inheritdoc />
    public partial class addcurso : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tb_curso",
                columns: table => new
                {
                    Id = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    Nome = table.Column<string>(type: "NVARCHAR2(100)", maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tb_curso", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ClienteEntityCursoEntity",
                columns: table => new
                {
                    ClientesId = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    CursosId = table.Column<int>(type: "NUMBER(10)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClienteEntityCursoEntity", x => new { x.ClientesId, x.CursosId });
                    table.ForeignKey(
                        name: "FK_ClienteEntityCursoEntity_tb_cliente_ClientesId",
                        column: x => x.ClientesId,
                        principalTable: "tb_cliente",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ClienteEntityCursoEntity_tb_curso_CursosId",
                        column: x => x.CursosId,
                        principalTable: "tb_curso",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ClienteEntityCursoEntity_CursosId",
                table: "ClienteEntityCursoEntity",
                column: "CursosId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ClienteEntityCursoEntity");

            migrationBuilder.DropTable(
                name: "tb_curso");
        }
    }
}
