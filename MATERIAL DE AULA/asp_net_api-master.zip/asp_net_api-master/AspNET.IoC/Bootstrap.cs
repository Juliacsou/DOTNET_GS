﻿using AspNET.API.Application.Interfaces;
using AspNET.API.Application.UseCases;
using AspNET.API.Domain.Interfaces;
using AspNET.API.Infrastructure.Data;
using AspNET.API.Infrastructure.Data.Repositories;
using AspNET.API.Infrastructure.Service;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace AspNET.API.Infrastructure.IoC
{
    public static class Bootstrap
    {

        public static void AddIoC(IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<ApplicationContext>(options => {
                options.UseOracle(configuration.GetConnectionString("Oracle"));
            });

            services.AddDbContext<MongoApplicationContext>(options => {
                options.UseMongoDB(configuration.GetConnectionString("Mongodb") ?? "", "Aula01");
            });

            services.AddTransient<IPedidoRepository, PedidoRepository>();
            services.AddTransient<IPedidoUseCase, PedidoUseCase>();



            services.AddTransient<IUserRepository, UserRepository>();
            services.AddTransient<IUserUseCase, UserUseCase>();



            services.AddTransient<IClienteRepository, ClienteRepository>();
            services.AddTransient<IClienteUseCase, ClienteUseCase>();


            services.AddTransient<IClienteService, ClienteService>();
        }
    }
}
