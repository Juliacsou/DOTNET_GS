﻿using AspNET.API.Application.Dtos;
using AspNET.API.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace AspNET.API.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserUseCase _userUseCase;

        public AuthController(IUserUseCase userUseCase)
        {
            _userUseCase = userUseCase;
        }


        [HttpPost]
        public async Task<IActionResult> Post(PostAuthDto model)
        {
            var resultado = await _userUseCase.AutenticaUserAsync(model);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }
    }
}
