﻿using Microsoft.AspNetCore.Mvc;

namespace AspNET.API.Controllers
{
    [Route("api/introducao")]
    [ApiController]
    public class IntroducaoController : ControllerBase
    {
        [HttpGet]
        public string Get()
        {
            return "Aula Teste";
        }

        [HttpGet("status")]
        public IActionResult GetStatus()
        { 
            return BadRequest("Aula Teste");
        }

        [HttpPost("{id}")]
        public string Post(Teste model, int id)
        {
            return $"Aula Teste - {id}";
        }

        [HttpPut]
        public string Put()
        {
            return "Aula Teste";
        }

        [HttpDelete]
        public string Delete()
        {
            return "Aula Teste";
        }
    }

    public record Teste(string nome);
}
