﻿using AspNET.API.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace AspNET.API.Controllers
{
    [Route("api/aula")]
    [ApiController]
    public class AulaController : ControllerBase
    {
        //Banco de dados Fake
        private static readonly List<AulaModel> _aula =
        [
            new AulaModel { Id = 1, Nome = "Aluno 1", Email = "aluno1@aula.com" },
            new AulaModel { Id = 2, Nome = "Aluno 2", Email = "aluno2@aula.com" }
        ];

        [HttpGet]
        public IActionResult Listar()
        {
            if (!_aula.Any())
                return NoContent();

            return Ok(_aula);
        }

        [HttpGet("{id}")]
        public IActionResult ObtePorId(int id)
        {
            var aula = _aula.FirstOrDefault(a => a.Id == id);

            if (aula is null)
                return NotFound(new { msg = $"Não foi encontrado o registro para esse id: {id}" });

            return Ok(aula);
        }

        [HttpPost]
        public IActionResult Criar(AulaModel model)
        {
            _aula.Add(model);

            return Ok(model);
        }

        [HttpPut("{id}")]
        public IActionResult Editar(int id, AulaModel model)
        {
            var aula = _aula.FirstOrDefault(a => a.Id == id);

            if (aula is null)
                return NotFound(new { msg = $"Não foi encontrado o registro para esse id: {id}" });

            aula.Nome = model.Nome;
            aula.Email = model.Email;

            _aula[_aula.IndexOf(aula)] = aula;

            return Ok(aula);
        }

        [HttpDelete("{id}")]
        public IActionResult Deletar(int id)
        {
            var aula = _aula.FirstOrDefault(a => a.Id == id);

            if (aula is null)
                return NotFound(new { msg = $"Não foi encontrado o registro para esse id: {id}" });

            _aula.Remove(aula);

            return Ok(aula);
        }
    }
}
