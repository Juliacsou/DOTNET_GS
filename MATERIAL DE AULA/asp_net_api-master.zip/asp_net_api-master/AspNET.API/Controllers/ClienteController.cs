﻿using AspNET.API.Application.Dtos;
using AspNET.API.Application.Interfaces;
using AspNET.API.Doc.Samples;
using AspNET.API.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Swashbuckle.AspNetCore.Annotations;
using Swashbuckle.AspNetCore.Filters;

namespace AspNET.API.Controllers
{
    //[Authorize(Roles = "admin,gerente")]
    [Route("api/cliente")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly ILogger<ClienteController> _logger;
        private readonly IClienteUseCase _clienteUseCase;

        public ClienteController(IClienteUseCase clienteUseCase, ILogger<ClienteController> logger)
        {
            _clienteUseCase = clienteUseCase;
            _logger = logger;
        }

        /// <summary>
        /// "Lista todos os clientes"
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Authorize(Roles = "admin,gerente")]
        [SwaggerOperation(
            Summary = "Lista todos os clientes",
            //Description = "Metodo para retornar todos os clientes do banco de dados"
            Description = """
            ## 📋 Informações do Retorno:
            * **Status 200 (OK):** Retorna uma lista contendo todos os clientes localizados.
            * **Status 204 (No Content):** Executado com sucesso, porém a base não possui registros cadastrados.
            * **Status 400 (Bad Request):** Ocorreu uma falha durante a consulta (ex: erro de conexão com o banco).

            ## 💡 Observações:
            * Os dados incluem as entidades relacionadas (como **Estado**).
            """
        )]
        [SwaggerResponse(statusCode: 200, description: "Listagem de dados retornado com sucesso", type: typeof(IEnumerable<ClienteEntity>))]
        [SwaggerResponse(statusCode: 204, description: "Cliente não possui dados")]
        [SwaggerResponse(statusCode: 400, description: "Ocorreu um erro ao retornar os dados", type: typeof(string))]
        [SwaggerResponseExample(statusCode: 200, typeof(ClienteResponseListSample))]
        [EnableRateLimiting("politica_5_tentativas")]
        public async Task<IActionResult> Get(int Deslocamento, int RegistroRetornado)
        {
            var resultado = await _clienteUseCase.ObterTodosClientesAsync(Deslocamento, RegistroRetornado);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "admin,gerente")]
        [SwaggerOperation(
            Summary = "Obter cliente"
        )]
        [SwaggerResponse(statusCode: 200, description: "Dados retornado com sucesso", type: typeof(ClienteEntity))]
        [SwaggerResponseExample(statusCode: 200, typeof(ClienteResponseSample))]
        public IActionResult Get(int id)
        {
            var resultado = _clienteUseCase.ObterUmClientes(id);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpGet("maior/idade")]
        [SwaggerOperation(
            Summary = "Obter cliente maior de idade"
        )]
        public async Task<IActionResult> GetMaiorDeIdade()
        {
            var resultado = await _clienteUseCase.ObterTodosClientesMaioresDeIdadeAsync(18);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }


        [HttpPost]
        [Authorize(Roles = "admin")]
        [SwaggerOperation(
            Summary = "Adicionar cliente"
        )]
        [SwaggerRequestExample(typeof(ClienteEntity), typeof(ClienteRequestSample))]

        [SwaggerResponse(statusCode: 201, description: "Cliente criado com sucesso", typeof(ClienteEntity))]
        [SwaggerResponseExample(statusCode: 201, typeof(ClienteResponseSample))]
        public IActionResult Post(ClienteRequestDto model)
        {
            var resultado = _clienteUseCase.AdicionarClientes(model);
            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPut("{id}")]
        [SwaggerOperation(
            Summary = "Editar cliente"
        )]
        public IActionResult Put([FromRoute, SwaggerParameter("Id do cliente")] int id, ClienteRequestDto model)
        {
            var resultado = _clienteUseCase.EditarClientes(id, model);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpDelete("{id}")]
        [SwaggerOperation(
            Summary = "Deletar cliente"
        )]
        public IActionResult Delete(int id)
        {
            var resultado = _clienteUseCase.DeletarClientes(id);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }


        [HttpPost("produto/cliente/{idcliente}")]
        [SwaggerOperation(
            Summary = "Adicionar produto"
        )]
        [SwaggerResponse(statusCode: 201, description: "Produto criado com sucesso")]
        public IActionResult PostProduto(int idcliente, ProdutoRequestDto model)
        {
            var resultado = _clienteUseCase.AdicionarProdutoNoCliente(model, idcliente);
            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPut("produto/{id}/cliente/{idcliente}")]
        [SwaggerOperation(
            Summary = "Adicionar produto"
        )]
        [SwaggerResponse(statusCode: 201, description: "Produto criado com sucesso")]
        public IActionResult PutProduto(int id, int idcliente, ProdutoRequestDto model)
        {
            var resultado = _clienteUseCase.EditarProdutoNoCliente(model, id, idcliente);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }


        [HttpPost("curso/cliente/{idcliente}")]
        [SwaggerOperation(
            Summary = "Adicionar curso"
        )]
        [SwaggerResponse(statusCode: 201, description: "Curso criado com sucesso")]
        public IActionResult PostCurso(int idcliente, CursoRequestDto model)
        {
            var resultado = _clienteUseCase.AdicionarCursoNoCliente(model, idcliente);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPut("curso/{id}")]
        [SwaggerOperation(
             Summary = "Editar curso"
         )]
        [SwaggerResponse(statusCode: 201, description: "Curso alterado com sucesso")]
        public IActionResult PutCurso(int id, CursoRequestDto model)
        {
            var resultado = _clienteUseCase.EditarCursoNoCliente(model, id);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpGet("endereco/{cep}")]
        [SwaggerOperation(
            Summary = "Obter endereço por cep"
        )]
        [SwaggerResponse(statusCode: 200, description: "Endereço retornado com sucesso", type: typeof(EnderecoModel))]
        public async Task<IActionResult> GetEndereco(string cep)
        {
            var resultado = await _clienteUseCase.ObterEnderecoPorCepAsync(cep);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpGet("insights")]
        public async Task<IActionResult> GetInsights()
        {
            var resultado = await _clienteUseCase.ObterInsightsAsync();

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }
    }
}
