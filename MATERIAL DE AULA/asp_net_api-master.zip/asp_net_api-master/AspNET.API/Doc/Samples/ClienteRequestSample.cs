﻿using AspNET.API.Application.Dtos;
using Swashbuckle.AspNetCore.Filters;

namespace AspNET.API.Doc.Samples
{
    public class ClienteRequestSample : IExamplesProvider<ClienteRequestDto>
    {
        public ClienteRequestDto GetExamples()
        {
            return new ClienteRequestDto
            {
                Nome = "Clietne 1",
                Idade = 18,
                Email = "cliente1@teste.com",
                Estado = "SP",
                Cursos = new List<CursoRequestDto>
                    {
                        new CursoRequestDto { Nome = "Curso 1" },
                        new CursoRequestDto { Nome = "Curso 2" },
                    },
                Produtos = new List<ProdutoRequestDto>
                    {
                        new ProdutoRequestDto { Nome = "Produto 1", Preco = 10.0 },
                        new ProdutoRequestDto { Nome = "Produto 2", Preco = 35.48 },
                    }
            };
        }
    }
}
