﻿using AspNET.API.Domain.Entities;
using Swashbuckle.AspNetCore.Filters;

namespace AspNET.API.Doc.Samples
{

    public class ClienteResponseSample : IExamplesProvider<ClienteEntity>
    {
        public ClienteEntity GetExamples()
        {
            return new ClienteEntity
            {
                Id = 1,
                Nome = "Clietne 1",
                Idade = 18,
                Email = "cliente1@teste.com",
                Estado = new EstadoEntity { Id = 1, Nome = "SP" },
                Cursos = new List<CursoEntity>
                    {
                        new CursoEntity { Id = 1, Nome = "Curso 1" },
                        new CursoEntity { Id = 2, Nome = "Curso 2" },
                    },
                Produtos = new List<ProdutoEntity>
                    {
                        new ProdutoEntity { Id = 1, Nome = "Produto 1", Preco = 10.0 },
                        new ProdutoEntity { Id = 2, Nome = "Produto 2", Preco = 35.48 },
                    }
            };
        }
    }
}
