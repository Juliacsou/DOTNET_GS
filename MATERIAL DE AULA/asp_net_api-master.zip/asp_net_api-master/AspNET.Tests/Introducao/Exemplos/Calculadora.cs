﻿namespace AspNET.Tests.Introducao.Exemplos
{
    internal class Calculadora
    {
        public double Somar(double valor1, double valor2)
        {
            var soma = valor1 + valor2;

            if (soma == 80)
                return 50;

            return soma;
        }
    }
}
