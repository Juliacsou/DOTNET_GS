﻿using AspNET.Tests.Introducao.Exemplos;

namespace AspNET.Tests.Introducao
{
    public class CalculadoraTest
    {
        [Fact(DisplayName = "Deve Retonar a Soma")]
        [Trait("Exemplos", "Soma")]
        public void Somar_DeveRetornarSomaCorreta()
        {
            // Arrange - Preparar
            var calculadora = new Calculadora();

            double numero1 = 10;
            double numero2 = 5;


            // Act - Agir
            var retorno = calculadora.Somar(numero1, numero2);


            // Assert - Verificar
            Assert.Equal(15, retorno);
        }

        [Fact(DisplayName = "Deve Retonar a Soma igual 40")]
        [Trait("Exemplos", "Soma")]
        public void Somar_DeveRetornarSomaCorreta_40()
        {
            // Arrange - Preparar
            var calculadora = new Calculadora();

            double numero1 = 20;
            double numero2 = 20;


            // Act - Agir
            var retorno = calculadora.Somar(numero1, numero2);

            // Assert - Verificar

            Assert.NotNull(calculadora);

            Assert.True(retorno >= 20, "O valor deve ser maior ou igual a 20");

            Assert.Equal(40, retorno);

        }

        [Fact(DisplayName = "Deve Retonar a Soma igual 50")]
        [Trait("Exemplos", "Soma")]
        public void Somar_DeveRetornarSomaCorreta_50()
        {
            // Arrange - Preparar
            var calculadora = new Calculadora();

            double numero1 = 40;
            double numero2 = 40;


            // Act - Agir
            var retorno = calculadora.Somar(numero1, numero2);


            // Assert - Verificar
            Assert.Equal(50, retorno);
        }
    }
}
