﻿using AspNET.API.Application.Dtos;
using AspNET.API.Application.Mappers;
using AspNET.API.Application.UseCases;
using AspNET.API.Domain.Entities;
using AspNET.API.Domain.Interfaces;
using Microsoft.Extensions.Logging;
using Moq;

namespace AspNET.Tests.App
{
    public class ClienteUseCaseTest
    {
        private readonly Mock<ILogger<ClienteUseCase>> _loggerMock;
        private readonly Mock<IClienteRepository> _clienteRepository;
        private readonly Mock<IClienteService> _clienteService;
        private readonly ClienteUseCase _clienteUseCase;

        public ClienteUseCaseTest()
        {
            _clienteRepository = new Mock<IClienteRepository>();
            _clienteService = new Mock<IClienteService>();
            _loggerMock = new Mock<ILogger<ClienteUseCase>>();

            // Isso é o que vamos testar
            _clienteUseCase = new ClienteUseCase(_clienteRepository.Object, _loggerMock.Object, _clienteService.Object);
        }


        [Fact]
        [Trait("UseCase", "Clientes")]
        public void ObterUm_DeveRetonarUmClientes()
        {
            //Arrange  

            int idCliente = 1;

            var cliente = new ClienteEntity { Id = 1, Nome = "Carlos", Email = "cliente1@teste.com" };

            //Prepara o repository
            _clienteRepository.Setup(obj => obj.ObterUm(idCliente)).Returns(cliente);

            //Act  
            var resultado = _clienteUseCase.ObterUmClientes(1);

            //Assert  
            Assert.NotNull(resultado);
            Assert.Equal(idCliente, resultado.Value?.Id);
            Assert.Equal(cliente.Nome, resultado.Value?.Nome);
        }

        [Fact]
        [Trait("UseCase", "Clientes")]
        public void AdicionarAsync_DeveRetonarTodosOsClientes()
        {
            //Arrange  
            var clienteDto = new ClienteRequestDto { Nome = "Carlos", Email = "cliente1@teste.com", Idade = 10 };

            var entity = clienteDto.ToClienteEntity();

            _clienteRepository.Setup(obj => obj.Adicionar(It.IsAny<ClienteEntity>())).Returns(entity);

            //Act  
            var resultado = _clienteUseCase.AdicionarClientes(clienteDto);

            //Assert  
            Assert.NotNull(resultado);

            Assert.Equal(clienteDto.Nome, resultado!.Value?.Nome);
            Assert.Equal(clienteDto.Email, resultado!.Value?.Email);
            Assert.Equal(clienteDto.Idade, resultado!.Value?.Idade);
        }
    }
}
