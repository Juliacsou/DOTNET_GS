﻿using AspNET.API.Application.Dtos;
using AspNET.API.Application.Interfaces;
using AspNET.API.Domain.Entities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Moq;
using System.Net;

namespace AspNET.Tests.App
{

    public class CustomWebApplicationFactory : WebApplicationFactory<Program>
    {
        public Mock<IClienteUseCase> ClienteUseCaseMock { get; set; } = new();

        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.ConfigureServices(services =>
            {
                services.RemoveAll(typeof(IClienteUseCase));
                services.AddSingleton(ClienteUseCaseMock.Object);
            });
        }
    }

    public class ClienteControllerTest : IClassFixture<CustomWebApplicationFactory>
    {
        private readonly CustomWebApplicationFactory _factory;

        public ClienteControllerTest(CustomWebApplicationFactory factory)
        {
            _factory = factory;
        }

        [Fact]
        [Trait("Controller", "Cliente")]
        public async Task Get_DeveRetornarOK()
        {
            // Arrange  
            var cliente = new GetClienteDto { Nome = "João", Email = "joao.silva@example.com", Idade = 30 };

            var operationResult = OperationResult<GetClienteDto?>.Success(cliente);
 
            _factory.ClienteUseCaseMock.Setup(x => x.ObterUmClientes(1)).Returns(operationResult);

            using var client = _factory.CreateClient();

            // Act
            var response = await client.GetAsync("api/cliente/1");

            // Assert
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }
    }
}
