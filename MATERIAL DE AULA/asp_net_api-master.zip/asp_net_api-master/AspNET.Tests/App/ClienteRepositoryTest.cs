﻿using AspNET.API.Domain.Entities;
using AspNET.API.Infrastructure.Data;
using AspNET.API.Infrastructure.Data.Repositories;
using Microsoft.EntityFrameworkCore;

namespace AspNET.Tests.App
{
    public class ClienteRepositoryTest
    {
        private readonly DbContextOptions<ApplicationContext> _options;
        private readonly ApplicationContext _applicationContext;
        private readonly ClienteRepository _clienteRepository;

        public ClienteRepositoryTest()
        {
            _options = new DbContextOptionsBuilder<ApplicationContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            _applicationContext = new ApplicationContext(_options);

            _applicationContext.Database.EnsureDeleted();
            _applicationContext.Database.EnsureCreated();

            // Isso é o que vamos testar
            _clienteRepository = new ClienteRepository(_applicationContext);
        }


        [Fact]
        [Trait("Repository", "Clientes")]
        public async Task ObterTodos_DeveRetornarClientes()
        {
            // Arrange
            var clientes = new List<ClienteEntity> {
                new ClienteEntity { Nome = "João", Email = "joao.silva@example.com", Idade = 30 },
                new ClienteEntity { Nome = "Maria", Email = "maria.silva@example.com", Idade = 25 },
                new ClienteEntity { Nome = "Pedro", Email = "pedro.silva@example.com", Idade = 40 }
            };

            //Adicionando no banco em memoria
            _applicationContext.Cliente.AddRange(clientes);
            _applicationContext.SaveChanges();

            // Act
            var resultado = await _clienteRepository.ObterTodosAsync(0, 10);

            // Assert
            Assert.NotNull(resultado.data);
            Assert.Equal(3, resultado.data.Count());

            Assert.Collection(resultado.data,
                cliente =>
                {
                    Assert.Equal("João", cliente.Nome);
                    Assert.Equal("joao.silva@example.com", cliente.Email);
                    Assert.Equal(30, cliente.Idade);
                },

                cliente =>
                {
                    Assert.Equal("Maria", cliente.Nome);
                    Assert.Equal("maria.silva@example.com", cliente.Email);
                    Assert.Equal(25, cliente.Idade);
                },

                cliente =>
                {
                    Assert.Equal("Pedro", cliente.Nome);
                    Assert.Equal("pedro.silva@example.com", cliente.Email);
                    Assert.Equal(40, cliente.Idade);
                });
        }


        [Fact]
        [Trait("Repository", "Clientes")]
        public void ObterUm_DeveRetornarUmCliente()
        {
            // Arrange
            var cliente = new ClienteEntity
            {
                Id = 1,
                Nome = "João",
                Email = "joao.silva@example.com",
                Idade = 30
            };

            _applicationContext.Cliente.Add(cliente);
            _applicationContext.SaveChanges();

            // Act
            var resultado = _clienteRepository.ObterUm(1);

            // Assert
            Assert.NotNull(resultado);
            Assert.Equal(cliente.Id, resultado.Id);
            Assert.Equal(cliente.Nome, resultado.Nome);
            Assert.Equal(cliente.Email, resultado.Email);
            Assert.Equal(cliente.Idade, resultado.Idade);
        }



        [Fact]
        [Trait("Repository", "Clientes")]
        public void Adicionar_DeveAdicionarCliente()
        {
            // Arrange
            var cliente = new ClienteEntity
            {
                Nome = "João",
                Email = "joao.silva@example.com",
                Idade = 30
            };

            // Act
            var resultado = _clienteRepository.Adicionar(cliente);

            // Assert
            var idCliente = resultado?.Id ?? -1; //Buscar o ultimo ID Inserido

            var clienteNoDb = _applicationContext.Cliente.FirstOrDefault(c => c.Id == idCliente);

            Assert.NotNull(clienteNoDb);

            Assert.Equal(cliente.Nome, clienteNoDb.Nome);
            Assert.Equal(cliente.Email, clienteNoDb.Email);
            Assert.Equal(cliente.Idade, clienteNoDb.Idade);
        }
    }
}
