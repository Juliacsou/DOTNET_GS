﻿using System.ComponentModel.DataAnnotations;

namespace AspNET.API.Application.Dtos
{
    public class CursoRequestDto
    {
        [Required]
        public string Nome { get; set; }
    }
}
