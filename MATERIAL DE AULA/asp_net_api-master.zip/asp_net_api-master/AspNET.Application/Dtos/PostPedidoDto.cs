﻿namespace AspNET.API.Application.Dtos
{
    public class PostPedidoDto
    {
        public int ClienteId { get; set; }
        public string NumeroPedido { get; set; } = string.Empty;
    }
}
