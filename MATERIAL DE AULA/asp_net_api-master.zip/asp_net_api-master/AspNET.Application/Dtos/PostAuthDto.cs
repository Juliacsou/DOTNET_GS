﻿namespace AspNET.API.Application.Dtos
{
    public class PostAuthDto
    {
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}
