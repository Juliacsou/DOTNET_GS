﻿namespace AspNET.API.Application.Dtos
{
    public class GetAuthDto
    {
        public string Email { get; set; }
        public string Jwt { get; set; }
    }
}
