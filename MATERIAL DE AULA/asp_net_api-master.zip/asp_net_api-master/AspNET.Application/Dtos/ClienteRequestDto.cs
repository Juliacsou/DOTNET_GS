﻿using System.ComponentModel.DataAnnotations;

namespace AspNET.API.Application.Dtos
{
    public class ClienteRequestDto
    {
        [Required]
        [StringLength(100, MinimumLength = 3)]
        public string Nome { get; set; }
        [EmailAddress]
        public string Email { get; set; }
        public int Idade { get; set; }
        [Required]
        public string Estado { get; set; }

        public IEnumerable<ProdutoRequestDto>? Produtos { get; set; }

        public IEnumerable<CursoRequestDto>? Cursos { get; set; }
    }
}
