﻿using AspNET.API.Domain.Entities;

namespace AspNET.Application.Dtos
{
    public class GetInsightsDto
    {
        public required IEnumerable<ClienteEntity> Dados { get; set; }
        public string InsightsMarkdown { get; set; } = string.Empty;
    }
}
