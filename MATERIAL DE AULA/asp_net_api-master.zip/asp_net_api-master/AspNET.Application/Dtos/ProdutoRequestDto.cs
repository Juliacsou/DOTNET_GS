﻿namespace AspNET.API.Application.Dtos
{
    public class ProdutoRequestDto
    {
        public string Nome { get; set; }
        public double Preco { get; set; }
    }
}
