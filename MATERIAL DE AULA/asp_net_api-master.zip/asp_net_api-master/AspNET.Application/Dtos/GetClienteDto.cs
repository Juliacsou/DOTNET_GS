﻿using AspNET.API.Domain.Entities;

namespace AspNET.API.Application.Dtos
{
    public class GetClienteDto
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public int Idade { get; set; }
        public string Estado { get; set; }

        public IEnumerable<ProdutoEntity>? Produtos { get; set; }

        public IEnumerable<CursoEntity>? Cursos { get; set; } = [];

        public List<LinkDto> Links { get; set; } = new();
    }
}
