﻿using AspNET.API.Domain.Entities;

namespace AspNET.API.Application.Dtos
{

    public class GetPedidoDto
    {
        public string Id { get; set; }
        public int ClienteId { get; set; }
        public string NumeroPedido { get; set; } = string.Empty;

        public IEnumerable<PedidoItensEntity> Itens { get; set; } = [];
    }
}
