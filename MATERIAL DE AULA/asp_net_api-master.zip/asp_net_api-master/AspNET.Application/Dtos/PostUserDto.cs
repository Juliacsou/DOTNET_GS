﻿using System.ComponentModel.DataAnnotations;

namespace AspNET.API.Application.Dtos
{
    public class PostUserDto
    {
        [Required]
        public string Nome { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required(ErrorMessage = "A senha é obrigatória.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required(ErrorMessage = "A confirmação de senha é obrigatória.")]
        [DataType(DataType.Password)]
        [Compare(nameof(Password), ErrorMessage = "As Senhas não conferem")]
        public string ConfirmPassword { get; set; }
        [Required]
        public string Role { get; set; }
    }
}
