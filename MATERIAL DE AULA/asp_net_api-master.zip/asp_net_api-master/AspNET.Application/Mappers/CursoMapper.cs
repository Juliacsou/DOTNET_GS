﻿using AspNET.API.Application.Dtos;
using AspNET.API.Domain.Entities;

namespace AspNET.API.Application.Mappers
{
    public static class CursoMapper
    {
        public static CursoEntity ToCursoEntity(this CursoRequestDto model)
        {
            return new CursoEntity
            {
                Nome = model.Nome,
            };
        }
    }
}
