﻿using AspNET.API.Application.Dtos;
using AspNET.API.Domain.Entities;

namespace AspNET.API.Application.Mappers
{
    public static class PedidoMapper
    {
        public static PedidoEntity ToPedidoEntity(this PostPedidoDto obj)
        {
            return new PedidoEntity
            {
                ClienteId = obj.ClienteId,
                NumeroPedido = obj.NumeroPedido,
            };
        }

        public static GetPedidoDto ToPedidoDto(this PedidoEntity obj)
        {
            return new GetPedidoDto
            {
                Id = obj.Id.ToString(),
                ClienteId = obj.ClienteId,
                NumeroPedido = obj.NumeroPedido,
                Itens = obj.Itens,
            };
        }
    }
}
