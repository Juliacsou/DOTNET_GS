﻿using AspNET.API.Application.Dtos;
using AspNET.API.Domain.Entities;

namespace AspNET.API.Application.Mappers
{
    public static class ClienteMapper
    {
        public static ClienteEntity ToClienteEntity(this ClienteRequestDto obj)
        {
            return new ClienteEntity
            {
                Nome = obj.Nome,
                Email = obj.Email,
                Idade = obj.Idade,
                Estado = new EstadoEntity
                {
                    Nome = obj.Estado
                },
                Produtos = obj.Produtos?.Select(x => new ProdutoEntity
                {
                    Nome = x.Nome,
                    Preco = x.Preco,
                })
                    .ToList(),
                Cursos = obj.Cursos?.Select(x => new CursoEntity
                {
                    Nome = x.Nome,
                })
                    .ToList()
            };
        }

        public static GetClienteDto ToClienteDto(this ClienteEntity obj, IEnumerable<LinkDto> links)
        {
            return new GetClienteDto
            {
                Id = obj.Id,
                Nome = obj.Nome,
                Email = obj.Email,
                Idade = obj.Idade,
                Estado = obj.Estado?.Nome ?? string.Empty,
                Produtos = obj.Produtos,
                Cursos = obj.Cursos,
                Links = links?.ToList() ?? Enumerable.Empty<LinkDto>().ToList(),
            };
        }
    }
}
