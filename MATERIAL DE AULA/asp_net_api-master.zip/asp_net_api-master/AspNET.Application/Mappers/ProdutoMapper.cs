﻿using AspNET.API.Application.Dtos;
using AspNET.API.Domain.Entities;

namespace AspNET.API.Application.Mappers
{
    public static class ProdutoMapper
    {
        public static ProdutoEntity ToProdutoEntity(this ProdutoRequestDto model)
        {
            return new ProdutoEntity
            {
                Nome = model.Nome,
                Preco = model.Preco,
            };
        }
    }
}
