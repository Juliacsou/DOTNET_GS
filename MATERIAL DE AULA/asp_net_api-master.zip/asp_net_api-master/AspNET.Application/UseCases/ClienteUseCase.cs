﻿using AspNET.API.Application.Dtos;
using AspNET.API.Application.Interfaces;
using AspNET.API.Application.Mappers;
using AspNET.API.Domain.Entities;
using AspNET.API.Domain.Errors;
using AspNET.API.Domain.Interfaces;
using AspNET.Application.Dtos;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text.Json;

namespace AspNET.API.Application.UseCases
{
    public class ClienteUseCase : IClienteUseCase
    {
        private readonly IChatClient _chatClient;
        private readonly ILogger<ClienteUseCase> _logger;
        private readonly IClienteRepository _clienteRepository;
        private readonly IClienteService _clienteService;

        public ClienteUseCase(IClienteRepository clienteRepository, 
            ILogger<ClienteUseCase> logger, 
            IClienteService clienteService,
            IChatClient chatClient)
        {
            _clienteService = clienteService;
            _clienteRepository = clienteRepository;
            _logger = logger;
            _chatClient = chatClient;
        }

        public OperationResult<ClienteEntity?> AdicionarClientes(ClienteRequestDto entity)
        {
            try
            {
                var result = _clienteRepository.Adicionar(entity.ToClienteEntity());

                return OperationResult<ClienteEntity?>.Success(result, (int)HttpStatusCode.OK);
            }
            catch (Exception)
            {
                return OperationResult<ClienteEntity?>.Failure("Ocorreu um erro ao salvar o cliente", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<ClienteEntity?> DeletarClientes(int Id)
        {
            try
            {
                var result = _clienteRepository.Deletar(Id);

                return OperationResult<ClienteEntity?>.Success(result, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<ClienteEntity?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception)
            {
                return OperationResult<ClienteEntity?>.Failure("Ocorreu um erro ao deletar o cliente", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<ClienteEntity?> EditarClientes(int Id, ClienteRequestDto entity)
        {
            try
            {
                var result = _clienteRepository.Editar(Id, entity.ToClienteEntity());

                return OperationResult<ClienteEntity?>.Success(result, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<ClienteEntity?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception)
            {

                return OperationResult<ClienteEntity?>.Failure("Ocorreu um erro ao editar o cliente", (int)HttpStatusCode.BadRequest);
            }
        }

        public async Task<OperationResult<PageResponseDto<GetClienteDto>>> ObterTodosClientesAsync(int Deslocamento, int RegistroRetornado)
        {
            try
            {
                _logger.LogInformation("Iniciando o ObterTodosClientesAsync na camada de application");
                var result = await _clienteRepository.ObterTodosAsync(Deslocamento, RegistroRetornado);

                var pageResponse = new PageResponseDto<GetClienteDto>
                {
                    //Items = result.data.Select(item => new GetClienteDto { 
                    //    Id = item.Id,
                    //    Nome = item.Nome,
                    //    Email = item.Email,
                    //    Idade = item.Idade,
                    //    Estado = item.Estado?.Nome ?? string.Empty,
                    //    Produtos = item.Produtos,
                    //    Cursos = item.Cursos,
                    //    Links = new List<LinkDto>
                    //    {
                    //        new LinkDto($"/api/cliente/{item.Id}", "get_cliente", "GET"),
                    //        new LinkDto($"/api/cliente/{item.Id}", "put_cliente", "PUT"),
                    //        new LinkDto($"/api/cliente/{item.Id}", "delete_cliente", "DELETE"),
                    //    }

                    //}),
                    Items = result.data.Select(item => item.ToClienteDto(new List<LinkDto>
                        {
                            new LinkDto($"/api/cliente/{item.Id}", "get_cliente", "GET"),
                            new LinkDto($"/api/cliente/{item.Id}", "put_cliente", "PUT"),
                            new LinkDto($"/api/cliente/{item.Id}", "delete_cliente", "DELETE"),
                        })
                    ),
                    Deslocamento = Deslocamento,
                    RegistroRetornado = RegistroRetornado,
                    TotalRegistros = result.rowsCount,
                    Links = new List<LinkDto>
                    {
                        new LinkDto($"/api/cliente?Deslocamento={Deslocamento}&RegistroRetornado={RegistroRetornado}", "self", "GET"),
                        new LinkDto("/api/cliente", "create_cliente", "POST")
                    }
                };

                return OperationResult<PageResponseDto<GetClienteDto>>.Success(pageResponse, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                _logger.LogWarning("Não retornou dados do banco para os parametros: D: {0} R: {1}", Deslocamento, RegistroRetornado);
                return OperationResult<PageResponseDto<GetClienteDto>>.Failure(ex.Message, (int)HttpStatusCode.NoContent);
            }
            catch (Exception ex)
            {
                _logger.LogError("[ERROR] - {0}", ex.Message);
                return OperationResult<PageResponseDto<GetClienteDto>>.Failure("Ocorreu um erro ao buscar todos os clientes", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<GetClienteDto?> ObterUmClientes(int Id)
        {
            try
            {
                _logger.LogInformation("Iniciando o ObterUmClientes na camada de application");
                var result = _clienteRepository.ObterUm(Id);

                var links = new List<LinkDto>
                {
                    new LinkDto($"/api/cliente/{Id}", "self", "GET"),
                    new LinkDto($"/api/cliente/{Id}", "put_cliente", "PUT"),
                    new LinkDto($"/api/cliente/{Id}", "delete_cliente", "DELETE"),
                };

                return OperationResult<GetClienteDto?>.Success(result?.ToClienteDto(links), (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                _logger.LogWarning("Não retornou dados do banco para os parametros: ID: {0}", Id);
                return OperationResult<GetClienteDto?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError("[ERROR] - {0}", ex.Message);
                return OperationResult<GetClienteDto?>.Failure("Ocorreu um erro ao obter um cliente", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<CursoEntity?> AdicionarCursoNoCliente(CursoRequestDto entity, int clienteId)
        {
            try
            {
                var result = _clienteRepository.AdicionarCurso(entity.ToCursoEntity(), clienteId);

                return OperationResult<CursoEntity?>.Success(result, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<CursoEntity?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception)
            {

                return OperationResult<CursoEntity?>.Failure("Ocorreu um erro ao salvar o curso", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<CursoEntity?> EditarCursoNoCliente(CursoRequestDto entity, int cursoId)
        {
            try
            {
                var result = _clienteRepository.EditarCurso(entity.ToCursoEntity(), cursoId);

                return OperationResult<CursoEntity?>.Success(result, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<CursoEntity?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception)
            {
                return OperationResult<CursoEntity?>.Failure("Ocorreu um erro ao editar o curso", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<ProdutoEntity?> AdicionarProdutoNoCliente(ProdutoRequestDto entity, int clienteId)
        {
            try
            {
                var result = _clienteRepository.AdicionarProduto(entity.ToProdutoEntity(), clienteId);

                return OperationResult<ProdutoEntity?>.Success(result, (int)HttpStatusCode.OK);
            }
            catch (Exception)
            {
                return OperationResult<ProdutoEntity?>.Failure("Ocorreu um erro ao salvar o produto", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<ProdutoEntity?> EditarProdutoNoCliente(ProdutoRequestDto entity, int produtoId, int clienteId)
        {
            try
            {
                var result = _clienteRepository.EditarProduto(entity.ToProdutoEntity(), produtoId, clienteId);

                return OperationResult<ProdutoEntity?>.Success(result, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<ProdutoEntity?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception)
            {
                return OperationResult<ProdutoEntity?>.Failure("Ocorreu um erro ao editar o produto", (int)HttpStatusCode.BadRequest);
            }
        }

        public async Task<OperationResult<IEnumerable<ClienteEntity>>> ObterTodosClientesMaioresDeIdadeAsync(int idade)
        {
            try
            {
                _logger.LogInformation("Iniciando o ObterTodosClientesMaioresDeIdadeAsync na camada de application");

                var result = await _clienteRepository.ObterTodosMaiorDeIdadeAsync(idade);

                return OperationResult<IEnumerable<ClienteEntity>>.Success(result, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<IEnumerable<ClienteEntity>>.Failure(ex.Message, (int)HttpStatusCode.NoContent);
            }
            catch (Exception)
            {
                return OperationResult<IEnumerable<ClienteEntity>>.Failure("Ocorreu um erro ao buscar todos os clientes maior de idade", (int)HttpStatusCode.BadRequest);
            }
        }

        public async Task<OperationResult<EnderecoModel?>> ObterEnderecoPorCepAsync(string cep)
        {
            try
            {
                _logger.LogInformation("Iniciando o ObterEnderecoPorCepAsync na camada de application");

                var result = await _clienteService.ObterEnderecoPorCepAsync(cep);

                return OperationResult<EnderecoModel?>.Success(result, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<EnderecoModel?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception)
            {
                return OperationResult<EnderecoModel?>.Failure("Ocorreu um erro ao obter o endereco por cep", (int)HttpStatusCode.BadRequest);
            }
        }

        public async Task<OperationResult<GetInsightsDto?>> ObterInsightsAsync()
        {
            try
            {
                _logger.LogInformation("Iniciando o ObterTodosClientesAsync na camada de application");

                var result = await _clienteRepository.ObterTodosAsync(0, 0);

                var dados = JsonSerializer.Serialize(result.data);

                var prompt = $"""
                        Você é um analista de negócios especializado em análise de
                        clientes, comportamento de consumo e oportunidades comerciais.
                        
                        Analise os dados dos clientes abaixo e gere um relatório
                        de insights em Markdown.
                        
                        Estruture o relatório com as seguintes seções:
                        
                        ## 1. Resumo geral
                        - Quantidade total de clientes.
                        - Idade média dos clientes.
                        - Estados representados na base.
                        
                        ## 2. Análise de compras
                        - Valor total dos produtos de cada cliente.
                        - Cliente com maior valor total em produtos.
                        - Produto de maior preço individual.
                        - Valor médio de produtos por cliente.
                        
                        ## 3. Análise de cursos
                        - Quantidade total de cursos associados aos clientes.
                        - Cliente com maior quantidade de cursos.
                        - Cursos que podem indicar interesses em comum.
                        
                        ## 4. Perfil dos clientes
                        - Identifique padrões de idade, localização e consumo.
                        - Compare os perfis dos clientes com base nos dados disponíveis.
                        
                        ## 5. Oportunidades comerciais
                        - Sugira três ações comerciais baseadas nos dados.
                        - Identifique oportunidades de venda cruzada entre produtos e cursos.
                        - Explique quais clientes podem ser alvos de cada oportunidade.
                        
                        ## 6. Conclusão
                        - Apresente os principais insights da análise.
                        - Destaque oportunidades que merecem atenção.
                        
                        Regras:
                        - Utilize somente informações presentes nos dados.
                        - Não invente valores, clientes, produtos ou cursos.
                        - Calcule os totais usando quantidade e preço dos produtos.
                        - Considere que cada preço representa o valor de uma unidade.
                        - Diferencie o maior preço individual do maior total por cliente.
                        - Se uma informação não puder ser calculada, informe isso.
                        - Escreva em português do Brasil.
                        - Utilize títulos, listas, tabelas e negrito em Markdown.
                        - Seja objetivo e apresente recomendações práticas.
                        
                        Dados dos clientes:
                        {dados}
                        """;

                var response = await _chatClient.GetResponseAsync(
                    prompt,
                    cancellationToken: CancellationToken.None);


                var insight = new GetInsightsDto
                {
                    Dados = result.data,
                    InsightsMarkdown = response.Text
                };


                return OperationResult<GetInsightsDto?>.Success(insight, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                _logger.LogWarning("Não retornou dados do banco para os parametros: D: {0} R: {1}", 0, 0);
                return OperationResult<GetInsightsDto?>.Failure(ex.Message, (int)HttpStatusCode.NoContent);
            }
            catch (Exception ex)
            {
                _logger.LogError("[ERROR] - {0}", ex.Message);
                return OperationResult<GetInsightsDto?>.Failure("Ocorreu um erro ao buscar todos os clientes", (int)HttpStatusCode.BadRequest);
            }
        }
    }
}
