﻿using AspNET.API.Application.Dtos;
using AspNET.API.Application.Interfaces;
using AspNET.API.Application.Mappers;
using AspNET.API.Domain.Entities;
using AspNET.API.Domain.Errors;
using AspNET.API.Domain.Interfaces;
using System.Net;

namespace AspNET.API.Application.UseCases
{
    public class PedidoUseCase : IPedidoUseCase
    {
        private readonly IPedidoRepository _pedidoRepository;

        public PedidoUseCase(IPedidoRepository pedidoRepository)
        {
            _pedidoRepository = pedidoRepository;
        }

        public OperationResult<GetPedidoDto?> AdicionarItemPedido(string PedidoId, PedidoItensEntity entity)
        {
            try
            {
                var result = _pedidoRepository.AdicionarItem(PedidoId, entity);

                return OperationResult<GetPedidoDto?>.Success(result?.ToPedidoDto(), (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<GetPedidoDto?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                return OperationResult<GetPedidoDto?>.Failure("Ocorreu um erro ao obter um pedido", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<GetPedidoDto?> AdicionarPedido(PostPedidoDto entity)
        {
            try
            {
                var result = _pedidoRepository.Adicionar(entity.ToPedidoEntity());

                return OperationResult<GetPedidoDto?>.Success(result?.ToPedidoDto(), (int)HttpStatusCode.OK);
            }
            catch (Exception)
            {
                return OperationResult<GetPedidoDto?>.Failure("Ocorreu um erro ao salvar o pedido", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<PageResponseDto<GetPedidoDto>> ObterTodosPedidos(int Deslocamento, int RegistroRetornado)
        {
            try
            {
                var result = _pedidoRepository.ObterTodos(Deslocamento, RegistroRetornado);

                var pageResponse = new PageResponseDto<GetPedidoDto>
                {
                    Items = result.data.Select(item => item.ToPedidoDto()),
                    Deslocamento = Deslocamento,
                    RegistroRetornado = RegistroRetornado,
                    TotalRegistros = result.rowsCount,
                    Links = new List<LinkDto>
                    {
                        new LinkDto($"/api/pedido?Deslocamento={Deslocamento}&RegistroRetornado={RegistroRetornado}", "self", "GET"),
                        new LinkDto("/api/pedido", "create_cliente", "POST")
                    }
                };

                return OperationResult<PageResponseDto<GetPedidoDto>>.Success(pageResponse, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<PageResponseDto<GetPedidoDto>>.Failure(ex.Message, (int)HttpStatusCode.NoContent);
            }
            catch (Exception ex)
            {
                return OperationResult<PageResponseDto<GetPedidoDto>>.Failure("Ocorreu um erro ao buscar todos os clientes", (int)HttpStatusCode.BadRequest);
            }
        }

        public OperationResult<GetPedidoDto?> ObterUmPedido(string Id)
        {
            try
            {
                var result = _pedidoRepository.ObterUm(Id);

                return OperationResult<GetPedidoDto?>.Success(result?.ToPedidoDto(), (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<GetPedidoDto?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                return OperationResult<GetPedidoDto?>.Failure("Ocorreu um erro ao obter um cliente", (int)HttpStatusCode.BadRequest);
            }
        }
    }
}
