﻿using AspNET.API.Application.Dtos;
using AspNET.API.Domain.Entities;

namespace AspNET.API.Application.Interfaces
{
    public interface IPedidoUseCase
    {
        OperationResult<PageResponseDto<GetPedidoDto>> ObterTodosPedidos(int Deslocamento, int RegistroRetornado);
        OperationResult<GetPedidoDto?> ObterUmPedido(string Id);
        OperationResult<GetPedidoDto?> AdicionarPedido(PostPedidoDto entity);

        OperationResult<GetPedidoDto?> AdicionarItemPedido(string PedidoId, PedidoItensEntity entity);
    }
}
