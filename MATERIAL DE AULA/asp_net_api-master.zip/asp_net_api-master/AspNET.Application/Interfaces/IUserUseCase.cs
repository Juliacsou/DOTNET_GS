﻿using AspNET.API.Application.Dtos;
using AspNET.API.Domain.Entities;

namespace AspNET.API.Application.Interfaces
{
    public interface IUserUseCase
    {
        Task<OperationResult<UserEntity?>> AdicionarUserAsync(PostUserDto entity);
        Task<OperationResult<GetAuthDto?>> AutenticaUserAsync(PostAuthDto model);
    }
}
