﻿using AspNET.API.Application.Dtos;
using AspNET.API.Domain.Entities;
using AspNET.Application.Dtos;

namespace AspNET.API.Application.Interfaces
{
    public interface IClienteUseCase
    {
        Task<OperationResult<PageResponseDto<GetClienteDto>>> ObterTodosClientesAsync(int Deslocamento, int RegistroRetornado);
        Task<OperationResult<IEnumerable<ClienteEntity>>> ObterTodosClientesMaioresDeIdadeAsync(int idade);
        OperationResult<GetClienteDto?> ObterUmClientes(int Id);
        OperationResult<ClienteEntity?> AdicionarClientes(ClienteRequestDto entity);
        OperationResult<ClienteEntity?> EditarClientes(int Id, ClienteRequestDto entity);
        OperationResult<ClienteEntity?> DeletarClientes(int Id);

        OperationResult<ProdutoEntity?> AdicionarProdutoNoCliente(ProdutoRequestDto entity, int clienteId);
        OperationResult<ProdutoEntity?> EditarProdutoNoCliente(ProdutoRequestDto entity, int produtoId, int clienteId);

        OperationResult<CursoEntity?> AdicionarCursoNoCliente(CursoRequestDto entity, int clienteId);
        OperationResult<CursoEntity?> EditarCursoNoCliente(CursoRequestDto entity, int cursoId);

        Task<OperationResult<EnderecoModel?>> ObterEnderecoPorCepAsync(string cep);

        Task<OperationResult<GetInsightsDto?>> ObterInsightsAsync();
    }
}
