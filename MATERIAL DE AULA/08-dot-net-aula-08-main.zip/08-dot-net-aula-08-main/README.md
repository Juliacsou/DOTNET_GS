**Tópicos Abordados**

- Hateaos
	- Usando Dtos de Retorno para resultados Unicos
	- Usando Dtos de Retorno para resultados em uma Lista
- Autenticação/Autorização

Nesta aula, avançamos na consolidação da nossa API desenvolvida em **ASP.NET Core 8**, aprofundando o princípio de **HATEOAS** através de DTOs dedicados de resposta para resultados únicos e em lista, além de implementar um módulo completo de segurança com **Autenticação e Autorização via JWT (JSON Web Token)**.

Os temas abordados nesta aula são:
1. **HATEOAS (Hypermedia as the Engine of Application State)**:
   - Conceito e importância da hipermídia em APIs RESTful.
   - Estrutura de links com `LinkDto`.
   - Usando DTOs de Retorno para resultados únicos (`GetClienteDto`).
   - Usando DTOs de Retorno para resultados em uma lista (`PageResponseDto<GetClienteDto>`).
2. **Autenticação e Autorização**:
   - Conceitos fundamentais: Autenticação ("Diz quem você é") vs Autorização ("Diz o que você pode fazer").
   - O que é JWT (JSON Web Token) e estrutura de claims.
   - Dependências e pacotes necessários (`Microsoft.AspNetCore.Authentication.JwtBearer`).
   - Configuração de credenciais e segredo (`Secretkey`).
   - Modelagem de dados de Usuário (`UserEntity`, `ApplicationContext` e Migrations).
   - Contratos e Repositório de Usuário (`IUserRepository` e `UserRepository`).
   - DTOs e Mappers de Usuário e Autenticação (`PostUserDto`, `PostAuthDto`, `GetAuthDto`, `UserMapper`).
   - Caso de Uso de Autenticação e Geração do Token JWT (`IUserUseCase` e `UserUseCase`).
   - Controllers de Apresentação (`UserController` e `AuthController`).
   - Configuração do pipeline e middlewares no `Program.cs`.
   - Configuração do Swagger com suporte a Bearer Token.
   - Proteção de Controllers e Endpoints (`[Authorize]`, `[AllowAnonymous]`, status 401/403 e autorização por Roles).
   - Injeção de dependências no `Bootstrap.cs`.

---

## 1. HATEOAS (Hypermedia as the Engine of Application State)

**HATEOAS (Hypermedia as the Engine of Application State)** é um princípio do estilo arquitetural REST que define que as respostas da API devem conter não apenas os dados solicitados, mas também links de navegação que orientam o cliente sobre as ações disponíveis para aquele recurso.

Dessa forma, ao buscar um cliente, por exemplo, a resposta pode incluir links para visualizar, atualizar ou excluir o registro, tornando a API autoexplicativa e permitindo que o consumidor descubra endpoints por meio da própria navegação.

### Principais Benefícios:
- **Redução da dependência de documentação externa:** o próprio payload indica os caminhos válidos.
- **Evolução segura da API:** rotas e ações podem mudar no backend sem quebrar clientes que navegam pelos links.
- **Interação dinâmica e desacoplada:** o cliente transita de estado guiado pela resposta da aplicação.

---

### Estrutura do DTO de Hipermídia: `LinkDto`

Para padronizar os links retornados pela API, utilizamos o DTO `LinkDto`, localizado em `Application/Dtos/LinkDto.cs`:

```csharp
namespace AspNet.API.Application.Dtos
{
    public class LinkDto
    {
        public string Href { get; set; } = string.Empty;
        public string Rel { get; set; } = string.Empty;
        public string Method { get; set; } = "GET";

        public LinkDto(string href, string rel, string method = "GET")
        {
            Href = href;
            Rel = rel;
            Method = method;
        }
    }
}
```

- **`Href`**: caminho ou URL do recurso (ex: `/api/cliente/1`).
- **`Rel`**: relação semântica do link com o recurso atual (ex: `"self"`, `"get_um_cliente"`, `"update_cliente"`, `"delete_cliente"`).
- **`Method`**: verbo HTTP exigido pela ação (`GET`, `POST`, `PUT`, `DELETE`).

---

### HATEOAS: Usando DTOs de Retorno para Resultados Únicos

Na versão anterior da aplicação, os métodos retornavam a própria entidade de domínio (`ClienteEntity`). Para desacoplar a camada de domínio da camada de apresentação e permitir o enriquecimento com hipermídia, criamos um DTO específico de saída: `GetClienteDto`.

#### Criando o `GetClienteDto`:

Localizado em `Application/Dtos/GetClienteDto.cs`:

```csharp
using AspNet.API.Domain.Entities;

namespace AspNet.API.Application.Dtos
{
    public class GetClienteDto
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public int Idade { get; set; }
        public string Estado { get; set; }

        public IEnumerable<ProdutoEntity>? Produtos { get; set; }

        public IEnumerable<CursoEntity>? Cursos { get; set; } = [];

        public List<LinkDto> Links { get; set; } = new();
    }
}
```

#### Mapeando Entidade para DTO com Links no `ClienteMapper`:

Localizado em `Application/Mappers/ClienteMapper.cs`, adicionamos um método de extensão que recebe os links e projeta a entidade no DTO de resposta:

```csharp
public static GetClienteDto ToClienteDto(this ClienteEntity obj, IEnumerable<LinkDto> links)
{
    return new GetClienteDto
    {
        Id = obj.Id,
        Nome = obj.Nome,
        Idade = obj.Idade,
        Email = obj.Email,
        Estado = obj.Estado?.Nome ?? string.Empty,
        Produtos = obj.Produtos,
        Cursos = obj.Cursos,
        Links = links?.ToList() ?? Enumerable.Empty<LinkDto>().ToList()
    };
}
```

#### Implementando no Caso de Uso (`ClienteUseCase.ObterUmCliente`):

No `IClienteUseCase`, o contrato do método passa a retornar `OperationResult<GetClienteDto?>`:

```csharp
public OperationResult<GetClienteDto?> ObterUmCliente(int Id)
{
    try
    {
        _logger.LogInformation("ObterUmCliente iniciado na application");
        var result = _clienteRepository.ObterUm(Id);

        var links = new List<LinkDto>
        {
            new LinkDto($"/api/cliente/{Id}", "get_um_cliente", "GET"),
            new LinkDto($"/api/cliente/{Id}", "update_cliente", "PUT"),
            new LinkDto($"/api/cliente/{Id}", "delete_cliente", "DELETE"),
        };

        return OperationResult<GetClienteDto?>.Success(result?.ToClienteDto(links), (int)HttpStatusCode.OK);
    }
    catch (NoContentException ex)
    {
        _logger.LogWarning("Nao retornou nenhuma informação do ObterUmCliente - Parametros: ID: {0}", Id);
        return OperationResult<GetClienteDto?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
    }
    catch (Exception ex)
    {
        _logger.LogError("[ERROR] - {0}", ex.Message);
        return OperationResult<GetClienteDto?>.Failure("Ocorreu um erro ao obter um cliente", (int)HttpStatusCode.BadRequest);
    }
}
```

#### Exemplo de Retorno JSON para Resultado Único:

Ao realizar uma requisição `GET /api/cliente/1`:

```json
{
  "id": 1,
  "nome": "João da Silva",
  "email": "joao@email.com",
  "idade": 30,
  "estado": "SP",
  "produtos": [],
  "cursos": [],
  "links": [
    {
      "href": "/api/cliente/1",
      "rel": "get_um_cliente",
      "method": "GET"
    },
    {
      "href": "/api/cliente/1",
      "rel": "update_cliente",
      "method": "PUT"
    },
    {
      "href": "/api/cliente/1",
      "rel": "delete_cliente",
      "method": "DELETE"
    }
  ]
}
```

---

### HATEOAS: Usando DTOs de Retorno para Resultados em uma Lista

Ao trabalhar com listas e paginação, o HATEOAS deve atuar em dois níveis:
1. **Nível de Item:** Cada item individual da lista possui seus próprios links para obter detalhes, atualizar ou deletar aquele registro específico.
2. **Nível da Lista (Página):** O container da página possui links globais para consultar a listagem atual (`self`) ou criar novos registros (`create_cliente`).

#### Estrutura do `PageResponseDto<T>`:

Localizado em `Application/Dtos/PageResponseDto.cs`:

```csharp
namespace AspNet.API.Application.Dtos
{
    public class PageResponseDto<T>
    {
        public IEnumerable<T> Items { get; set; } = new List<T>();
        public int Deslocamento { get; set; }
        public int RegistroRetornado { get; set; }
        public int TotalRegistros { get; set; }

        public List<LinkDto> Links { get; set; } = new();
    }
}
```

#### Implementando no Caso de Uso (`ClienteUseCase.ObterTodosClientes`):

O método `ObterTodosClientes` agora mapeia cada item retornado pelo repositório em um `GetClienteDto` com seus links individuais, além de anexar os links de escopo global no `PageResponseDto`:

```csharp
public OperationResult<PageResponseDto<GetClienteDto>> ObterTodosClientes(int Deslocamento, int RegistroRetornado)
{
    try
    {
        _logger.LogInformation("ObterTodos iniciado na application");
        var result = _clienteRepository.ObterTodos(Deslocamento, RegistroRetornado);

        var pageResponse = new PageResponseDto<GetClienteDto>
        {
            // Mapeando cada item da lista com seus próprios links de ação
            Items = result.data.Select(item => item.ToClienteDto(new List<LinkDto>
                {
                    new LinkDto($"/api/cliente/{item.Id}", "get_um_cliente", "GET"),
                    new LinkDto($"/api/cliente/{item.Id}", "update_cliente", "PUT"),
                    new LinkDto($"/api/cliente/{item.Id}", "delete_cliente", "DELETE"),
                })
            ),
            Deslocamento = Deslocamento,
            RegistroRetornado = RegistroRetornado,
            TotalRegistros = result.rowsCount,
            // Links globais da listagem paginada
            Links = new List<LinkDto>
            {
                new LinkDto($"/api/cliente?Deslocamento={Deslocamento}&RegistroRetornado={RegistroRetornado}", "self", "GET"),
                new LinkDto("/api/cliente", "create_cliente", "POST")
            }
        };

        return OperationResult<PageResponseDto<GetClienteDto>>.Success(pageResponse, (int)HttpStatusCode.OK);
    }
    catch (NoContentException ex)
    {
        _logger.LogWarning("Nao retornou nenhuma informação do ObterTodos - Parametros: D: {0} - R: {1}", Deslocamento, RegistroRetornado);
        return OperationResult<PageResponseDto<GetClienteDto>>.Failure(ex.Message, (int)HttpStatusCode.NoContent);
    }
    catch (Exception ex)
    {
        _logger.LogError("[ERROR] - {0}", ex.Message);
        return OperationResult<PageResponseDto<GetClienteDto>>.Failure("Ocorreu um erro ao buscar todos os clientes", (int)HttpStatusCode.BadRequest);
    }
}
```

#### Exemplo de Retorno JSON para Lista Paginada com HATEOAS:

Ao fazer uma requisição `GET /api/cliente?Deslocamento=0&RegistroRetornado=2`:

```json
{
  "items": [
    {
      "id": 1,
      "nome": "João da Silva",
      "email": "joao@email.com",
      "idade": 30,
      "estado": "SP",
      "produtos": [],
      "cursos": [],
      "links": [
        {
          "href": "/api/cliente/1",
          "rel": "get_um_cliente",
          "method": "GET"
        },
        {
          "href": "/api/cliente/1",
          "rel": "update_cliente",
          "method": "PUT"
        },
        {
          "href": "/api/cliente/1",
          "rel": "delete_cliente",
          "method": "DELETE"
        }
      ]
    },
    {
      "id": 2,
      "nome": "Maria Santos",
      "email": "maria@email.com",
      "idade": 25,
      "estado": "RJ",
      "produtos": [],
      "cursos": [],
      "links": [
        {
          "href": "/api/cliente/2",
          "rel": "get_um_cliente",
          "method": "GET"
        },
        {
          "href": "/api/cliente/2",
          "rel": "update_cliente",
          "method": "PUT"
        },
        {
          "href": "/api/cliente/2",
          "rel": "delete_cliente",
          "method": "DELETE"
        }
      ]
    }
  ],
  "deslocamento": 0,
  "registroRetornado": 2,
  "totalRegistros": 10,
  "links": [
    {
      "href": "/api/cliente?Deslocamento=0&RegistroRetornado=2",
      "rel": "self",
      "method": "GET"
    },
    {
      "href": "/api/cliente",
      "rel": "create_cliente",
      "method": "POST"
    }
  ]
}
```

---

## 2. Autenticação e Autorização

Em sistemas modernos, especialmente aqueles baseados em **APIs e aplicações web**, dois conceitos fundamentais garantem a segurança e o controle de acesso aos recursos: **autenticação** e **autorização**.  
Esses mecanismos são essenciais para proteger informações sensíveis, controlar o que cada usuário pode fazer e manter a integridade da aplicação.

### Autenticação: “Diz quem você é”

A **autenticação** é o processo responsável por **verificar a identidade de um usuário** ou serviço que tenta acessar o sistema.  
Em outras palavras, é o momento em que o sistema **confirma quem está tentando entrar**.

De forma prática, a autenticação normalmente ocorre quando o usuário fornece suas credenciais, como **e-mail e senha**, e o sistema valida essas informações em uma base de dados. Se os dados estiverem corretos, o sistema reconhece aquele usuário como legítimo e emite um comprovante de identidade (como um token criptográfico).

No **ASP.NET Core**, a autenticação pode ser implementada de várias formas:
- **JWT (JSON Web Token)**: amplamente utilizado em APIs RESTful por ser stateless (sem estado no servidor);
- **Cookies de autenticação**: padrão em aplicações web tradicionais com renderização no servidor (MVC / Razor Pages);
- **OAuth2 / OpenID Connect**: comum para login social e provedores corporativos (Google, Microsoft, Keycloak);
- **ASP.NET Core Identity**: framework completo para gerenciamento de usuários, senhas e perfis.

### Autorização: “Diz o que você pode fazer”

Após o usuário ser autenticado, o sistema precisa saber **quais ações ele tem permissão para executar**.  
É aqui que entra o processo de **autorização**, responsável por **controlar o acesso aos recursos** da aplicação com base em **perfis**, **funções (roles)** ou **políticas específicas**.

Por exemplo: tanto um administrador quanto um operador conseguem se autenticar no sistema. Porém, apenas o administrador terá autorização para excluir um cliente ou criar novos operadores.

No ASP.NET Core, a autorização é expressa principalmente através do atributo `[Authorize]`.

### Importância na Segurança das Aplicações

A combinação de autenticação e autorização proporciona:
- **Proteção de dados sensíveis:** apenas clientes autenticados acessam informações protegidas.
- **Controle granular de acesso:** restrições específicas por perfil (Admin, User, etc.).
- **Rastreabilidade e auditoria:** identificação de quem realizou cada operação por meio de claims.
- **Conformidade regulatória:** atendimento a legislações como LGPD e normas ISO 27001.

---

### O que é JWT (JSON Web Token)

**JWT (JSON Web Token)** é um padrão aberto (RFC 7519) que define uma forma compacta e autocontida para transmitir com segurança informações entre as partes como um objeto JSON.

O token é composto por três partes separadas por pontos (`.`):
1. **Header (Cabeçalho):** indica o tipo do token (`JWT`) e o algoritmo de assinatura (`HMAC-SHA256`).
2. **Payload (Carga Útil):** contém as **claims**, que são as declarações sobre a entidade (usuário) e metadados adicionais (nome, e-mail, perfil/role, expiração).
3. **Signature (Assinatura):** garante que o conteúdo do token não foi alterado após a emissão pelo servidor.

---

### Dependências

Para habilitar a autenticação JWT no projeto `AspNet.API`, adicionamos o pacote `Microsoft.AspNetCore.Authentication.JwtBearer`:

```bash
dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer
```

No arquivo `AspNet.API.csproj`, a referência é registrada:

```xml
<PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.31" />
```

---

### Configurando o Segredo (`Secretkey`)

A chave secreta é utilizada pelo servidor para assinar digitalmente o token e verificar sua validade em requisições futuras. Configuramos a `Secretkey` no arquivo `appsettings.Development.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "ConnectionStrings": {
    "Oracle": "Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=oracle.fiap.com.br)(PORT=1521))) (CONNECT_DATA=(SERVER=DEDICATED)(SID=ORCL)));User Id=;Password=;"
  },
  "ApplicationInsights": {
    "ConnectionString": ""
  },
  "Secretkey": "0Ioc4Lr0o5K5JvbRv88G84qn0BldVdGpHshzD0bG"
}
```

---

### Modelagem de Dados: Entidade de Usuário

#### Criando a `UserEntity`

Localizada em `Domain/Entities/UserEntity.cs`:

```csharp
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AspNet.API.Domain.Entities
{
    [Table("tb_usuario")]
    public class UserEntity
    {
        [Key]
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        [Required]
        public string Email { get; set; } = string.Empty;
        [Required]
        public string Password { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
    }
}
```

#### Adicionando o `DbSet` no `ApplicationContext`:

Em `Infrastructure/Data/ApplicationContext.cs`, incluímos a nova tabela de usuários:

```csharp
public class ApplicationContext : DbContext
{
    public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
    {
    }

    public DbSet<UserEntity> Usuario { get; set; }
    public DbSet<ClienteEntity> Cliente { get; set; }
    public DbSet<ProdutoEntity> Produto { get; set; }
    public DbSet<CursoEntity> Curso { get; set; }
}
```

*Nota:* Foi gerada a migration `add-user` via Entity Framework Core para refletir a tabela `tb_usuario` no banco de dados.

---

### Contratos e Repositório de Usuário

#### Interface `IUserRepository`:

Localizada em `Domain/Interfaces/IUserRepository.cs`:

```csharp
using AspNet.API.Domain.Entities;

namespace AspNet.API.Domain.Interfaces
{
    public interface IUserRepository
    {
        Task<UserEntity?> AdicionarAsync(UserEntity entity);
        Task<UserEntity?> AutenticarAsync(string email, string password);
    }
}
```

#### Implementando `UserRepository`:

Localizada em `Infrastructure/Data/Repositories/UserRepository.cs`:

```csharp
using AspNet.API.Domain.Entities;
using AspNet.API.Domain.Errors;
using AspNet.API.Domain.Interfaces;

namespace AspNet.API.Infrastructure.Data.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationContext _context;

        public UserRepository(ApplicationContext context)
        {
            _context = context;
        }

        public async Task<UserEntity?> AdicionarAsync(UserEntity entity)
        {
            try
            {
                await _context.Usuario.AddAsync(entity);
                await _context.SaveChangesAsync();

                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<UserEntity?> AutenticarAsync(string email, string password)
        {
            try
            {
                var usuario = _context
                    .Usuario
                    .FirstOrDefault(item => item.Email == email && item.Password == password);

                if (usuario is null) 
                    throw new NoContentException("Não foi encontrado o usuario para estas credenciais");

                return usuario;
            }
            catch (NoContentException ex)
            {
                throw new NoContentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
    }
}
```

---

### DTOs e Mappers de Usuário

#### DTO de Cadastro: `PostUserDto`

Localizado em `Application/Dtos/PostUserDto.cs`, com validações via DataAnnotations para garantir a confirmação de senha:

```csharp
using System.ComponentModel.DataAnnotations;

namespace AspNet.API.Application.Dtos
{
    public class PostUserDto
    {
        [Required]
        public string Nome { get; set; } = string.Empty;
        
        [Required]
        public string Email { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "A senha é obrigatória.")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "A confirmação de senha é obrigatória.")]
        [DataType(DataType.Password)]
        [Compare(nameof(Password), ErrorMessage = "As senhas não confeream...")]
        public string CofirmPassword { get; set; } = string.Empty;
        
        public string Role { get; set; } = string.Empty;
    }
}
```

#### DTO de Autenticação: `PostAuthDto`

Localizado em `Application/Dtos/PostAuthDto.cs`:

```csharp
namespace AspNet.API.Application.Dtos
{
    public class PostAuthDto
    {
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}
```

#### DTO de Retorno do Token: `GetAuthDto`

Localizado em `Application/Dtos/GetAuthDto.cs`:

```csharp
namespace AspNet.API.Application.Dtos
{
    public class GetAuthDto
    {
        public string Email { get; set; }
        public string Jwt { get; set; }
    }
}
```

#### Mapper de Usuário: `UserMapper`

Localizado em `Application/Mappers/UserMapper.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Domain.Entities;

namespace AspNet.API.Application.Mappers
{
    public static class UserMapper
    {
        public static UserEntity ToUserEntity(this PostUserDto obj)
        {
            return new UserEntity
            {
                Nome = obj.Nome,
                Email = obj.Email,
                Password = obj.Password,
                Role = obj.Role,
            };
        }
    }
}
```

---

### Casos de Uso: `IUserUseCase` e `UserUseCase`

#### Interface `IUserUseCase`:

Localizada em `Application/Interfaces/IUserUseCase.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Domain.Entities;

namespace AspNet.API.Application.Interfaces
{
    public interface IUserUseCase
    {
        Task<OperationResult<UserEntity?>> AdicionarUserAsync(PostUserDto entity);
        Task<OperationResult<GetAuthDto?>> AutenticarUserAsync(PostAuthDto model);
    }
}
```

#### Implementando o `UserUseCase` com Geração de JWT:

Localizado em `Application/UseCases/UserUseCase.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Application.Interfaces;
using AspNet.API.Application.Mappers;
using AspNet.API.Domain.Entities;
using AspNet.API.Domain.Errors;
using AspNet.API.Domain.Interfaces;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;

namespace AspNet.API.Application.UseCases
{
    public class UserUseCase : IUserUseCase
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _configuration;

        public UserUseCase(IUserRepository userRepository, IConfiguration configuration)
        {
            _userRepository = userRepository;
            _configuration = configuration;
        }

        public async Task<OperationResult<UserEntity?>> AdicionarUserAsync(PostUserDto entity)
        {
            try
            {
                var result = await _userRepository.AdicionarAsync(entity.ToUserEntity());

                return OperationResult<UserEntity?>.Success(result, (int)HttpStatusCode.OK);
            }
            catch (Exception)
            {
                return OperationResult<UserEntity?>.Failure("Ocorreu um erro ao adicionar o usuario", (int)HttpStatusCode.BadRequest);
            }
        }

        public async Task<OperationResult<GetAuthDto?>> AutenticarUserAsync(PostAuthDto model)
        {
            try
            {
                var result = await _userRepository.AutenticarAsync(model.Email, model.Senha);

                // Autenticação e Geração do JWT
                var tokenHandler = new JwtSecurityTokenHandler();

                var key = Encoding.ASCII.GetBytes(_configuration["Secretkey"]!.ToString());

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Expires = DateTime.UtcNow.AddHours(8),
                    SigningCredentials = new SigningCredentials(
                        new SymmetricSecurityKey(key), 
                        SecurityAlgorithms.HmacSha256Signature
                    ),
                    Subject = new ClaimsIdentity(new Claim[] {
                        new Claim(ClaimTypes.Name, result!.Email.ToString()),
                        new Claim(ClaimTypes.Role, result!.Role.ToString()),
                        new Claim("Teste", "ValorTeste"),
                    })
                };

                var token = tokenHandler.CreateToken(tokenDescriptor);

                var userAutenticado = new GetAuthDto
                {
                    Email = model.Email,
                    Jwt = tokenHandler.WriteToken(token),
                };

                return OperationResult<GetAuthDto?>.Success(userAutenticado, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                return OperationResult<GetAuthDto?>.Failure(ex.Message, (int)HttpStatusCode.NotFound);
            }
            catch (Exception)
            {
                return OperationResult<GetAuthDto?>.Failure("Ocorreu um erro ao autenticar o usuario", (int)HttpStatusCode.BadRequest);
            }
        }
    }
}
```

#### Entendendo a Geração do Token Passo a Passo:

1. **Validação das Credenciais:**
   ```csharp
   var result = await _userRepository.AutenticarAsync(model.Email, model.Senha);
   ```
   Valida se as credenciais informadas existem na base. Se não existir, lança `NoContentException`, retornando HTTP 404/401 sem prosseguir.

2. **Manipulador de Tokens e Chave Secreta:**
   ```csharp
   var tokenHandler = new JwtSecurityTokenHandler();
   var key = Encoding.ASCII.GetBytes(_configuration["Secretkey"]!.ToString());
   ```
   `JwtSecurityTokenHandler` é a classe que constrói e serializa o JWT. A chave é convertida em um array de bytes para a assinatura simétrica.

3. **Descritor do Token (`SecurityTokenDescriptor`):**
   ```csharp
   var tokenDescriptor = new SecurityTokenDescriptor
   {
       Expires = DateTime.UtcNow.AddHours(8),
       SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
       Subject = new ClaimsIdentity(new Claim[] {
           new Claim(ClaimTypes.Name, result!.Email.ToString()),
           new Claim(ClaimTypes.Role, result!.Role.ToString()),
           new Claim("Teste", "ValorTeste"),
       })
   };
   ```
   - **`Expires`**: define a validade do token (neste exemplo, 8 horas).
   - **`SigningCredentials`**: define a chave simétrica e o algoritmo criptográfico de assinatura (`HmacSha256Signature`).
   - **`Subject`**: coleção de **claims** (identidade do usuário):
     - `ClaimTypes.Name`: e-mail do usuário autenticado.
     - `ClaimTypes.Role`: papel ou perfil do usuário (`admin`, `user`), essencial para a autorização.
     - `"Teste"`: exemplo de claim personalizada.

4. **Criação e Serialização:**
   ```csharp
   var token = tokenHandler.CreateToken(tokenDescriptor);
   var jwtString = tokenHandler.WriteToken(token);
   ```
   O token é serializado em formato de string compacta (`eyJhbGciOiJIUzI1Ni...`) e devolvido no DTO `GetAuthDto`.

---

### Camada de Apresentação: Controllers

#### `UserController` (Cadastro de Usuários):

Localizada em `Presentation/Controllers/UserController.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace AspNet.API.Presentation.Controllers
{
    [Route("api/user")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserUseCase _userUseCase;

        public UserController(IUserUseCase userUseCase)
        {
            _userUseCase = userUseCase;
        }

        [HttpPost]
        public async Task<IActionResult> Post(PostUserDto model)
        {
            var resultado = await _userUseCase.AdicionarUserAsync(model);

            if (!resultado.IsSuccess) 
                return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }
    }
}
```

#### `AuthController` (Autenticação e Login):

Localizada em `Presentation/Controllers/AuthController.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace AspNet.API.Presentation.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserUseCase _userUseCase;

        public AuthController(IUserUseCase userUseCase)
        {
            _userUseCase = userUseCase;
        }

        [HttpPost]
        public async Task<IActionResult> Post(PostAuthDto model)
        {
            var resultado = await _userUseCase.AutenticarUserAsync(model);

            if (!resultado.IsSuccess) 
                return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }
    }
}
```

Ao fazer `POST /api/auth` com credenciais válidas, a API responde com status `200 OK`:

```json
{
  "email": "admin@fiap.com.br",
  "jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFkbWluQGZpYXAuY29tLmJyIiwicm9sZSI6ImFkbWluIiwiVGVzdGUiOiJWYWxvclRlc3RlIiwibmJmIjoxNjk2ODg1MDAwLCJleHAiOjE2OTY5MTM4MDAsImlhdCI6MTY5Njg4NTAwMH0.sOmE_sIgnAtUrE_hAsH..."
}
```

---

### Configurando o ASP.NET Core no `Program.cs`

Para que o ASP.NET Core valide os tokens JWT recebidos no cabeçalho `Authorization: Bearer <token>`, configuramos o serviço de autenticação e os middlewares correspondentes.

#### 1. Registrando o Serviço de Autenticação JWT:

```csharp
// Configuração da chave de autenticação
var key = Encoding.ASCII.GetBytes(builder.Configuration["Secretkey"]!.ToString());

builder.Services.AddAuthentication(options => {
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(x => {
    x.RequireHttpsMetadata = false; // Em produção deve ser true
    x.SaveToken = true;
    x.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ValidateIssuer = false,
        ValidateAudience = false,
    };
});
```

- **`ValidateIssuerSigningKey = true`**: obriga a validação da assinatura simétrica utilizando a `Secretkey`.
- **`IssuerSigningKey = new SymmetricSecurityKey(key)`**: define a chave válida para verificar a assinatura.
- **`ValidateIssuer = false` / `ValidateAudience = false`**: simplifica a validação para o ambiente local/desenvolvimento. Em cenários OAuth2 complexos, apontam para a URL do emissor e cliente.

#### 2. Adicionando os Middlewares no Pipeline HTTP:

A ordem de declaração dos middlewares é mandatória: a autenticação deve preceder a autorização:

```csharp
app.UseAuthentication(); // 1º: Identifica quem é o usuário
app.UseAuthorization();  // 2º: Avalia as permissões do usuário autenticado
```

---

### Configurando o Swagger para Suportar JWT Bearer

Para testar requisições protegidas diretamente pela interface do Swagger sem depender de ferramentas externas, configuramos o esquema de segurança OpenAPI no `builder.Services.AddSwaggerGen`:

```csharp
builder.Services.AddSwaggerGen(c => { 
    c.EnableAnnotations();
    c.ExampleFilters();

    var securitySchema = new OpenApiSecurityScheme
    {
        Description = "Using the Authorization header with the Bearer scheme.",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        Reference = new OpenApiReference
        {
            Type = ReferenceType.SecurityScheme,
            Id = "Bearer"
        }
    };
    c.AddSecurityDefinition("Bearer", securitySchema);

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        { securitySchema, new[] { "Bearer" } }
    });
});
```

Com isso, o Swagger exibe o botão **Authorize** (cadeado). O desenvolvedor insere o token JWT e todas as requisições subsequentes incluirão automaticamente o cabeçalho:

```http
Authorization: Bearer <token_aqui>
```

---

### Injeção de Dependências no `Bootstrap.cs`

No arquivo `Infrastructure/IoC/Bootstrap.cs`, registramos as dependências do novo módulo de autenticação:

```csharp
public static void AddIoC(IServiceCollection services, IConfiguration configuration)
{
    services.AddDbContext<ApplicationContext>(options => {
        options.UseOracle(configuration.GetConnectionString("Oracle"));
    });

    // Módulo de Usuário e Autenticação
    services.AddTransient<IUserRepository, UserRepository>();
    services.AddTransient<IUserUseCase, UserUseCase>();

    // Módulo de Cliente
    services.AddTransient<IClienteRepository, ClienteRepository>();
    services.AddTransient<IClienteUseCase, ClienteUseCase>();

    services.AddTransient<IClienteService, ClienteService>();
}
```

---

### Protegendo Endpoints com Atributos de Autorização

No ASP.NET Core, a proteção de endpoints é aplicada por meio dos atributos `[Authorize]` e `[AllowAnonymous]`.

#### 1. `[Authorize]` em Nível de Controller

Ao decorar a classe da controller com `[Authorize]`, todos os seus métodos passam a exigir um token JWT válido:

```csharp
[Authorize] // Protege todos os endpoints da Controller
[Route("api/cliente")]
[ApiController]
public class ClienteController : ControllerBase
{
    private readonly IClienteUseCase _clienteUseCase;

    public ClienteController(IClienteUseCase clienteUseCase)
    {
        _clienteUseCase = clienteUseCase;
    }

    [HttpGet]
    public IActionResult Get()
    {
        // Somente usuários autenticados conseguem acessar
        ...
    }
}
```

#### 2. Protegendo Apenas um Método Específico

```csharp
[ApiController]
[Route("api/produto")]
public class ProdutoController : ControllerBase
{
    [HttpGet]
    public IActionResult GetProdutos() => Ok("Acesso público!");

    [Authorize] // Protege somente esta ação
    [HttpPost]
    public IActionResult CriarProduto() => Ok("Acesso restrito!");
}
```

#### 3. `[AllowAnonymous]` – Permitindo Acesso Público

Quando uma controller está protegida com `[Authorize]`, mas algum endpoint precisa permanecer acessível a qualquer visitante (como a tela de login ou status público), utilizamos `[AllowAnonymous]`:

```csharp
[Authorize] // Exige autenticação por padrão
[ApiController]
[Route("api/conta")]
public class ContaController : ControllerBase
{
    [AllowAnonymous] // Exceção: qualquer pessoa pode fazer login
    [HttpPost("login")]
    public IActionResult Login() => Ok("Login público!");

    [HttpGet("perfil")]
    public IActionResult Perfil() => Ok("Dados protegidos do perfil!");
}
```

---

### Códigos de Retorno HTTP Esperados em Segurança

| Código HTTP | Significado | Quando ocorre |
| :--- | :--- | :--- |
| **`401 Unauthorized`** | Falha de Autenticação | A requisição não enviou o cabeçalho `Authorization`, o token é inválido ou expirou. |
| **`403 Forbidden`** | Falha de Autorização | O usuário está autenticado com sucesso, mas seu perfil/role não tem permissão para acessar o recurso. |

---

### Autorização Baseada em Papéis (Roles)

Em muitos cenários, estar autenticado não é suficiente: o sistema precisa restringir certas ações a papéis específicos (`Admin`, `Gerente`, `Cliente`).

No momento da geração do token no `UserUseCase`, incluímos a claim de role:

```csharp
new Claim(ClaimTypes.Role, result!.Role.ToString())
```

Para proteger endpoints exigindo papéis específicos, utilizamos `[Authorize(Roles = "...")]`:

```csharp
[ApiController]
[Route("api/produtos")]
public class ProdutoController : ControllerBase
{
    // Qualquer usuário autenticado
    [Authorize]
    [HttpGet]
    public IActionResult Listar() => Ok("Lista de produtos para qualquer usuário autenticado.");

    // Apenas usuários com a role "admin"
    [Authorize(Roles = "admin")]
    [HttpPost]
    public IActionResult Criar() => Ok("Apenas administradores podem cadastrar produtos.");

    // Usuários com role "admin" OU "gerente"
    [Authorize(Roles = "admin,gerente")]
    [HttpPut("{id}")]
    public IActionResult Atualizar(int id) => Ok("Administradores ou gerentes podem atualizar.");
}
```

> **Nota:** É possível especificar múltiplos papéis separados por vírgula. Se o usuário possuir **qualquer um** dos papéis informados, o acesso será autorizado. Caso não possua, o ASP.NET Core responderá automaticamente com **403 Forbidden**.

---

## Resumo dos Padrões e Componentes da Aula 08

| Componente | Camada | Descrição e Finalidade |
| :--- | :--- | :--- |
| **`LinkDto`** | `Application (DTOs)` | Define o contrato de links de hipermídia (`Href`, `Rel`, `Method`). |
| **`GetClienteDto`** | `Application (DTOs)` | DTO de saída do cliente contendo dados essenciais e coleção `Links`. |
| **`PageResponseDto<T>`** | `Application (DTOs)` | Contrato de resposta paginada enriquecido com links globais e itens navegáveis. |
| **`ClienteMapper`** | `Application (Mappers)` | Método de extensão `ToClienteDto` para acoplar os links de hipermídia à resposta. |
| **`UserEntity`** | `Domain (Entities)` | Entidade de usuário mapeada para `tb_usuario` com dados de login e role. |
| **`IUserRepository` / `UserRepository`** | `Domain / Infrastructure` | Operações assíncronas de inserção e autenticação no banco via EF Core. |
| **`PostUserDto` / `PostAuthDto`** | `Application (DTOs)` | DTOs de entrada para cadastro (com validação de confirmação de senha) e login. |
| **`GetAuthDto`** | `Application (DTOs)` | DTO de saída da autenticação contendo e-mail e a string compacta do token JWT. |
| **`UserUseCase`** | `Application (UseCases)` | Orquestra cadastro e gera o JWT assinado com claims de nome, role e expiração. |
| **`AuthController` / `UserController`** | `Presentation (Controllers)` | Endpoints HTTP para autenticação (`/api/auth`) e registro (`/api/user`). |
| **`AddJwtBearer` & Middlewares** | `Presentation (Program.cs)` | Registra a validação do token JWT e ativa os middlewares `UseAuthentication()` e `UseAuthorization()`. |
| **`OpenApiSecurityScheme`** | `Presentation (Program.cs)` | Habilita autenticação via Bearer token na documentação interativa do Swagger. |
| **`[Authorize]` & Roles** | `Presentation (Controllers)` | Garante proteção dos endpoints, bloqueando acessos anônimos e filtrando por perfis. |

