
**Tópicos Abordados**

- Modularização
- Usando IA com **(Microsoft Extensions AI)**
  
Nesta aula, avançamos de forma significativa na maturidade arquitetural e funcional da nossa aplicação em **ASP.NET Core 8**. Abordamos dois temas centrais para o desenvolvimento corporativo moderno: a **Modularização de Software** em múltiplos projetos/DLLs independentes (adotando os princípios da *Clean Architecture*) e a integração com **Inteligência Artificial Generativa** através da nova biblioteca oficial **Microsoft Extensions AI** (`Microsoft.Extensions.AI.OpenAI`), utilizando a abstração `IChatClient` para geração de relatórios de *insights* de negócios baseados em dados reais.

## 1. Modularização de Software

A **modularização do software**, dividindo-o em projetos independentes (DLLs / *Class Libraries*), oferece diversos benefícios essenciais para a arquitetura de sistemas corporativos:

- **Separação de responsabilidades** → cada camada tem seu papel bem definido: *Domain* concentra as entidades e regras centrais de negócio, *Application* os casos de uso e orquestrações, *Infrastructure* os detalhes técnicos e persistência, e *Presentation* a interação com os clientes (HTTP, gRPC, etc.).
- **Reuso e testabilidade** → *Domain* e *Application* podem ser testados isoladamente em testes de unidade puros, sem depender de conexões com banco de dados ou APIs externas.
- **Evolução independente** → é possível trocar ou atualizar a infraestrutura (ex.: EF Core ↔ MongoDB, Oracle ↔ PostgreSQL, ou novos serviços de terceiros) sem impactar nenhuma linha da lógica de negócio.
- **Reaproveitamento em múltiplas apresentações** → quando a aplicação possui diferentes projetos de apresentação (ex.: API REST principal, microsserviço de pedidos, gRPC, Worker de mensageria ou WebApp), todos podem reutilizar as mesmas camadas de *Domain* e *Application* sem duplicar código.
- **Baixo acoplamento e alta coesão** → mudanças em um módulo não quebram os demais, mantendo o sistema modular, estável e bem organizado.
- **Flexibilidade de deploy e compilação** → cada projeto compila seu próprio artefato (`.dll`), permitindo versionamento, modularização de pacotes internos e compilação incremental mais rápida.

Em resumo, **modularizar em DLLs aumenta a organização, a manutenibilidade e a flexibilidade do sistema, permitindo evolução contínua sem a necessidade de reescrever a aplicação**.

---

### Como é separado no Java e no .NET

Tanto no **Java** quanto no **.NET** os conceitos arquiteturais são bastante similares, porém utilizam nomenclaturas e tipos de artefatos distintos:

- **Java** → utiliza `package` para a organização lógica do código-fonte e compila em arquivos `JAR` (*Java Archive*) ou `WAR` (*Web Application Archive*).
- **.NET** → utiliza `namespace` para a organização lógica do código e compila em `Assemblies` (arquivos `.dll` para bibliotecas de classes ou `.exe` para executáveis).

#### Comparativo de Estrutura: Java vs .NET

##### Estrutura de um projeto em Java:

```css
/loja
 ├─ loja-domain/               (JAR)   
 │   └─ src/main/java/com/loja/domain/...
 │        ├─ entities/         (com.loja.domain.entities)
 │        └─ ports/            (com.loja.domain.ports)
 │
 ├─ loja-application/          (JAR)   
 │   └─ src/main/java/com/loja/application/...
 │        ├─ usecases/         (com.loja.application.usecases)
 │        └─ dto/              (com.loja.application.dto)
 │
 ├─ loja-infrastructure/       (JAR)   
 │   └─ src/main/java/com/loja/infrastructure/...
 │        ├─ jpa/              (com.loja.infrastructure.jpa)
 │        └─ repositories/     (com.loja.infrastructure.repositories)
 │
 └─ loja-api/                  (JAR/WAR) 
     └─ src/main/java/com/loja/api/...
          ├─ controllers/      (com.loja.api.controllers)
          └─ config/           (com.loja.api.config)
```

##### Estrutura de um projeto em .NET:

```css
/Loja.sln
 ├── Loja.Api/            (projeto ASP.NET Web API - gera Loja.Api.dll / executável)
 ├── Loja.Application/    (biblioteca de classes / casos de uso - gera Loja.Application.dll)
 ├── Loja.Domain/         (biblioteca de classes / entidades e interfaces - gera Loja.Domain.dll)
 ├── Loja.Infrastructure/ (biblioteca de classes / persistência e serviços - gera Loja.Infrastructure.dll)
 └── Loja.IoC/            (biblioteca de classes / injeção de dependência - gera Loja.IoC.dll)
```

---

### Estrutura do Projeto Separado em Módulos

Na nossa solução, organizamos os projetos por pastas de solução lógicas, garantindo que cada componente pertença à sua respectiva camada:

```css
Solution 'AspNet.sln' (ou Revisao.sln)
├─ 0 - Presentation
│  ├─ AspNet.API           (API Principal - Clientes, Autenticação, Usuários, etc.)
│  └─ Pedido.API           (API Especializada de Pedidos - Exemplo de Múltipla Apresentação)
│
├─ 1 - Application
│  └─ AspNet.Application   (DTOs, Mappers, Casos de Uso e Interfaces de Aplicação)
│
├─ 2 - Domain
│  └─ AspNet.Domain        (Entidades, Objetos de Domínio, Exceções e Interfaces de Repositório/Serviço)
│
├─ 3 - Infrastructure
│  ├─ AspNet.Infrastructure (Contextos EF Oracle/MongoDB, Repositórios e Serviços Externos)
│  └─ AspNet.IoC           (Bootstrap da Injeção de Dependências - Inversion of Control)
│
└─ 4 - Tests
   └─ AspNet.Tests         (Testes Unitários e Testes de Integração com xUnit e Moq)
```

#### Responsabilidade de Cada Módulo:

1. **`AspNet.Domain` (Domínio Central)**:
   - É o coração da aplicação. Não depende de nenhuma outra camada do projeto.
   - Contém as entidades de negócio (`ClienteEntity`, `CursoEntity`, `EstadoEntity`, `ProdutoEntity`, `UserEntity`, `PedidoEntity`, `PedidoItemEntity`), modelos de resposta (`OperationResult<T>`, `EnderecoModel`), exceções de domínio (`NoContentException`) e os contratos/interfaces (`IClienteRepository`, `IPedidoRepository`, `IUserRepository`, `IClienteService`).
2. **`AspNet.Application` (Casos de Uso / Regras de Aplicação)**:
   - Depende de `AspNet.Domain` e `AspNet.Infrastructure`.
   - Contém os DTOs (`PostClienteDto`, `GetClienteDto`, `GetInsightsDto`, etc.), os Mappers e as implementações dos Casos de Uso (`ClienteUseCase`, `PedidoUseCase`, `UserUseCase`).
   - É onde orquestramos chamadas de repositórios, serviços externos e provedores de IA.
3. **`AspNet.Infrastructure` (Detalhes Técnicos e Persistência)**:
   - Depende de `AspNet.Domain`.
   - Implementa os acessos a dados reais: `ApplicationContext` (Oracle via Entity Framework Core), `MongoApplicationContext` (MongoDB), migrações de banco, implementações concretas dos repositórios (`ClienteRepository`, `PedidoRepository`, `UserRepository`) e clientes HTTP externos (`ClienteService` via RestSharp consumindo o ViaCEP).
4. **`AspNet.IoC` (Inversão de Controle)**:
   - Depende de `AspNet.Application` e `AspNet.Infrastructure`.
   - Isola a amarração de injeção de dependências em um único local (`Bootstrap.cs`), evitando que os projetos de apresentação precisem referenciar diretamente detalhes de infraestrutura ou registrar manualmente cada repositório.
5. **`AspNet.API` e `Pedido.API` (Apresentação / Presentation)**:
   - Dependem de `AspNet.Application`, `AspNet.Domain` e `AspNet.IoC`.
   - Recebem as requisições HTTP, executam validações de rotas/autorizações (`[Authorize]`), chamam os casos de uso e retornam os códigos de status HTTP correspondentes.

---

## 2. Bibliotecas e Dependências por Camada

Ao dividir a aplicação em projetos independentes, cada projeto passa a declarar apenas os pacotes NuGet estritamente necessários para a sua função, reduzindo o acoplamento e o tamanho dos artefatos.

### Camada `AspNet.Application`

A camada de aplicação precisa lidar com a validação de tokens JWT (caso necessite de tipos de segurança) e com as abstrações de Inteligência Artificial:

```bash
# Autenticação e claims JWT
dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer --version 8.0.31

# Quando adicionar o módulo de IA, adicionar esta biblioteca:
dotnet add package Microsoft.Extensions.AI.OpenAI --version 10.11.0
```

### Camada `AspNet.Domain`

A camada de domínio deve ser a mais pura possível, utilizando apenas os tipos de dados fundamentais para definição das entidades:

```bash
# Suporte aos tipos e anotações do EF Core
dotnet add package Microsoft.EntityFrameworkCore --version 8.0.26

# Suporte ao tipo ObjectId e anotações BSON para entidades NoSQL
dotnet add package MongoDB.Bson --version 3.12.0
```

### Camada `AspNet.Infrastructure`

A camada de infraestrutura concentra os provedores de acesso a banco de dados e comunicação HTTP:

```bash
# Entity Framework Core e Ferramentas de Migração
dotnet add package Microsoft.EntityFrameworkCore --version 8.0.26
dotnet add package Microsoft.EntityFrameworkCore.Tools --version 8.0.26

# Provedor do Banco Relacional Oracle
dotnet add package Oracle.EntityFrameworkCore --version 8.23.26200

# Provedores e tipos para MongoDB
dotnet add package MongoDB.Bson --version 3.12.0
dotnet add package MongoDB.EntityFrameworkCore --version 8.3.3

# Cliente HTTP para consumo de APIs externas (ex: ViaCEP)
dotnet add package RestSharp --version 114.0.0
```

### Camada de Apresentação e Bibliotecas de IA (`AspNet.API`)

O projeto de apresentação que inicializa o runtime e configura os serviços de IA necessita das bibliotecas concretas do cliente:

```bash
# Abstração unificada da Microsoft para IA
dotnet add package Microsoft.Extensions.AI.OpenAI --version 10.11.0

# SDK oficial da OpenAI para .NET
dotnet add package OpenAI --version 2.14.0
```

---

### Vinculando as Dependências entre os Projetos via CLI

Para configurar as referências de projeto entre os módulos da Solution, executamos os comandos `dotnet add reference`:

```bash
# 1. AspNet.Infrastructure referencia AspNet.Domain
dotnet add AspNet.Infrastructure/AspNet.Infrastructure.csproj reference AspNet.Domain/AspNet.Domain.csproj

# 2. AspNet.Application referencia AspNet.Domain e AspNet.Infrastructure
dotnet add AspNet.Application/AspNet.Application.csproj reference AspNet.Domain/AspNet.Domain.csproj
dotnet add AspNet.Application/AspNet.Application.csproj reference AspNet.Infrastructure/AspNet.Infrastructure.csproj

# 3. AspNet.IoC referencia AspNet.Application e AspNet.Infrastructure
dotnet add AspNet.IoC/AspNet.IoC.csproj reference AspNet.Application/AspNet.Application.csproj
dotnet add AspNet.IoC/AspNet.IoC.csproj reference AspNet.Infrastructure/AspNet.Infrastructure.csproj

# 4. AspNet.API referencia AspNet.Application, AspNet.Domain e AspNet.IoC
dotnet add AspNet.API/AspNet.API.csproj reference AspNet.Application/AspNet.Application.csproj
dotnet add AspNet.API/AspNet.API.csproj reference AspNet.Domain/AspNet.Domain.csproj
dotnet add AspNet.API/AspNet.API.csproj reference AspNet.IoC/AspNet.IoC.csproj

# 5. Pedido.API referencia AspNet.Application, AspNet.Domain e AspNet.IoC
dotnet add Pedido.API/Pedido.API.csproj reference AspNet.Application/AspNet.Application.csproj
dotnet add Pedido.API/Pedido.API.csproj reference AspNet.Domain/AspNet.Domain.csproj
dotnet add Pedido.API/Pedido.API.csproj reference AspNet.IoC/AspNet.IoC.csproj
```

---

## 3. Inversão de Controle e Desacoplamento com `AspNet.IoC`

Para centralizar e desacoplar o registro dos serviços da aplicação, criamos a classe estática `Bootstrap` dentro do projeto `AspNet.IoC`. Dessa forma, qualquer aplicação de apresentação precisa apenas invocar um único método para registrar todos os contextos de banco de dados, repositórios e casos de uso.

### Arquivo: `AspNet.IoC/Bootstrap.cs`

```csharp
using AspNet.API.Application.Interfaces;
using AspNet.API.Application.UseCases;
using AspNet.API.Domain.Interfaces;
using AspNet.API.Infrastructure.Data;
using AspNet.API.Infrastructure.Data.Repositories;
using AspNet.API.Infrastructure.Service;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace AspNet.API.Infrastructure.IoC
{
    public static class Bootstrap
    {
        public static void AddIoC(IServiceCollection services, IConfiguration configuration)
        {
            // Configuração do contexto relacional Oracle
            services.AddDbContext<ApplicationContext>(options =>
            {
                options.UseOracle(configuration.GetConnectionString("Oracle"));
            });

            // Configuração do contexto NoSQL MongoDB
            services.AddDbContext<MongoApplicationContext>(options =>
            {
                options.UseMongoDB(configuration.GetConnectionString("Mongodb") ?? "", "Aula01");
            });

            // Registro do ciclo de vida de Repositórios e Casos de Uso (Transient)
            services.AddTransient<IPedidoRepository, PedidoRepository>();
            services.AddTransient<IPedidoUseCase, PedidoUseCase>();

            services.AddTransient<IUserRepository, UserRepository>();
            services.AddTransient<IUserUseCase, UserUseCase>();

            services.AddTransient<IClienteRepository, ClienteRepository>();
            services.AddTransient<IClienteUseCase, ClienteUseCase>();

            // Registro de serviço externo (ViaCEP)
            services.AddTransient<IClienteService, ClienteService>();
        }
    }
}
```

No arquivo `Program.cs` das camadas de apresentação, o registro de IoC resume-se a uma única linha:

```csharp
Bootstrap.AddIoC(builder.Services, builder.Configuration);
```

---

## 4. Reaproveitamento em Múltiplas Apresentações: `Pedido.API`

Um dos maiores benefícios demonstrados na aula foi o reaproveitamento das camadas de negócio e persistência através da criação de um novo projeto de apresentação: **`Pedido.API`**.

Imagine um cenário corporativo onde a gestão de pedidos precisa ser escalada de forma independente da API central de clientes e cadastros. Graças à modularização, não precisamos reescrever nenhuma regra de negócio ou mapeamento do MongoDB!

### Arquivo `Pedido.API/Program.cs`

O arquivo de inicialização de `Pedido.API` é extremamente enxuto, limitando-se a registrar a IoC modularizada, o Swagger e os Controllers:

```csharp
using AspNet.API.Infrastructure.IoC;

var builder = WebApplication.CreateBuilder(args);

// Reutilizando toda a infraestrutura e regras de negócio com uma única linha
Bootstrap.AddIoC(builder.Services, builder.Configuration);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.MapControllers();

app.Run();
```

### Arquivo `Pedido.API/Controllers/PedidoController.cs`

A Controller dentro de `Pedido.API` consome diretamente o contrato `IPedidoUseCase` da camada `AspNet.Application`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Application.Interfaces;
using AspNet.API.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Pedido.API.Controllers
{
    [Route("api/pedido")]
    [ApiController]
    public class PedidoController : ControllerBase
    {
        private readonly IPedidoUseCase _pedidoUseCase;

        public PedidoController(IPedidoUseCase pedidoUseCase)
        {
            _pedidoUseCase = pedidoUseCase;
        }

        [HttpGet]
        public IActionResult Get(int Deslocamento, int RegistroRetornado)
        {
            var resultado = _pedidoUseCase.ObterTodosPedidos(Deslocamento, RegistroRetornado);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            var resultado = _pedidoUseCase.ObterUmPedido(id);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPost]
        public IActionResult Post(PostPedidoDto model)
        {
            var resultado = _pedidoUseCase.AdicionarPedido(model);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }

        [HttpPost("{pedidoId}/item")]
        public IActionResult PostItem(string pedidoId, PedidoItemEntity model)
        {
            var resultado = _pedidoUseCase.AdicionarItemNoPedido(pedidoId, model);

            if (!resultado.IsSuccess) return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }
    }
}
```

---

## 5. Usando IA com Microsoft Extensions AI

Com a evolução da Inteligência Artificial Generativa, desenvolvedores .NET frequentemente enfrentavam o desafio de acoplamento com SDKs proprietários específicos de cada fornecedor (OpenAI, Azure, Anthropic, Ollama). 

Para resolver essa fragmentação, a Microsoft introduziu a biblioteca **`Microsoft.Extensions.AI`**.

### O que é o Microsoft Extensions AI?

O **Microsoft Extensions AI** é um conjunto de bibliotecas e abstrações unificadas do ecossistema .NET que padroniza a interação com modelos de linguagem (LLMs), visão computacional e serviços de IA.

A interface central desta arquitetura é a **`IChatClient`**:
- Fornece um contrato comum para envio de prompts e recebimento de respostas (`GetResponseAsync`).
- Desacopla o código de negócio da implementação física do modelo.
- Permite alternar entre **OpenAI**, **Azure OpenAI**, **OpenRouter**, **Ollama** ou modelos locais sem alterar nenhuma linha da camada de aplicação (`Application`).
- Suporta recursos avançados como streaming, middleware de logging, cache e chamadas de função (*function calling*).

---

## 6. Configuração de Variáveis no `appsettings.Development.json`

Para viabilizar a comunicação com os bancos de dados, serviços de telemetria, autenticação JWT e o provedor de IA, configuramos as chaves necessárias no arquivo `appsettings.Development.json`.

> **Importante:** Por questões de segurança e boas práticas de desenvolvimento corporativo, nunca devemos expor chaves de API, senhas ou *connection strings* reais em documentações públicas ou repositórios de controle de versão. Abaixo apresentamos as variáveis utilizadas e a finalidade de cada uma:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "ConnectionStrings": {
    "Oracle": "<string_de_conexao_banco_oracle>",
    "Mongodb": "<string_de_conexao_banco_mongodb>"
  },
  "ApplicationInsights": {
    "ConnectionString": "<string_de_conexao_azure_application_insights>"
  },
  "Secretkey": "<chave_secreta_assinatura_jwt>",
  "OpenRouterKey": "<chave_de_api_openrouter_ou_openai>"
}
```

### Finalidade de Cada Variável:

- **`ConnectionStrings:Oracle`**: String de conexão utilizada pelo `ApplicationContext` para persistência dos dados relacionais no banco de dados Oracle (clientes, produtos, cursos, estados, usuários).
- **`ConnectionStrings:Mongodb`**: String de conexão utilizada pelo `MongoApplicationContext` para persistência de documentos de pedidos e subdocumentos no MongoDB.
- **`ApplicationInsights:ConnectionString`**: Chave de instrumentação e telemetria para monitoramento e observabilidade da API na nuvem Microsoft Azure.
- **`Secretkey`**: Chave simétrica utilizada pelo algoritmo `HmacSha256` para assinar e validar a autenticidade dos tokens JWT gerados para os usuários.
- **`OpenRouterKey`**: Chave de API secreta fornecida pela plataforma OpenRouter (ou OpenAI) utilizada para autenticar as requisições enviadas ao modelo de Inteligência Artificial.

---

## 7. Registro e Configuração do `IChatClient` no `Program.cs`

No arquivo `Program.cs` da API principal (`AspNet.API`), realizamos a configuração do cliente da OpenAI e o registramos como a abstração `IChatClient` no container de injeção de dependência.

Utilizamos a plataforma **OpenRouter** como *gateway*, definindo o endpoint personalizado `https://openrouter.ai/api/v1` e selecionando o modelo `openai/gpt-4o-mini`.

```csharp
using Microsoft.Extensions.AI;
using OpenAI;
using System.ClientModel;

// 1. Instanciação do cliente oficial da OpenAI apontando para o endpoint do OpenRouter
var openAiClient = new OpenAIClient(
    new ApiKeyCredential(builder.Configuration["OpenRouterKey"]!.ToString()),
    new OpenAIClientOptions
    {
        Endpoint = new Uri("https://openrouter.ai/api/v1")
    });

// 2. Registro da abstração IChatClient como Singleton no ASP.NET Core
builder.Services.AddSingleton<IChatClient>(openAiClient
    .GetChatClient("openai/gpt-4o-mini")
    .AsIChatClient());
```

### Por que usar `.AsIChatClient()`?
O método de extensão `.AsIChatClient()` converte a instância do cliente proprietário da OpenAI para a abstração padrão do .NET (`IChatClient`). Isso garante que a nossa camada de aplicação (`AspNet.Application`) dependa exclusivamente de `IChatClient`, sem nenhum acoplamento com classes concretas de um provedor específico.

---

## 8. Modelagem de Dados e Contratos para IA

Para transportar o resultado da análise gerada pela Inteligência Artificial de volta para a camada de apresentação, criamos um DTO dedicado e atualizamos o contrato do caso de uso de clientes.

### DTO de Resposta: `GetInsightsDto`

Localizado em `AspNet.Application/Dtos/GetInsightsDto.cs`:

```csharp
using AspNet.API.Domain.Entities;

namespace AspNet.Application.Dtos
{
    public class GetInsightsDto
    {
        // Coleção contendo os dados brutos dos clientes consultados na base
        public IEnumerable<ClienteEntity> Dados { get; set; } = new List<ClienteEntity>();

        // Texto completo gerado pela IA com a análise de negócios em formato Markdown
        public string InsightsMarkdown { get; set; } = string.Empty;
    }
}
```

### Atualização da Interface: `IClienteUseCase`

Adicionamos o método assíncrono `ObterInsightsAsync` na interface `IClienteUseCase` localizada em `AspNet.Application/Interfaces/IClienteUseCase.cs`:

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Domain.Entities;
using AspNet.Application.Dtos;

namespace AspNet.API.Application.Interfaces
{
    public interface IClienteUseCase
    {
        OperationResult<PageResponseDto<GetClienteDto>> ObterTodosClientes(int Deslocamento, int RegistroRetornado);
        OperationResult<IEnumerable<ClienteEntity>> ObterTodosClientesMaioresDeIdadeClientes(int idade);
        OperationResult<GetClienteDto?> ObterUmCliente(int Id);
        OperationResult<ClienteEntity?> AdicionarCliente(PostClienteDto entity);
        OperationResult<ClienteEntity?> EditarCliente(int Id, PostClienteDto entity);
        OperationResult<ClienteEntity?> DeletarCliente(int Id);

        OperationResult<ProdutoEntity?> AdicionarProdutoNoCliente(PostProdutoDto entity, int clienteId);
        OperationResult<ProdutoEntity?> EditarProdutoNoCliente(PostProdutoDto entity, int produtoId, int clienteId);
        OperationResult<CursoEntity?> AdicionarCursoNoCliente(PostCursoDto entity, int clienteId);
        OperationResult<CursoEntity?> EditarCursoNoCliente(PostCursoDto entity, int cursoId);

        Task<OperationResult<EnderecoModel?>> ObterEnderecoPorCepAsync(string cep);

        // Novo contrato para geração de insights via Inteligência Artificial
        Task<OperationResult<GetInsightsDto>> ObterInsightsAsync();
    }
}
```

---

## 9. Implementação do Caso de Uso de Insights (`ClienteUseCase`)

A implementação do método `ObterInsightsAsync` na classe `ClienteUseCase` integra todas as camadas:
1. Recupera os clientes da base de dados através do repositório Oracle.
2. Serializa a lista de entidades para o formato JSON (`JsonSerializer.Serialize`).
3. Constrói um prompt detalhado e com instruções rígidas para o modelo.
4. Invoca o modelo de linguagem através de `_chatClient.GetResponseAsync(...)`.
5. Retorna o resultado padronizado com `OperationResult<GetInsightsDto>`.

### Arquivo: `AspNet.Application/UseCases/ClienteUseCase.cs`

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Application.Interfaces;
using AspNet.API.Domain.Entities;
using AspNet.API.Domain.Errors;
using AspNet.API.Domain.Interfaces;
using AspNet.Application.Dtos;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text.Json;

namespace AspNet.API.Application.UseCases
{
    public class ClienteUseCase : IClienteUseCase
    {
        private readonly IChatClient _chatClient;
        private readonly ILogger<ClienteUseCase> _logger;
        private readonly IClienteRepository _clienteRepository;
        private readonly IClienteService _clienteService;

        public ClienteUseCase(
            IClienteRepository clienteRepository, 
            ILogger<ClienteUseCase> logger, 
            IClienteService clienteService, 
            IChatClient chatClient)
        {
            _clienteService = clienteService;
            _clienteRepository = clienteRepository;
            _logger = logger;
            _chatClient = chatClient;
        }

        // ... outros métodos do caso de uso ...

        public async Task<OperationResult<GetInsightsDto>> ObterInsightsAsync()
        {
            try
            {
                // 1. Busca os dados dos clientes na base através do repositório
                var result = _clienteRepository.ObterTodos(0, 0);

                // 2. Serializa os dados em JSON para fornecer como contexto ao modelo de IA
                var dados = JsonSerializer.Serialize(result.data);

                // 3. Montagem do Prompt com Persona, Estrutura e Regras de Negócio
                var prompt = $"""
                    Você é um analista de negócios especializado em análise de
                    clientes, comportamento de consumo e oportunidades comerciais.

                    Analise os dados dos clientes abaixo e gere um relatório
                    de insights em Markdown.

                    Estruture o relatório com as seguintes seções:

                    ## 1. Resumo geral
                    - Quantidade total de clientes.
                    - Idade média dos clientes.
                    - Estados representados na base.

                    ## 2. Análise de compras
                    - Valor total dos produtos de cada cliente.
                    - Cliente com maior valor total em produtos.
                    - Produto de maior preço individual.
                    - Valor médio de produtos por cliente.

                    ## 3. Análise de cursos
                    - Quantidade total de cursos associados aos clientes.
                    - Cliente com maior quantidade de cursos.
                    - Cursos que podem indicar interesses em comum.

                    ## 4. Perfil dos clientes
                    - Identifique padrões de idade, localização e consumo.
                    - Compare os perfis dos clientes com base nos dados disponíveis.

                    ## 5. Oportunidades comerciais
                    - Sugira três ações comerciais baseadas nos dados.
                    - Identifique oportunidades de venda cruzada entre produtos e cursos.
                    - Explique quais clientes podem ser alvos de cada oportunidade.

                    ## 6. Conclusão
                    - Apresente os principais insights da análise.
                    - Destaque oportunidades que merecem atenção.

                    Regras:
                    - Utilize somente informações presentes nos dados.
                    - Não invente valores, clientes, produtos ou cursos.
                    - Calcule os totais usando quantidade e preço dos produtos.
                    - Considere que cada preço representa o valor de uma unidade.
                    - Diferencie o maior preço individual do maior total por cliente.
                    - Se uma informação não puder ser calculada, informe isso.
                    - Escreva em português do Brasil.
                    - Utilize títulos, listas, tabelas e negrito em Markdown.
                    - Seja objetivo e apresente recomendações práticas.

                    Dados dos clientes:
                    {dados}
                    """;

                // 4. Execução da chamada assíncrona ao modelo de IA
                var response = await _chatClient.GetResponseAsync(
                    prompt,
                    cancellationToken: CancellationToken.None);

                // 5. Montagem do DTO com os dados brutos e o relatório em Markdown gerado pela IA
                var insight = new GetInsightsDto
                {
                    Dados = result.data,
                    InsightsMarkdown = response.Text
                };

                return OperationResult<GetInsightsDto>.Success(insight, (int)HttpStatusCode.OK);
            }
            catch (NoContentException ex)
            {
                _logger.LogWarning("Nao retornou nenhuma informação do ObterTodos - Parametros: D: {0} - R: {1}", 0, 0);
                return OperationResult<GetInsightsDto>.Failure(ex.Message, (int)HttpStatusCode.NoContent);
            }
            catch (Exception ex)
            {
                _logger.LogError("[ERROR] - {0}", ex.Message);
                return OperationResult<GetInsightsDto>.Failure("Ocorreu um erro ao buscar todos os clientes", (int)HttpStatusCode.BadRequest);
            }
        }
    }
}
```

### Análise da Engenharia de Prompt:
- **Definição de Persona:** ao instruir a IA que ela é um *“analista de negócios especializado em análise de clientes, comportamento de consumo e oportunidades comerciais”*, o tom da resposta torna-se profissional, orientado a métricas e focado em tomada de decisão.
- **Seções Pré-definidas:** a estruturação do retorno em 6 seções claras padroniza o formato de saída, garantindo que o relatório seja previsível e legível.
- **Regras Estritas de Não-Alucinação:** a instrução explícita de *“Utilize somente informações presentes nos dados. Não invente valores, clientes, produtos ou cursos”* reduz drasticamente a chance de alucinação do modelo.
- **Contexto em JSON:** os dados são fornecidos em formato JSON nativo, que é facilmente interpretado por LLMs avançados como o GPT-4o-mini.

---

## 10. Exposição do Endpoint na Controller (`ClienteController`)

Para disponibilizar o recurso para os consumidores da API (Postman, Swagger, frontends e dashboards), criamos o endpoint `[HttpGet("insights")]` dentro da `ClienteController`.

### Arquivo: `AspNet.API/Controllers/ClienteController.cs`

```csharp
using AspNet.API.Application.Dtos;
using AspNet.API.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace AspNet.API.Controllers
{
    [Route("api/cliente")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly IClienteUseCase _clienteUseCase;

        public ClienteController(IClienteUseCase clienteUseCase)
        {
            _clienteUseCase = clienteUseCase;
        }

        // ... outros endpoints de CRUD de clientes ...

        [HttpGet("insights")]
        public async Task<IActionResult> GetInsights()
        {
            var resultado = await _clienteUseCase.ObterInsightsAsync();

            if (!resultado.IsSuccess) 
                return StatusCode(resultado.StatusCode, resultado.Error);

            return StatusCode(resultado.StatusCode, resultado.Value);
        }
    }
}
```

### Exemplo de Resposta da API (`GET /api/cliente/insights`):

```json
{
  "dados": [
    {
      "id": 1,
      "nome": "Carlos Silva",
      "email": "carlos@email.com",
      "idade": 34,
      "produtos": [
        {
          "id": 1,
          "nome": "Notebook Pro",
          "preco": 4500.0,
          "quantidade": 1
        }
      ],
      "cursos": [
        {
          "id": 1,
          "nome": "Arquitetura Cloud com .NET"
        }
      ]
    }
  ],
  "insightsMarkdown": "## 1. Resumo geral\n- **Quantidade total de clientes:** 1\n- **Idade média dos clientes:** 34 anos\n...\n## 5. Oportunidades comerciais\n- Oferecer curso avançado de Microservices para clientes de tecnologia..."
}
```

---

## 11. Resumo dos Conceitos e Boas Práticas da Aula

1. **Modularização em Camadas Claras**:
   - Manter a regra de negócio centralizada na camada de **Domínio** e orquestrada na camada de **Aplicação**.
   - A camada de **Infraestrutura** é a única que conhece detalhes concretos de banco de dados e APIs externas.
   - A camada de **IoC** desacopla o registro de dependências, permitindo que múltiplos projetos de apresentação compartilhem a mesma infraestrutura com esforço mínimo.
2. **Reuso em Múltiplas Apresentações**:
   - A criação de `Pedido.API` comprovou a eficiência da arquitetura: criamos uma nova API REST independente sem duplicar nenhuma entidade, repositório ou caso de uso.
3. **Padrão `IChatClient` (Microsoft Extensions AI)**:
   - A nova abstração oficial do .NET padroniza a integração com IA Generativa, garantindo portabilidade entre diferentes provedores e simplificando testes de unidade com mocks.
4. **Engenharia de Prompt Corporativa**:
   - Prompts bem elaborados com contexto serializado em JSON e regras estritas garantem relatórios consistentes, seguros e de alto valor comercial.

